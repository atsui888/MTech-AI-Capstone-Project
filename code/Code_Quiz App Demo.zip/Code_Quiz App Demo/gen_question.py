import json
import requests
from calc_cerebro_index import CalcCerebroIndex
from qxdf_helper import generated_question_to_qxdf_object
from typing import Union

class GenQuestion:
    def __init__(self, uid: str, upass: str, gen_quest_url: str, ci_url: str, debug=False):
        self._uid = uid
        self._upass = upass
        self._gen_quest_url = gen_quest_url
        self._calc_ci = CalcCerebroIndex(self._uid, self._upass, ci_url, debug=debug)

    def generate_question(self, question_format: str, complexity_level: str, domain: str,
                          question_purpose: str, shareable_read_only=False, user_provided_persona: Union[None, str]=None,
                          user_provided_question_content: Union[None, str]=None, timeout: int=30):
        """
        Send prompt to API to generate a question

        :param user_provided_question_content:
        :param question_format:
        :param complexity_level:
        :param domain:
        :param question_purpose:
        :param shareable_read_only:
        :param user_provided_persona:
        :param timeout: in Seconds
        :return:
        """

        headers = {'accept': 'application/json', 'Content-Type': 'application/json'}
        data = {
            'question_format': question_format,
            'complexity_level': complexity_level,
            'domain': domain,
            'question_purpose': question_purpose,
            'shareable_read_only': shareable_read_only,
            'user_provided_persona': user_provided_persona,
            'user_provided_question_content': user_provided_question_content
        }

        try:
            res = requests.post(
                self._gen_quest_url,
                headers=headers,
                data=json.dumps(data),
                auth=(self._uid, self._upass),
                timeout=timeout
            )
            res.raise_for_status()  # Raise an exception for bad status codes

            if res is not None:
                generation_error = res.json().get('generation_error')

                # todo: debug line
                # print(f"\n\n---------------> generation_error: {generation_error}\n\n")

                if generation_error is None or (isinstance(generation_error, dict) and len(generation_error)==0):
                    quest = res.json().get('generated_question')
                    return generated_question_to_qxdf_object(quest, self._calc_ci), res.json().get('insert_status')
                else:
                    return {"error": f"Error: Unable to get valid response from API "
                                     f"Server.\nGeneration Error --> {generation_error}"}
        except requests.exceptions.RequestException as e:
            print(f"An error occurred: {e}")
            return {"error": e}
        except json.JSONDecodeError as e:
            print("Could not decode the JSON response.")
            return {"error": e}

