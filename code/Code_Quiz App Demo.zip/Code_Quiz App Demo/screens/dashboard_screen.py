import ttkbootstrap as tb
from ttkbootstrap.constants import *


class DashboardScreen(tb.Frame):
    def __init__(self, master, navigator):
        super().__init__(master)
        self.nav = navigator

        container = tb.Frame(self, padding=20)
        container.pack(fill="both", expand=True)

        tb.Label(container, text="Dashboard", font=("Segoe UI", 18, "bold")).pack(pady=(0, 20))

        btn_row = tb.Frame(container)
        btn_row.pack(pady=10)

        tb.Button(btn_row, text="Auto-Generate Question", bootstyle=PRIMARY, width=20,
                  command=lambda: self.nav.show_screen("Question")).pack(side=LEFT, padx=10)
        tb.Button(btn_row, text="Manual Create Question", bootstyle=WARNING, width=20,
                  command=lambda: self.nav.show_screen("ManualQuestion")).pack(side=LEFT, padx=10)
        tb.Button(btn_row, text="Generate Quiz", bootstyle=SUCCESS, width=20,
                  command=lambda: self.nav.show_screen("Quiz")).pack(side=LEFT, padx=10)
        tb.Button(btn_row, text="Logout", bootstyle=DANGER, width=20,
                  command=lambda: self.nav.show_screen("Login")).pack(side=LEFT, padx=10)


