import json
import ttkbootstrap as tb
from ttkbootstrap.constants import *
from ttkbootstrap.dialogs import Messagebox
from tkinter import filedialog
import matplotlib.pyplot as plt
import matplotlib
from io import BytesIO
import base64
from PIL import Image, ImageTk
import os

from functions_stub import generate_question, calculate_complexity_score
from calc_cerebro_index import CalcCerebroIndex
from question_mcq import MCQQuestion
from question_shortanswer import ShortAnswerQuestion
from question_truefalse import TrueFalseQuestion
from generate_question import create_ci_contribution_chart


DOMAINS = ['math used in a supermarket', 'supervised machine learning', 'time in personal travel']
QFORMATS = ['mcq', 'short_answer', 'true_false']
LEVELS = ["very easy", "easy", "moderate", "challenging", "very challenging"]


class ChartModalWindow:
    """Modal window to display the complexity chart"""
    def __init__(self, parent, chart_path):
        self.chart_path = chart_path
        self.window = tb.Toplevel(parent)
        self.window.title("Complexity Score Breakdown Chart")
        self.window.geometry("800x600")
        self.window.resizable(True, True)
        
        # Make it modal
        self.window.transient(parent)
        self.window.grab_set()
        
        # Center the window
        self.window.update_idletasks()
        x = (self.window.winfo_screenwidth() // 2) - (800 // 2)
        y = (self.window.winfo_screenheight() // 2) - (600 // 2)
        self.window.geometry(f"800x600+{x}+{y}")
        
        self.create_widgets()
        
    def create_widgets(self):
        # Main frame
        main_frame = tb.Frame(self.window, padding=10)
        main_frame.pack(fill=BOTH, expand=True)
        
        # Title
        title_label = tb.Label(main_frame, text="Complexity Score Breakdown", 
                              font=("Segoe UI", 16, "bold"))
        title_label.pack(pady=(0, 10))
        
        # Image frame with scrollbars
        image_frame = tb.Frame(main_frame)
        image_frame.pack(fill=BOTH, expand=True)
        
        # Create canvas and scrollbars
        canvas = tb.Canvas(image_frame, bg="white")
        v_scrollbar = tb.Scrollbar(image_frame, orient=VERTICAL, command=canvas.yview)
        h_scrollbar = tb.Scrollbar(image_frame, orient=HORIZONTAL, command=canvas.xview)
        
        canvas.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
        
        # Pack scrollbars and canvas
        v_scrollbar.pack(side=RIGHT, fill=Y)
        h_scrollbar.pack(side=BOTTOM, fill=X)
        canvas.pack(side=LEFT, fill=BOTH, expand=True)
        
        # Load and display image
        try:
            if os.path.exists(self.chart_path):
                # Load image
                image = Image.open(self.chart_path)
                
                # Resize image if too large (max 1200x800)
                max_width, max_height = 1200, 800
                if image.width > max_width or image.height > max_height:
                    image.thumbnail((max_width, max_height), Image.Resampling.LANCZOS)
                
                # Convert to PhotoImage
                photo = ImageTk.PhotoImage(image)
                
                # Create image on canvas
                canvas.create_image(0, 0, anchor=NW, image=photo)
                canvas.configure(scrollregion=canvas.bbox("all"))
                
                # Keep a reference to prevent garbage collection
                canvas.image = photo
                
            else:
                # Show error if file doesn't exist
                error_label = tb.Label(canvas, text=f"Chart file not found: {self.chart_path}", 
                                     font=("Segoe UI", 12), fg="red")
                canvas.create_window(0, 0, anchor=NW, window=error_label)
                canvas.configure(scrollregion=canvas.bbox("all"))
                
        except Exception as e:
            # Show error if image loading fails
            error_label = tb.Label(canvas, text=f"Error loading chart: {str(e)}", 
                                 font=("Segoe UI", 12), fg="red")
            canvas.create_window(0, 0, anchor=NW, window=error_label)
            canvas.configure(scrollregion=canvas.bbox("all"))
        
        # Close button
        close_btn = tb.Button(main_frame, text="Close", bootstyle=PRIMARY, 
                             command=self.window.destroy)
        close_btn.pack(pady=(10, 0))
        
        # Focus on the window
        self.window.focus_set()


class QuestionScreen(tb.Frame):
    def __init__(self, master, navigator):
        super().__init__(master)
        self.nav = navigator
        self.current_question_obj = None  # instance of Question subclass
        self.score_valid = False

        wrapper = tb.Panedwindow(self, orient=HORIZONTAL)
        wrapper.pack(fill=BOTH, expand=True)

        left = tb.Frame(wrapper, padding=10)
        right = tb.Frame(wrapper, padding=10)
        wrapper.add(left, weight=1)
        wrapper.add(right, weight=1)

        # Controls - Auto generate
        tb.Label(left, text="Auto-generate Question", font=("Segoe UI", 14, "bold")).pack(anchor=W, pady=(0, 8))

        form = tb.Labelframe(left, text="Parameters", padding=10)
        form.pack(fill=X, pady=(0, 10))

        self.domain_var = tb.StringVar(value=DOMAINS[1])
        self.qformat_var = tb.StringVar(value=QFORMATS[0])
        self.level_var = tb.StringVar(value=LEVELS[2])
        self.share_ro_var = tb.BooleanVar(value=False)

        row = tb.Frame(form)
        row.pack(fill=X, pady=4)
        tb.Label(row, text="Domain", width=18).pack(side=LEFT)
        tb.Combobox(row, textvariable=self.domain_var, values=DOMAINS, state="readonly").pack(side=LEFT, fill=X, expand=True)

        row = tb.Frame(form)
        row.pack(fill=X, pady=4)
        tb.Label(row, text="Question format", width=18).pack(side=LEFT)
        tb.Combobox(row, textvariable=self.qformat_var, values=QFORMATS, state="readonly").pack(side=LEFT, fill=X, expand=True)

        row = tb.Frame(form)
        row.pack(fill=X, pady=4)
        tb.Label(row, text="Complexity level", width=18).pack(side=LEFT)
        tb.Combobox(row, textvariable=self.level_var, values=LEVELS, state="readonly").pack(side=LEFT, fill=X, expand=True)

        row = tb.Frame(form)
        row.pack(fill=X, pady=4)
        tb.Label(row, text="Context (optional)", width=18).pack(side=LEFT)
        self.context_text = tb.Text(row, height=6)
        self.context_text.pack(side=LEFT, fill=X, expand=True)
        btns_col = tb.Frame(row)
        btns_col.pack(side=LEFT, padx=6)
        tb.Button(btns_col, text="Upload .md", command=self.load_md).pack(fill=X)
        tb.Button(btns_col, text="Clear", command=self.clear_context).pack(fill=X, pady=(4,0))
        self.context_info = tb.StringVar(value="")
        tb.Label(form, textvariable=self.context_info).pack(anchor=W, pady=(2,0))

        tb.Checkbutton(form, text="Shareable read-only", variable=self.share_ro_var).pack(anchor=W, pady=(6, 0))

        self.generate_btn = tb.Button(left, text="Generate", bootstyle=PRIMARY, command=self.on_generate)
        self.generate_btn.pack(anchor=E, pady=4)
        self.status_var = tb.StringVar(value="")
        tb.Label(left, textvariable=self.status_var, bootstyle=SECONDARY).pack(anchor=W, pady=(0, 8))

        actions = tb.Frame(left)
        actions.pack(fill=X, pady=(0, 8))
        self.calc_btn = tb.Button(actions, text="Calculate Complexity", bootstyle=INFO, command=self.on_calculate_complexity)
        self.calc_btn.pack(side=LEFT)
        tb.Button(actions, text="Back", bootstyle=LINK, command=lambda: self.nav.show_screen("Dashboard")).pack(side=RIGHT)
        self.calc_result = tb.ScrolledText(left)
        self.calc_result.pack(fill=BOTH, expand=True)

        # Manual input removed

        # Right panel: display area
        tb.Label(right, text="Question Output", font=("Segoe UI", 14, "bold")).pack(anchor=W, pady=(0, 8))
        self.output = tb.ScrolledText(right, height=25)
        self.output.pack(fill=BOTH, expand=True)

    def load_md(self):
        path = filedialog.askopenfilename(filetypes=[("Markdown", "*.md"), ("Text", "*.txt"), ("All", "*.*")])
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                raw = f.read()
                limited, words, truncated = self._limit_context(raw)
                self.context_text.delete("1.0", END)
                self.context_text.insert("1.0", limited)
                info = f"Loaded: {path}  |  {words} words" + (" (truncated to 8000 words)" if truncated else "")
                self.context_info.set(info)
        except Exception as e:
            Messagebox.show_error(str(e), "File Error")

    def on_generate(self):
        domain = self.domain_var.get()
        qfmt = self.qformat_var.get()
        level = self.level_var.get()
        raw_context = self.context_text.get("1.0", END).strip()
        context, words, truncated = self._limit_context(raw_context)
        if raw_context:
            info = f"Context: {words} words" + (" (truncated to 8000 words)" if truncated else "")
            self.context_info.set(info)
        else:
            context = None
            self.context_info.set("")
        share_ro = self.share_ro_var.get()
        # Disable button and show status
        self.generate_btn.configure(state=DISABLED)
        self.status_var.set("Generating question... Please wait.")
        # Clear previous outputs before API request and force UI refresh
        self.output.delete("1.0", END)
        self.calc_result.delete("1.0", END)
        self.update_idletasks()
        # Run the blocking API call after a short delay to let the UI update
        self.after(50, lambda: self._do_generate(domain, qfmt, level, context, share_ro))

    def _do_generate(self, domain, qfmt, level, context, share_ro):
        try:
            quest = generate_question(domain=domain, question_format=qfmt, complexity_level=level,
                                      context=context, shareable_read_only=share_ro)
            self.current_question_obj = quest
            self.score_valid = True
            self.render_question(quest)
        except Exception as e:
            Messagebox.show_error(str(e), "Generation Error")
        finally:
            self.generate_btn.configure(state=NORMAL)
            self.status_var.set("")

    def _limit_context(self, text: str):
        if not text:
            return "", 0, False
        words = text.split()
        truncated = False
        if len(words) > 8000:
            words = words[:8000]
            truncated = True
        limited = " ".join(words)
        return limited, len(words), truncated

    def clear_context(self):
        self.context_text.delete("1.0", END)
        self.context_info.set("")
    
    def show_chart_modal(self, chart_path):
        """Display the chart in a modal window"""
        try:
            ChartModalWindow(self, chart_path)
        except Exception as e:
            Messagebox.show_error(f"Error displaying chart: {str(e)}", "Chart Display Error")

    def on_calculate_complexity(self):
        # Clear previous API response immediately
        self.calc_result.delete("1.0", END)
        self.update_idletasks()
        # Parse question data from the "Question Output" box
        view_text = self.output.get("1.0", END).strip()
        if not view_text:
            Messagebox.show_error("No question data found. Generate a question first.", "Validation")
            return
        uid = self.nav.state.uid
        upass = self.nav.state.upass
        url = self.nav.state.calc_ci_url
        if not all([uid, upass, url]):
            Messagebox.show_error("Please login first.", "Error")
            return
        try:
            # Disable button and show status
            self.calc_btn.configure(state=DISABLED)
            self.status_var.set("Calculating complexity... Please wait.")
            self.update_idletasks()
            # Clear previous API response box
            self.calc_result.delete("1.0", END)
            data = json.loads(view_text)
            calc = CalcCerebroIndex(uid=uid, upass=upass, url=url, display_status=False, debug=False)
            qobj = self._build_question_from_view(data, calc)
            if qobj is None:
                Messagebox.show_error("Unsupported or malformed question data.", "Error")
                return
            res = calculate_complexity_score(uid=uid, upass=upass, url=url, quest_obj=qobj)
            result = res.get('result') if res else None
            if not result:
                Messagebox.show_error("Complexity calculation failed.", "Error")
                return
            # Update display below button in a human-readable format
            self.calc_result.delete("1.0", END)
            human_result = self._format_ci_result_human(result)
            self.calc_result.insert("1.0", human_result)
            
            # Create and display the CI contribution chart
            try:
                # Update the question object with CI data for chart creation
                qobj._ci = result.get('complexity_score')
                
                # Construct the proper ci_explanation dictionary structure for chart creation
                component_scores = result.get('component_scores', {})
                ci_explanation_dict = {
                    'component_scores': component_scores,
                    'explanation': result.get('explanation', '')
                }
                qobj._ci_explanation = ci_explanation_dict
                
                # Create the chart
                fig, final_score, component_scores = create_ci_contribution_chart(qobj)
                
                # Add chart information to the display
                chart_info = f"\n\nChart Information:\n"
                chart_info += f"Final CI Score: {final_score}\n"
                chart_info += f"Component Scores: {component_scores}\n"
                chart_info += f"Chart saved as: score_breakdown_bar_chart.png\n"
                
                self.calc_result.insert(END, chart_info)
                
                # Close the figure to free memory
                plt.close(fig)
                
                # Show the chart in a modal window
                self.show_chart_modal('score_breakdown_bar_chart.png')
                
            except Exception as chart_error:
                error_msg = f"\n\nChart Creation Error: {str(chart_error)}\n"
                self.calc_result.insert(END, error_msg)
            
            # Also reflect updated CI in the main view
            self.current_question_obj = qobj
            self.score_valid = True
            self.render_question(qobj)
        except Exception as e:
            Messagebox.show_error(str(e), "Complexity Error")
        finally:
            self.calc_btn.configure(state=NORMAL)
            self.status_var.set("")

    # Recalculate removed

    def render_question(self, quest_obj):
        self.output.delete("1.0", END)
        try:
            data = quest_obj.to_dict()
            # hide long explanation details but keep component_scores summary if available
            explanation = data.get("ci_explanation")
            compact = {}
            if isinstance(explanation, dict):
                compact = {
                    "component_scores": explanation.get("component_scores"),
                }
            view = {
                "id": data.get("id"),
                "type": data.get("type"),
                "question": data.get("question"),
                "hint": data.get("hint"),
                "allowed_time_s": data.get("allowed_time_s"),
                "points": data.get("points"),
                "ci": data.get("ci"),
                "ci_explanation": compact or explanation,
            }
            if isinstance(quest_obj, MCQQuestion):
                view.update({
                    "options": data.get("options"),
                    "correct_indices": data.get("correct_indices"),
                })
            elif isinstance(quest_obj, TrueFalseQuestion):
                view.update({
                    "correct_value": data.get("correct_value"),
                    "correct_ans_explanation": data.get("correct_ans_explanation"),
                    "incorrect_ans_explanation": data.get("incorrect_ans_explanation"),
                })
            elif isinstance(quest_obj, ShortAnswerQuestion):
                view.update({
                    "expected_answer": data.get("expected_answer"),
                    "expected_ans_explanation": data.get("expected_ans_explanation"),
                })

            self.output.insert("1.0", json.dumps(view, indent=2))
        except Exception as e:
            self.output.insert("1.0", f"Error displaying question: {e}")

    def _build_question_from_view(self, data: dict, calc_obj: CalcCerebroIndex):
        qtype = data.get("type")
        qtext = data.get("question")
        allowed_time_s = data.get("allowed_time_s")
        points = data.get("points")
        hint = data.get("hint")
        if qtype == "mcq":
            options = data.get("options") or []
            correct_indices = data.get("correct_indices") or []
            return MCQQuestion(question_text=qtext, options=options, correct_indices=correct_indices,
                               allowed_time_s=allowed_time_s, points=points, hint=hint, calc_ci_obj=calc_obj)
        if qtype == "short_answer":
            expected_answer = data.get("expected_answer") or ""
            expected_ans_explanation = data.get("expected_ans_explanation") or ""
            return ShortAnswerQuestion(question_text=qtext, expected_answer=expected_answer,
                                      expected_ans_explanation=expected_ans_explanation,
                                      allowed_time_s=allowed_time_s, points=points, hint=hint, calc_ci_obj=calc_obj)
        if qtype == "true_false":
            correct_value = data.get("correct_value")
            correct_ans_explanation = data.get("correct_ans_explanation") or ""
            incorrect_ans_explanation = data.get("incorrect_ans_explanation") or ""
            return TrueFalseQuestion(question_text=qtext, correct_value=correct_value,
                                     correct_ans_explanation=correct_ans_explanation,
                                     incorrect_ans_explanation=incorrect_ans_explanation,
                                     allowed_time_s=allowed_time_s, points=points, hint=hint, calc_ci_obj=calc_obj)
        return None

    def _format_ci_result_human(self, result: dict) -> str:
        lines = []
        q = result.get("question", {}) or {}
        lines.append("Complexity Analysis")
        lines.append("====================")
        if q:
            lines.append(f"Type: {q.get('question_type')}")
            lines.append(f"Question: {q.get('question_text')}")
            if q.get('hint'):
                lines.append(f"Hint: {q.get('hint')}")
            if q.get('question_type') == 'mcq':
                opts = q.get('options') or []
                correct = set(q.get('correct_indices') or [])
                for idx, opt in enumerate(opts):
                    mark = '✓' if idx in correct else ' '
                    lines.append(f"  - ({mark}) {opt.get('text')}")
            elif q.get('question_type') == 'true_false':
                lines.append(f"Answer: {q.get('correct_value')}")
            elif q.get('question_type') == 'short_answer':
                if q.get('expected_answer'):
                    lines.append(f"Expected: {q.get('expected_answer')}")
        lines.append("")
        lines.append(f"CI Score: {result.get('complexity_score')}")
        comp = result.get('component_scores') or {}
        if comp:
            lines.append("Component Scores:")
            lines.append(f"  BLTX: {comp.get('bltx')}  AMB: {comp.get('amb')}  INFD: {comp.get('infd')}  STC: {comp.get('stc')}  CIC: {comp.get('cic')}  GS: {comp.get('gs')}")
        if result.get('explanation'):
            lines.append("")
            lines.append(f"Summary: {result.get('explanation')}")
        # Per-component brief summaries if present
        for key, title in [("bltx", "Bloom's Taxonomy"), ("amb", "Ambiguity"), ("infd", "Information Density"), ("stc", "Syntactic Complexity"), ("cic", "Conceptual Interconnectedness"), ("gs", "Guessing Susceptibility")]:
            sec = result.get(key)
            if isinstance(sec, dict) and sec.get('overall_summary'):
                lines.append("")
                lines.append(f"{title}: {sec.get('overall_summary')}")
        return "\n".join(lines)


