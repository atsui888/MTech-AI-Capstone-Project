import ttkbootstrap as tb
from ttkbootstrap.constants import *
from ttkbootstrap.dialogs import Messagebox
from functions_stub import check_login_credentials, set_login_context


class LoginScreen(tb.Frame):
    def __init__(self, master, navigator):
        super().__init__(master)
        self.nav = navigator

        container = tb.Frame(self, padding=20)
        container.pack(expand=True)

        title = tb.Label(container, text="Quiz Maker - Login", font=("Segoe UI", 18, "bold"))
        title.grid(row=0, column=0, columnspan=2, pady=(0, 20))

        tb.Label(container, text="Username").grid(row=1, column=0, sticky=E, padx=(0, 10))
        self.username_var = tb.StringVar()
        tb.Entry(container, textvariable=self.username_var, width=30).grid(row=1, column=1, sticky=W)

        tb.Label(container, text="Password").grid(row=2, column=0, sticky=E, padx=(0, 10), pady=(10, 0))
        self.password_var = tb.StringVar()
        tb.Entry(container, textvariable=self.password_var, show="*", width=30).grid(row=2, column=1, sticky=W, pady=(10, 0))

        btn = tb.Button(container, text="Login", bootstyle=PRIMARY, command=self.on_login)
        btn.grid(row=3, column=0, columnspan=2, pady=20, sticky=EW)

        container.columnconfigure(1, weight=1)

    def on_login(self):
        username = self.username_var.get().strip()
        password = self.password_var.get().strip()
        if not username or not password:
            Messagebox.show_error("Please enter username and password.", "Error")
            return
        try:
            uid, upass, calc_ci_url, gen_question_url, gen_quiz_url = check_login_credentials(username, password)
            # Persist in navigator state
            self.nav.state.uid = uid
            self.nav.state.upass = upass
            self.nav.state.calc_ci_url = calc_ci_url
            self.nav.state.gen_question_url = gen_question_url
            self.nav.state.gen_quiz_url = gen_quiz_url

            # Configure globals expected by provided modules
            set_login_context(uid, upass, calc_ci_url, gen_question_url, gen_quiz_url)

            self.nav.show_screen("Dashboard")
        except Exception as e:
            Messagebox.show_error(str(e), "Login Failed")


