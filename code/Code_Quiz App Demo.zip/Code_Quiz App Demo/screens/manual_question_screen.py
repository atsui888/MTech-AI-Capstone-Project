import json
import ttkbootstrap as tb
from ttkbootstrap.constants import *
from ttkbootstrap.dialogs import Messagebox
import matplotlib.pyplot as plt
import matplotlib
from io import BytesIO
import base64
from PIL import Image, ImageTk
import os

from functions_stub import calculate_complexity_score
from calc_cerebro_index import CalcCerebroIndex
from question_mcq import MCQQuestion
from question_shortanswer import ShortAnswerQuestion
from question_truefalse import TrueFalseQuestion
from generate_question import create_ci_contribution_chart


class ChartModalWindow:
    """Modal window to display the complexity chart"""
    def __init__(self, parent, chart_path):
        self.chart_path = chart_path
        self.window = tb.Toplevel(parent)
        self.window.title("Complexity Score Breakdown Chart")
        self.window.geometry("800x600")
        self.window.resizable(True, True)
        
        # Make it modal
        self.window.transient(parent)
        self.window.grab_set()
        
        # Center the window
        self.window.update_idletasks()
        x = (self.window.winfo_screenwidth() // 2) - (800 // 2)
        y = (self.window.winfo_screenheight() // 2) - (600 // 2)
        self.window.geometry(f"800x600+{x}+{y}")
        
        self.create_widgets()
        
    def create_widgets(self):
        # Main frame
        main_frame = tb.Frame(self.window, padding=10)
        main_frame.pack(fill=BOTH, expand=True)
        
        # Title
        title_label = tb.Label(main_frame, text="Complexity Score Breakdown", 
                              font=("Segoe UI", 16, "bold"))
        title_label.pack(pady=(0, 10))
        
        # Image frame with scrollbars
        image_frame = tb.Frame(main_frame)
        image_frame.pack(fill=BOTH, expand=True)
        
        # Create canvas and scrollbars
        canvas = tb.Canvas(image_frame, bg="white")
        v_scrollbar = tb.Scrollbar(image_frame, orient=VERTICAL, command=canvas.yview)
        h_scrollbar = tb.Scrollbar(image_frame, orient=HORIZONTAL, command=canvas.xview)
        
        canvas.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
        
        # Pack scrollbars and canvas
        v_scrollbar.pack(side=RIGHT, fill=Y)
        h_scrollbar.pack(side=BOTTOM, fill=X)
        canvas.pack(side=LEFT, fill=BOTH, expand=True)
        
        # Load and display image
        try:
            if os.path.exists(self.chart_path):
                # Load image
                image = Image.open(self.chart_path)
                
                # Resize image if too large (max 1200x800)
                max_width, max_height = 1200, 800
                if image.width > max_width or image.height > max_height:
                    image.thumbnail((max_width, max_height), Image.Resampling.LANCZOS)
                
                # Convert to PhotoImage
                photo = ImageTk.PhotoImage(image)
                
                # Create image on canvas
                canvas.create_image(0, 0, anchor=NW, image=photo)
                canvas.configure(scrollregion=canvas.bbox("all"))
                
                # Keep a reference to prevent garbage collection
                canvas.image = photo
                
            else:
                # Show error if file doesn't exist
                error_label = tb.Label(canvas, text=f"Chart file not found: {self.chart_path}", 
                                     font=("Segoe UI", 12), fg="red")
                canvas.create_window(0, 0, anchor=NW, window=error_label)
                canvas.configure(scrollregion=canvas.bbox("all"))
                
        except Exception as e:
            # Show error if image loading fails
            error_label = tb.Label(canvas, text=f"Error loading chart: {str(e)}", 
                                 font=("Segoe UI", 12), fg="red")
            canvas.create_window(0, 0, anchor=NW, window=error_label)
            canvas.configure(scrollregion=canvas.bbox("all"))
        
        # Close button
        close_btn = tb.Button(main_frame, text="Close", bootstyle=PRIMARY, 
                             command=self.window.destroy)
        close_btn.pack(pady=(10, 0))
        
        # Focus on the window
        self.window.focus_set()


class ManualQuestionScreen(tb.Frame):
    def __init__(self, master, navigator):
        super().__init__(master)
        self.nav = navigator
        self.current_question_obj = None
        self.score_valid = False

        # Main container with scrollbar
        main_container = tb.Frame(self)
        main_container.pack(fill=BOTH, expand=True)

        # Create canvas and scrollbar
        canvas = tb.Canvas(main_container)
        scrollbar = tb.Scrollbar(main_container, orient=VERTICAL, command=canvas.yview)
        scrollable_frame = tb.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Pack canvas and scrollbar
        canvas.pack(side=LEFT, fill=BOTH, expand=True)
        scrollbar.pack(side=RIGHT, fill=Y)

        # Title
        tb.Label(scrollable_frame, text="Manual Create Question", font=("Segoe UI", 18, "bold")).pack(pady=(0, 20))

        # Common question attributes
        common_frame = tb.Labelframe(scrollable_frame, text="Common Question Attributes", padding=10)
        common_frame.pack(fill=X, pady=(0, 10))

        # Question text
        tb.Label(common_frame, text="Question Text *", font=("Segoe UI", 10, "bold")).pack(anchor=W, pady=(0, 5))
        self.question_text = tb.Text(common_frame, height=4, wrap=WORD)
        self.question_text.pack(fill=X, pady=(0, 10))

        # Question type switcher
        tb.Label(common_frame, text="Question Type *", font=("Segoe UI", 10, "bold")).pack(anchor=W, pady=(0, 5))
        self.question_type_var = tb.StringVar(value="mcq")
        question_type_frame = tb.Frame(common_frame)
        question_type_frame.pack(fill=X, pady=(0, 10))
        
        question_types = [("Multiple Choice (MCQ)", "mcq"), ("Short Answer", "short_answer"), ("True/False", "true_false")]
        for text, value in question_types:
            tb.Radiobutton(question_type_frame, text=text, variable=self.question_type_var, 
                          value=value, command=self.on_question_type_change).pack(side=LEFT, padx=(0, 20))

        # Optional attributes
        optional_frame = tb.Frame(common_frame)
        optional_frame.pack(fill=X, pady=(0, 10))

        # Allowed time
        time_frame = tb.Frame(optional_frame)
        time_frame.pack(fill=X, pady=2)
        tb.Label(time_frame, text="Allowed Time (seconds):", width=20).pack(side=LEFT)
        self.allowed_time_var = tb.StringVar(value="0")
        tb.Entry(time_frame, textvariable=self.allowed_time_var, width=10).pack(side=LEFT, padx=(5, 0))

        # Points
        points_frame = tb.Frame(optional_frame)
        points_frame.pack(fill=X, pady=2)
        tb.Label(points_frame, text="Points:", width=20).pack(side=LEFT)
        self.points_var = tb.StringVar(value="0")
        tb.Entry(points_frame, textvariable=self.points_var, width=10).pack(side=LEFT, padx=(5, 0))

        # Hint
        tb.Label(optional_frame, text="Hint (optional):", font=("Segoe UI", 10, "bold")).pack(anchor=W, pady=(10, 5))
        self.hint_text = tb.Text(optional_frame, height=2, wrap=WORD)
        self.hint_text.pack(fill=X, pady=(0, 10))

        # Type-specific attributes frame
        self.type_specific_frame = tb.Labelframe(scrollable_frame, text="Type-Specific Attributes", padding=10)
        self.type_specific_frame.pack(fill=X, pady=(0, 10))

        # Initialize type-specific widgets
        self.init_type_specific_widgets()

        # Buttons
        button_frame = tb.Frame(scrollable_frame)
        button_frame.pack(fill=X, pady=10)

        self.calc_btn = tb.Button(button_frame, text="Calculate Complexity", bootstyle=INFO, 
                                 command=self.on_calculate_complexity)
        self.calc_btn.pack(side=LEFT, padx=(0, 10))

        tb.Button(button_frame, text="Back", bootstyle=LINK, 
                 command=lambda: self.nav.show_screen("Dashboard")).pack(side=RIGHT)

        # Status and result
        self.status_var = tb.StringVar(value="")
        tb.Label(scrollable_frame, textvariable=self.status_var, bootstyle=SECONDARY).pack(anchor=W, pady=(0, 5))

        # Result display
        tb.Label(scrollable_frame, text="Complexity Analysis Result", font=("Segoe UI", 14, "bold")).pack(anchor=W, pady=(10, 5))
        self.calc_result = tb.ScrolledText(scrollable_frame, height=15)
        self.calc_result.pack(fill=BOTH, expand=True, pady=(0, 10))

        # Bind mousewheel to canvas
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel)

    def init_type_specific_widgets(self):
        """Initialize type-specific input widgets"""
        # Clear existing widgets
        for widget in self.type_specific_frame.winfo_children():
            widget.destroy()

        question_type = self.question_type_var.get()

        if question_type == "mcq":
            self.init_mcq_widgets()
        elif question_type == "short_answer":
            self.init_short_answer_widgets()
        elif question_type == "true_false":
            self.init_true_false_widgets()

    def init_mcq_widgets(self):
        """Initialize MCQ-specific widgets"""
        # Options
        tb.Label(self.type_specific_frame, text="Options *", font=("Segoe UI", 10, "bold")).pack(anchor=W, pady=(0, 5))
        
        # Options container
        self.options_frame = tb.Frame(self.type_specific_frame)
        self.options_frame.pack(fill=X, pady=(0, 10))
        
        # Add initial option
        self.mcq_options = []
        self.add_mcq_option()

        # Add/Remove buttons
        option_btn_frame = tb.Frame(self.type_specific_frame)
        option_btn_frame.pack(fill=X, pady=(0, 10))
        tb.Button(option_btn_frame, text="Add Option", command=self.add_mcq_option).pack(side=LEFT, padx=(0, 10))
        tb.Button(option_btn_frame, text="Remove Last Option", command=self.remove_mcq_option).pack(side=LEFT)

        # Correct indices
        tb.Label(self.type_specific_frame, text="Correct Answer Indices (comma-separated, 0-based) *", 
                font=("Segoe UI", 10, "bold")).pack(anchor=W, pady=(0, 5))
        self.correct_indices_var = tb.StringVar(value="0")
        tb.Entry(self.type_specific_frame, textvariable=self.correct_indices_var).pack(fill=X, pady=(0, 10))

    def init_short_answer_widgets(self):
        """Initialize Short Answer-specific widgets"""
        # Expected answer
        tb.Label(self.type_specific_frame, text="Expected Answer *", font=("Segoe UI", 10, "bold")).pack(anchor=W, pady=(0, 5))
        self.expected_answer_var = tb.StringVar()
        tb.Entry(self.type_specific_frame, textvariable=self.expected_answer_var).pack(fill=X, pady=(0, 10))

        # Expected answer explanation
        tb.Label(self.type_specific_frame, text="Expected Answer Explanation *", font=("Segoe UI", 10, "bold")).pack(anchor=W, pady=(0, 5))
        self.expected_ans_explanation = tb.Text(self.type_specific_frame, height=3, wrap=WORD)
        self.expected_ans_explanation.pack(fill=X, pady=(0, 10))

    def init_true_false_widgets(self):
        """Initialize True/False-specific widgets"""
        # Correct value
        tb.Label(self.type_specific_frame, text="Correct Answer *", font=("Segoe UI", 10, "bold")).pack(anchor=W, pady=(0, 5))
        self.correct_value_var = tb.StringVar(value="True")
        correct_frame = tb.Frame(self.type_specific_frame)
        correct_frame.pack(fill=X, pady=(0, 10))
        tb.Radiobutton(correct_frame, text="True", variable=self.correct_value_var, value="True").pack(side=LEFT, padx=(0, 20))
        tb.Radiobutton(correct_frame, text="False", variable=self.correct_value_var, value="False").pack(side=LEFT)

        # Correct answer explanation
        tb.Label(self.type_specific_frame, text="Correct Answer Explanation *", font=("Segoe UI", 10, "bold")).pack(anchor=W, pady=(10, 5))
        self.correct_ans_explanation = tb.Text(self.type_specific_frame, height=3, wrap=WORD)
        self.correct_ans_explanation.pack(fill=X, pady=(0, 10))

        # Incorrect answer explanation
        tb.Label(self.type_specific_frame, text="Incorrect Answer Explanation *", font=("Segoe UI", 10, "bold")).pack(anchor=W, pady=(10, 5))
        self.incorrect_ans_explanation = tb.Text(self.type_specific_frame, height=3, wrap=WORD)
        self.incorrect_ans_explanation.pack(fill=X, pady=(0, 10))

    def add_mcq_option(self):
        """Add a new MCQ option"""
        option_frame = tb.Frame(self.options_frame)
        option_frame.pack(fill=X, pady=2)
        
        option_text = tb.Text(option_frame, height=2, wrap=WORD)
        option_text.pack(side=LEFT, fill=X, expand=True, padx=(0, 5))
        
        self.mcq_options.append(option_text)

    def remove_mcq_option(self):
        """Remove the last MCQ option"""
        if len(self.mcq_options) > 1:
            option = self.mcq_options.pop()
            option.master.destroy()

    def on_question_type_change(self):
        """Handle question type change"""
        self.init_type_specific_widgets()

    def get_common_attributes(self):
        """Get common question attributes from form"""
        question_text = self.question_text.get("1.0", END).strip()
        if not question_text:
            raise ValueError("Question text is required")
        
        try:
            allowed_time_s = int(self.allowed_time_var.get()) if self.allowed_time_var.get() else 0
        except ValueError:
            allowed_time_s = 0
            
        try:
            points = int(self.points_var.get()) if self.points_var.get() else 0
        except ValueError:
            points = 0
            
        hint_text = self.hint_text.get("1.0", END).strip()
        hint = [hint_text] if hint_text else None
        
        return {
            'question_text': question_text,
            'allowed_time_s': allowed_time_s,
            'points': points,
            'hint': hint
        }

    def get_mcq_attributes(self):
        """Get MCQ-specific attributes from form"""
        # Get options
        options = []
        for option_text in self.mcq_options:
            text = option_text.get("1.0", END).strip()
            if text:
                options.append({'text': text, 'explanation': ''})  # Empty explanation for now
        
        if len(options) < 2:
            raise ValueError("At least 2 options are required for MCQ")
        
        # Get correct indices
        try:
            correct_indices_str = self.correct_indices_var.get().strip()
            if not correct_indices_str:
                raise ValueError("Correct indices are required for MCQ")
            correct_indices = [int(x.strip()) for x in correct_indices_str.split(',')]
            
            # Validate indices
            for idx in correct_indices:
                if idx < 0 or idx >= len(options):
                    raise ValueError(f"Invalid correct index: {idx}. Must be between 0 and {len(options)-1}")
                    
        except ValueError as e:
            if "invalid literal" in str(e):
                raise ValueError("Correct indices must be comma-separated numbers")
            raise
        
        return {
            'options': options,
            'correct_indices': correct_indices
        }

    def get_short_answer_attributes(self):
        """Get Short Answer-specific attributes from form"""
        expected_answer = self.expected_answer_var.get().strip()
        if not expected_answer:
            raise ValueError("Expected answer is required for Short Answer")
        
        expected_ans_explanation = self.expected_ans_explanation.get("1.0", END).strip()
        if not expected_ans_explanation:
            raise ValueError("Expected answer explanation is required for Short Answer")
        
        return {
            'expected_answer': expected_answer,
            'expected_ans_explanation': expected_ans_explanation
        }

    def get_true_false_attributes(self):
        """Get True/False-specific attributes from form"""
        correct_value = self.correct_value_var.get()
        if not correct_value:
            raise ValueError("Correct answer is required for True/False")
        
        correct_ans_explanation = self.correct_ans_explanation.get("1.0", END).strip()
        if not correct_ans_explanation:
            raise ValueError("Correct answer explanation is required for True/False")
        
        incorrect_ans_explanation = self.incorrect_ans_explanation.get("1.0", END).strip()
        if not incorrect_ans_explanation:
            raise ValueError("Incorrect answer explanation is required for True/False")
        
        return {
            'correct_value': correct_value,
            'correct_ans_explanation': correct_ans_explanation,
            'incorrect_ans_explanation': incorrect_ans_explanation
        }

    def create_question_object(self):
        """Create question object based on form data"""
        common_attrs = self.get_common_attributes()
        question_type = self.question_type_var.get()
        
        # Get credentials
        uid = self.nav.state.uid
        upass = self.nav.state.upass
        url = self.nav.state.calc_ci_url
        
        if not all([uid, upass, url]):
            raise ValueError("Please login first")
        
        calc_obj = CalcCerebroIndex(uid=uid, upass=upass, url=url, display_status=False, debug=False)
        
        if question_type == "mcq":
            mcq_attrs = self.get_mcq_attributes()
            return MCQQuestion(
                question_text=common_attrs['question_text'],
                options=mcq_attrs['options'],
                correct_indices=mcq_attrs['correct_indices'],
                allowed_time_s=common_attrs['allowed_time_s'],
                points=common_attrs['points'],
                hint=common_attrs['hint'],
                calc_ci_obj=calc_obj
            )
        elif question_type == "short_answer":
            sa_attrs = self.get_short_answer_attributes()
            return ShortAnswerQuestion(
                question_text=common_attrs['question_text'],
                expected_answer=sa_attrs['expected_answer'],
                expected_ans_explanation=sa_attrs['expected_ans_explanation'],
                allowed_time_s=common_attrs['allowed_time_s'],
                points=common_attrs['points'],
                hint=common_attrs['hint'],
                calc_ci_obj=calc_obj
            )
        elif question_type == "true_false":
            tf_attrs = self.get_true_false_attributes()
            return TrueFalseQuestion(
                question_text=common_attrs['question_text'],
                correct_value=tf_attrs['correct_value'],
                correct_ans_explanation=tf_attrs['correct_ans_explanation'],
                incorrect_ans_explanation=tf_attrs['incorrect_ans_explanation'],
                allowed_time_s=common_attrs['allowed_time_s'],
                points=common_attrs['points'],
                hint=common_attrs['hint'],
                calc_ci_obj=calc_obj
            )
        else:
            raise ValueError(f"Unsupported question type: {question_type}")

    def on_calculate_complexity(self):
        """Calculate complexity for the manually created question"""
        try:
            # Clear previous results
            self.calc_result.delete("1.0", END)
            self.status_var.set("Calculating complexity... Please wait.")
            self.update_idletasks()
            
            # Create question object
            question_obj = self.create_question_object()
            self.current_question_obj = question_obj
            
            # Get credentials
            uid = self.nav.state.uid
            upass = self.nav.state.upass
            url = self.nav.state.calc_ci_url
            
            # Calculate complexity
            res = calculate_complexity_score(uid=uid, upass=upass, url=url, quest_obj=question_obj)
            result = res.get('result') if res else None
            
            if not result:
                raise ValueError("Complexity calculation failed")
            
            # Format and display result
            human_result = self._format_ci_result_human(result)
            self.calc_result.insert("1.0", human_result)
            
            # Create and display the CI contribution chart
            try:
                # Update the question object with CI data for chart creation
                question_obj._ci = result.get('complexity_score')
                
                # Construct the proper ci_explanation dictionary structure for chart creation
                component_scores = result.get('component_scores', {})
                ci_explanation_dict = {
                    'component_scores': component_scores,
                    'explanation': result.get('explanation', '')
                }
                question_obj._ci_explanation = ci_explanation_dict
                
                # Create the chart
                fig, final_score, component_scores = create_ci_contribution_chart(question_obj)
                
                # Add chart information to the display
                chart_info = f"\n\nChart Information:\n"
                chart_info += f"Final CI Score: {final_score}\n"
                chart_info += f"Component Scores: {component_scores}\n"
                chart_info += f"Chart saved as: score_breakdown_bar_chart.png\n"
                
                self.calc_result.insert(END, chart_info)
                
                # Close the figure to free memory
                plt.close(fig)
                
                # Show the chart in a modal window
                self.show_chart_modal('score_breakdown_bar_chart.png')
                
            except Exception as chart_error:
                error_msg = f"\n\nChart Creation Error: {str(chart_error)}\n"
                self.calc_result.insert(END, error_msg)
            
            self.score_valid = True
            self.status_var.set("Complexity calculation completed successfully!")
            
        except Exception as e:
            Messagebox.show_error(str(e), "Complexity Calculation Error")
            self.status_var.set("")
        finally:
            self.calc_btn.configure(state=NORMAL)

    def show_chart_modal(self, chart_path):
        """Display the chart in a modal window"""
        try:
            ChartModalWindow(self, chart_path)
        except Exception as e:
            Messagebox.show_error(f"Error displaying chart: {str(e)}", "Chart Display Error")

    def _format_ci_result_human(self, result: dict) -> str:
        """Format complexity result for human reading"""
        lines = []
        q = result.get("question", {}) or {}
        lines.append("Complexity Analysis")
        lines.append("====================")
        if q:
            lines.append(f"Type: {q.get('question_type')}")
            lines.append(f"Question: {q.get('question_text')}")
            if q.get('hint'):
                lines.append(f"Hint: {q.get('hint')}")
            if q.get('question_type') == 'mcq':
                opts = q.get('options') or []
                correct = set(q.get('correct_indices') or [])
                for idx, opt in enumerate(opts):
                    mark = '✓' if idx in correct else ' '
                    lines.append(f"  - ({mark}) {opt.get('text')}")
            elif q.get('question_type') == 'true_false':
                lines.append(f"Answer: {q.get('correct_value')}")
            elif q.get('question_type') == 'short_answer':
                if q.get('expected_answer'):
                    lines.append(f"Expected: {q.get('expected_answer')}")
        lines.append("")
        lines.append(f"CI Score: {result.get('complexity_score')}")
        comp = result.get('component_scores') or {}
        if comp:
            lines.append("Component Scores:")
            lines.append(f"  BLTX: {comp.get('bltx')}  AMB: {comp.get('amb')}  INFD: {comp.get('infd')}  STC: {comp.get('stc')}  CIC: {comp.get('cic')}  GS: {comp.get('gs')}")
        if result.get('explanation'):
            lines.append("")
            lines.append(f"Summary: {result.get('explanation')}")
        # Per-component brief summaries if present
        for key, title in [("bltx", "Bloom's Taxonomy"), ("amb", "Ambiguity"), ("infd", "Information Density"), ("stc", "Syntactic Complexity"), ("cic", "Conceptual Interconnectedness"), ("gs", "Guessing Susceptibility")]:
            sec = result.get(key)
            if isinstance(sec, dict) and sec.get('overall_summary'):
                lines.append("")
                lines.append(f"{title}: {sec.get('overall_summary')}")
        return "\n".join(lines)
