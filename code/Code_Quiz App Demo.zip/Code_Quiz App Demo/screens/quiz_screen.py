import json
import ttkbootstrap as tb
from ttkbootstrap.constants import *
from ttkbootstrap.dialogs import Messagebox
from functions_stub import generate_quiz


DOMAINS = ['math used in a supermarket', 'supervised machine learning', 'time in personal travel']


class QuizScreen(tb.Frame):
    def __init__(self, master, navigator):
        super().__init__(master)
        self.nav = navigator

        container = tb.Frame(self, padding=12)
        container.pack(fill=BOTH, expand=True)

        tb.Label(container, text="Generate Quiz", font=("Segoe UI", 16, "bold")).pack(anchor=W, pady=(0, 10))

        form = tb.Labelframe(container, text="Parameters", padding=10)
        form.pack(fill=X)

        self.title_var = tb.StringVar()
        self.desc_var = tb.StringVar()
        self.domain_var = tb.StringVar(value=DOMAINS[1])
        self.num_q_var = tb.IntVar(value=3)
        self.avg_ci_var = tb.DoubleVar(value=5.0)
        self.share_quiz_var = tb.BooleanVar(value=False)
        self.add_share_ro_var = tb.BooleanVar(value=False)

        row = tb.Frame(form); row.pack(fill=X, pady=4)
        tb.Label(row, text="Title", width=22).pack(side=LEFT)
        tb.Entry(row, textvariable=self.title_var).pack(side=LEFT, fill=X, expand=True)

        row = tb.Frame(form); row.pack(fill=X, pady=4)
        tb.Label(row, text="Description", width=22).pack(side=LEFT)
        tb.Entry(row, textvariable=self.desc_var).pack(side=LEFT, fill=X, expand=True)

        row = tb.Frame(form); row.pack(fill=X, pady=4)
        tb.Label(row, text="Domain", width=22).pack(side=LEFT)
        tb.Combobox(row, textvariable=self.domain_var, values=DOMAINS, state="readonly").pack(side=LEFT, fill=X, expand=True)

        row = tb.Frame(form); row.pack(fill=X, pady=4)
        tb.Label(row, text="Number of questions", width=22).pack(side=LEFT)
        tb.Spinbox(row, from_=1, to=50, textvariable=self.num_q_var, width=8).pack(side=LEFT)

        row = tb.Labelframe(form, text="Question format distribution (0-1, sum=1)", padding=6)
        row.pack(fill=X, pady=4)
        self.mcq_var = tb.DoubleVar(value=0.5)
        self.sa_var = tb.DoubleVar(value=0.25)
        self.tf_var = tb.DoubleVar(value=0.25)
        tb.Label(row, text="MCQ", width=6).pack(side=LEFT); tb.Entry(row, textvariable=self.mcq_var, width=8).pack(side=LEFT, padx=(0,10))
        tb.Label(row, text="Short", width=6).pack(side=LEFT); tb.Entry(row, textvariable=self.sa_var, width=8).pack(side=LEFT, padx=(0,10))
        tb.Label(row, text="T/F", width=6).pack(side=LEFT); tb.Entry(row, textvariable=self.tf_var, width=8).pack(side=LEFT)

        row = tb.Frame(form); row.pack(fill=X, pady=4)
        tb.Label(row, text="Average complexity (0-10)", width=22).pack(side=LEFT)
        tb.Entry(row, textvariable=self.avg_ci_var, width=10).pack(side=LEFT)

        opts = tb.Frame(form); opts.pack(fill=X, pady=6)
        tb.Checkbutton(opts, text="Make quiz shareable", variable=self.share_quiz_var).pack(side=LEFT)
        tb.Checkbutton(opts, text="Add shareable read-only", variable=self.add_share_ro_var).pack(side=LEFT, padx=10)

        actions = tb.Frame(container)
        actions.pack(fill=X, pady=8)
        self.gen_btn = tb.Button(actions, text="Generate", bootstyle=PRIMARY, command=self.on_generate)
        self.gen_btn.pack(side=LEFT)
        tb.Button(actions, text="Back", bootstyle=LINK, command=lambda: self.nav.show_screen("Dashboard")).pack(side=RIGHT)
        self.status_var = tb.StringVar(value="")
        tb.Label(container, textvariable=self.status_var, bootstyle=SECONDARY).pack(anchor=W)

        self.output = tb.ScrolledText(container, height=24)
        self.output.pack(fill=BOTH, expand=True)

    def on_generate(self):
        title = self.title_var.get().strip()
        desc = self.desc_var.get().strip()
        domain = self.domain_var.get()
        num_q = self.num_q_var.get()
        avg_ci = float(self.avg_ci_var.get())
        mcq = float(self.mcq_var.get())
        sa = float(self.sa_var.get())
        tf = float(self.tf_var.get())
        total = round(mcq + sa + tf, 6)
        if not title or not desc:
            Messagebox.show_error("Please fill title and description.", "Validation")
            return
        if total != 1.0:
            Messagebox.show_error("Distribution must sum to 1.0", "Validation")
            return
        if not (0.0 <= avg_ci <= 10.0):
            Messagebox.show_error("Average complexity must be in 0.0–10.0", "Validation")
            return

        uid = self.nav.state.uid
        upass = self.nav.state.upass
        calc_ci_url = self.nav.state.calc_ci_url
        gen_quiz_url = self.nav.state.gen_quiz_url
        try:
            self.gen_btn.configure(state=DISABLED)
            self.status_var.set("Generating quiz... Please wait.")
            self.update_idletasks()
            quiz, insert_status, generation_error = generate_quiz(
                uid=uid,
                upass=upass,
                calc_ci_url=calc_ci_url,
                gen_quiz_url=gen_quiz_url,
                quiz_title=title,
                quiz_desc=desc,
                domain=domain,
                number_of_questions=int(num_q),
                question_format_distri={"mcq": mcq, "short_answer": sa, "true_false": tf},
                avg_ci_score=avg_ci,
                make_quiz_shareable=bool(self.share_quiz_var.get()),
                add_shareable_read_only=bool(self.add_share_ro_var.get()),
            )
            self.render_quiz(quiz, insert_status, generation_error)
        except Exception as e:
            Messagebox.show_error(str(e), "Generation Error")
        finally:
            self.gen_btn.configure(state=NORMAL)
            self.status_var.set("")

    def render_quiz(self, quiz_obj, insert_status, generation_error):
        self.output.delete("1.0", END)
        if not quiz_obj:
            self.output.insert("1.0", "No quiz returned.")
            return
        # Build human-readable formatted text
        text = self._format_quiz_human(quiz_obj, insert_status, generation_error)
        self.output.insert("1.0", text)

    def _format_quiz_human(self, quiz_obj, insert_status, generation_error) -> str:
        d = quiz_obj.to_dict()
        lines = []
        lines.append(f"Quiz Title: {d.get('quiz_title')}")
        lines.append(f"Description: {d.get('quiz_description')}")
        lines.append(f"Domain: {d.get('domain')}")
        lines.append(f"Avg Complexity: {d.get('avg_quiz_complexity')}")
        lines.append(f"Questions: {d.get('total_questions')}  (MCQ: {d.get('num_mcq_questions')}, Short: {d.get('num_short_answer_questions')}, T/F: {d.get('num_true_false_questions')})")
        lines.append("")
        for idx, q in enumerate(d.get('questions', []), start=1):
            lines.append(f"{idx}. [{q.get('type').upper()}] {q.get('question')}")
            if q.get('hint'):
                lines.append(f"   Hint: {q.get('hint')}")
            if q.get('allowed_time_s') is not None:
                lines.append(f"   Time: {q.get('allowed_time_s')}s   Points: {q.get('points')}")
            if q.get('ci') is not None:
                lines.append(f"   CI: {q.get('ci')}")
            qtype = q.get('type')
            if qtype == 'mcq':
                options = q.get('options') or []
                correct_indices = set(q.get('correct_indices') or [])
                for oidx, opt in enumerate(options):
                    mark = '✓' if oidx in correct_indices else ' '
                    lines.append(f"   - ({mark}) {opt.get('text')}")
                    if opt.get('explanation'):
                        lines.append(f"       exp: {opt.get('explanation')}")
            elif qtype == 'true_false':
                lines.append(f"   Answer: {q.get('correct_value')}")
                if q.get('correct_ans_explanation'):
                    lines.append(f"   Correct: {q.get('correct_ans_explanation')}")
                if q.get('incorrect_ans_explanation'):
                    lines.append(f"   Incorrect: {q.get('incorrect_ans_explanation')}")
            elif qtype == 'short_answer':
                if q.get('expected_answer'):
                    lines.append(f"   Expected: {q.get('expected_answer')}")
                if q.get('expected_ans_explanation'):
                    lines.append(f"   Explanation: {q.get('expected_ans_explanation')}")
            lines.append("")
        lines.append("---")
        lines.append(f"insert_status: {insert_status}")
        lines.append(f"generation_error: {generation_error}")
        return "\n".join(lines)


