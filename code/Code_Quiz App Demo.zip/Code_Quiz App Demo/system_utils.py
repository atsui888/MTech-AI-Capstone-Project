import os
from dotenv import load_dotenv
load_dotenv()

UID = None
UPASS = None
CALC_CI_URL = None
GEN_QUESTION_URL = None
GEN_QUIZ_URL = None

def check_login_credentials(in_name, in_pass):
    if in_name == os.getenv('DEMO_USER_NAME') and in_pass == os.getenv('DEMO_USER_PASS'):
        global UID, UPASS, CALC_CI_URL, GEN_QUESTION_URL, GEN_QUIZ_URL
        # todo: I suspect Anvil 15 second server module limit is causing many queries to return None
        # todo: It might be best in long term to move to another platform, coz upgrading to higher plan does
        # todo: not guarantee server compute times.
        UID = os.getenv('UID_3')
        UPASS = os.getenv('RAG_TABLE_NAME_3')
        CALC_CI_URL = os.getenv('PDN_CALC_CI_URL')
        GEN_QUESTION_URL = os.getenv('PDN_GEN_QUESTION_URL')
        GEN_QUIZ_URL = os.getenv('PDN_GEN_QUIZ_URL')
        return UID, UPASS, CALC_CI_URL, GEN_QUESTION_URL, GEN_QUIZ_URL
    else:
        raise ValueError(f"Invalid input name: {in_name} and password: {in_pass}")

def load_markdown_file(file_path):
    """
    Loads the content of a Markdown file into a string.

    Args:
        file_path (str): The path to the Markdown file.

    Returns:
        str: The content of the Markdown file as a string.
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            markdown_content = f.read()
        return markdown_content
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found.")
        return None
    except Exception as e:
        print(f"An error occurred while reading the file: {e}")
        return None


if __name__ == "__main__":

    markdown_file_path = "Course_Supervised_Machine_Learning.md"
    content = load_markdown_file(markdown_file_path)

    if content:
        print("Markdown file content loaded successfully:")
        print(content)