import json
import requests
from question import Question


def calculate_complexity_score(uid: str, upass: str, url: str, quest: Question, display_status=False, debug=False):
    """
    This function is used for manually triggering the calculation of the complexity score, i.e. the user needs to 
    press a button to do this. Or the code needs to specifically want to do this.
    """
    ci = CalcCerebroIndex(uid=uid, upass=upass, url=url, display_status=display_status, debug=debug)
    return ci.calc_cerebro_index(question=quest.to_dict())


class CalcCerebroIndex:
    def __init__(self, uid: str, upass: str, url: str, display_status=True, debug=False):
        self._uid = uid
        self._upass = upass
        self._url = url
        self._display_status = display_status
        self._debug = debug

    def calc_cerebro_index(self, question: dict):
        """
        Call Cerebro Index API to calculate the complexity score of the input question.
        :return: json containing complexity score and explanation.
        """
        headers = {'accept': 'application/json', 'Content-Type': 'application/json'}

        data = {
            'question_id': question.get('id'),
            'question_type': question.get('type'),
            'question_text': question.get('question'),
            'hint': question.get('hint'),
            'options': question.get('options'),
            'correct_indices': question.get('correct_indices'),
            'correct_value': question.get('correct_value'),
            'correct_ans_explanation': question.get('correct_ans_explanation'),
            'incorrect_ans_explanation': question.get('incorrect_ans_explanation'),
            'expected_answer': question.get('expected_answer'),
            'expected_ans_explanation': question.get('expected_ans_explanation'),
        }

        try:
            if self._display_status:
                print('\n************************* Debug Code: Local calc_cerebro_index.py is called!\n')

            res = requests.post(
                self._url,
                headers=headers,
                data=json.dumps(data),
                auth=(self._uid,  self._upass)
            )
            res.raise_for_status()  # Raise an exception for bad status codes
            if res is None:
                raise SystemError("calc_cerebro_index() --> res is None.")
            else:
                if self._debug:
                    print(f"\nDebug Code: Response from CI API is:\n{type(res.json())}\n{res.json()}\n\n")

                return res.json()
        except requests.exceptions.RequestException as e:
            print(f"An error occurred: {e}")
            return None
        except json.JSONDecodeError:
            print("Could not decode the JSON response.")
            return None



if __name__ == "__main__":
#     from dotenv import load_dotenv
#     import os
#     load_dotenv()
#     UID = os.getenv('UID')
#     UPASS = os.getenv('UPASS')
#
#     CALC_CI_URL = os.getenv('CALC_CI_URL')
#     calc_ci = CalcCerebroIndex(UID, UPASS, CALC_CI_URL)
#     response = calc_ci.calc_cerebro_index(r'is the sky really yellow?')
#     ci_result = response.get('result') if response else None
#     for k, v in ci_result.items():
#         print(k)
#         print(v)
#         print()

    pass
