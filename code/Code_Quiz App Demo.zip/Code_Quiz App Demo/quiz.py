import json
from question_mcq import MCQQuestion
from question_truefalse import TrueFalseQuestion
from question_shortanswer import ShortAnswerQuestion
from typing import Union
import uuid

class Quiz:
    def __init__(self, domain: str, avg_quiz_complexity: float, make_quiz_shareable_read_only:bool=False, quiz_title: Union[None,str]=None,
                 quiz_description: Union[None,str]=None, allowed_time_s: Union[None, int]=0,
                 points: Union[None,int]=0, passing_score: Union[None, float]=None,
                 quiz_id:Union[None, str, uuid]=None):

        self.shareable_read_only = make_quiz_shareable_read_only
        self.quiz_title = quiz_title
        self.quiz_description = quiz_description
        self.domain = domain
        self.avg_quiz_complexity = avg_quiz_complexity
        self.quiz_id = quiz_id if quiz_id else uuid.uuid4()
        self.allowed_time_s = allowed_time_s
        self.points = points
        self.passing_score = passing_score
        self.questions = []

        # Calculated/Updated when .add_question() is called
        self.total_questions: int = 0
        self.num_mcq_questions: int = 0
        self.num_short_answer_questions: int = 0
        self.num_true_false_questions: int = 0

    def _recalc_avg_quiz_complexity(self):
        self.avg_quiz_complexity = round(sum([q.ci for q in self.questions]) / self.total_questions, 2)

    def add_question(self, question: Union[MCQQuestion, ShortAnswerQuestion, TrueFalseQuestion]):
        self.questions.append(question)
        self.total_questions += 1
        self._recalc_avg_quiz_complexity()

        if isinstance(question, MCQQuestion):
            self.num_mcq_questions += 1
        elif isinstance(question, ShortAnswerQuestion):
            self.num_short_answer_questions += 1
        elif isinstance(question, TrueFalseQuestion):
            self.num_true_false_questions += 1
        else:
            print("Quiz->add_question: Unknown Question Format")

    def to_dict(self):
        return {
            "shareable_read_only": self.shareable_read_only,
            "quiz_id": str(self.quiz_id),
            "quiz_title": self.quiz_title,
            "quiz_description": self.quiz_description,
            "domain": self.domain,
            "avg_quiz_complexity": self.avg_quiz_complexity,
            "allowed_time_s": self.allowed_time_s,
            "points": self.points,
            "passing_score": self.passing_score,
            "total_questions": self.total_questions,
            "num_mcq_questions": self.num_mcq_questions,
            "num_short_answer_questions": self.num_short_answer_questions,
            "num_true_false_questions": self.num_true_false_questions,
            "questions": [q.to_dict() for q in self.questions]
        }


    def export_qxdf(self, filename):
        qxdf_data = {
            "shareable_read_only": self.shareable_read_only,
            "quiz_id": str(self.quiz_id),
            "quiz_title": self.quiz_title,
            "quiz_description": self.quiz_description,
            "domain": self.domain,
            "avg_quiz_complexity": self.avg_quiz_complexity,
            "allowed_time_s": self.allowed_time_s,
            "points": self.points,
            "passing_score": self.passing_score,
            "total_questions": self.total_questions,
            "num_mcq_questions": self.num_mcq_questions,
            "num_short_answer_questions": self.num_short_answer_questions,
            "num_true_false_questions": self.num_true_false_questions,
            "questions": [q.to_dict() for q in self.questions]
        }
        with open(filename, 'w') as f:
            json.dump(qxdf_data, f, indent=2)

    @classmethod
    def import_qxdf(cls, filename):

        with open(filename, 'r') as f:
            data = json.load(f)

        quiz = cls(
            domain=data.get('domain'),
            avg_quiz_complexity=data.get('avg_quiz_complexity'),
            make_quiz_shareable_read_only=data.get('shareable_read_only'),
            quiz_title=data.get('quiz_title'),
            quiz_description=data.get('quiz_description'),
            allowed_time_s=data.get('allowed_time_s'),
            points=data.get('points'),
            passing_score=data.get('passing_score'),
            quiz_id=data.get('quiz_id'))

        for q_data in data.get('questions', []):
            q_type = q_data.get('type')
            match q_type:
                case "mcq":
                    quiz.add_question(MCQQuestion.from_dict(q_data))
                case "short_answer":
                    quiz.add_question(ShortAnswerQuestion.from_dict(q_data))
                case "true_false":
                    quiz.add_question(TrueFalseQuestion.from_dict(q_data))
                case _:
                    raise SystemError(f"Error-> Question Type: {q_type} is not supported.")
        return quiz

    def display_quiz(self):
        for q in self.questions:
            print(f"ID: {q.qid}")
            print(f"Type: {q.question_type}")
            print(f"Question: {q.question_text}")
            print(f"Hint: {q.hint}")
            print(f"Allowed Time (s): {q.allowed_time_s}")
            print(f"Points: {q.points}")
            print(f"Cerebro Index: {q.ci:.2f}")
            print(f"Cerebro Index Explanation: {q.ci_explanation}")

            if isinstance(q, MCQQuestion):
                print("Options:")
                for idx, option in enumerate(q.options):
                    correct = "✓" if idx in q.correct_indices else "✗"
                    print(f"  {correct} {option['text']}")
                    print(f"     Explanation: {option['explanation']}")
            elif isinstance(q, TrueFalseQuestion):
                print(f"Correct Answer: {q.correct_value}")
                print(f"Correct Explanation: {q.correct_ans_explanation}")
                print(f"Incorrect Explanation: {q.incorrect_ans_explanation}")
            elif isinstance(q, ShortAnswerQuestion):
                print(f"Expected Answer: {q.expected_answer}")
                print(f"Explanation: {q.expected_ans_explanation}")

            print("=" * 60)

