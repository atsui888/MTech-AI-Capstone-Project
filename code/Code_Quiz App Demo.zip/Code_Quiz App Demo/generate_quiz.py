from gen_quiz import GenQuiz
from system_utils import check_login_credentials

def create_quiz(uid: str, upass: str, calc_ci_url: str, gen_quiz_url: str, quiz_title: str, quiz_desc: str, domain: str, number_of_questions: int, 
                question_format_distri: dict, avg_ci_score: float, make_quiz_shareable: bool=False,
                add_shareable_read_only:bool=True):
    supported_domains = ['math used in a supermarket', 'supervised machine learning', 'time in personal travel']
    supported_qf = ['mcq', 'short_answer', 'true_false']
    if domain not in supported_domains:
        raise SystemError({'error': f"Domain '{domain}' is not supported. Please select one of the following: {supported_domains}"})
    for key in question_format_distri.keys():
        if key not in supported_qf:
            raise SystemError({'error': f"Question Format '{key}' is not supported. Please select one of the following: {supported_qf}"})

    if GEN_QUIZ_URL:
        gen_quiz = GenQuiz(
            uid=uid,
            upass=upass,
            gen_quiz_url=gen_quiz_url,
            ci_url=calc_ci_url,
            debug=False
        )
        user_requirements = {
                'make_quiz_shareable_read_only': make_quiz_shareable,
                'quiz_title': quiz_title,
                'quiz_description': quiz_desc,
                'num_questions': number_of_questions,
                'quiz_complexity_score': avg_ci_score,
                'question_format_distribution': question_format_distri,
                'domain': domain,
                'add_shareable_read_only': add_shareable_read_only
            }
        quiz, insert_status, generation_error = gen_quiz.gen_quiz(**user_requirements)
        return quiz, insert_status, generation_error
    else:
        return {'error': 'URL for Gen Quiz is invalid.'}
    

if __name__ == "__main__":
    UID, UPASS, CALC_CI_URL, _, GEN_QUIZ_URL = check_login_credentials('demo_niu', 'demo_bi')

    response = create_quiz(uid=UID, upass=UPASS, calc_ci_url=CALC_CI_URL, gen_quiz_url=GEN_QUIZ_URL,
                           quiz_desc='my_quiz_02', quiz_title='my quiz description',
                           domain='supervised machine learning', number_of_questions=3,
                           question_format_distri={'mcq': 0.5, 'short_answer': 0.25, 'true_false': 0.25 },
                           avg_ci_score=5.0, make_quiz_shareable=False, add_shareable_read_only=False)
    # todo: anvil is slow and server module has only 15 seconds compute before it returns error.
    # todo: hence for time-being, set add_shareable_read_only=False, which avoids querying other user's data
    # todo: and avoid doing joins. But in long term, need to move away from Anvil to a faster platform
    # todo: or a platform where I can directly state for how much $ how much compute I am getting.
    # todo: or keep anvil for UI only and let supabase etc do the heavier lifting.

    if response is not None:
        QUIZ, INSERT_STATUS, GENERATION_ERROR = response
        QUIZ.display_quiz()
    else:
        print(f"Error: {response}")