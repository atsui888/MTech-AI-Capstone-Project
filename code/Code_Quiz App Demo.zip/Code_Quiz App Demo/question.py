import uuid
from abc import ABC, abstractmethod
from typing import List

class Question(ABC):
    def __init__(self, question_type: str, question_text: str, allowed_time_s: int=0, points: int=0,
                 hint:List[str]=None, qid=None):
        self.qid = qid if qid else uuid.uuid4()
        self.question_type = question_type
        self.question_text = question_text
        self.allowed_time_s = allowed_time_s
        self.points = points
        self.hint = hint

    @property
    @abstractmethod
    def ci(self):
        pass

    @property
    @abstractmethod
    def ci_explanation(self):
        pass

    @abstractmethod
    def get_ci(self):
        # get_ci() will return ci and ci_explanation
        pass

    @abstractmethod
    def to_dict(self):
        pass

    @classmethod
    @abstractmethod
    def from_dict(cls, data):
        pass






