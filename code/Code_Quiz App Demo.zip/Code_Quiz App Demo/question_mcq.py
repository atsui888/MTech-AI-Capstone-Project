import uuid
from typing import Dict, List
from question import Question


class MCQQuestion(Question):
    def __init__(self, question_text:str, options:List[Dict], correct_indices:List[int], calc_ci_obj,
                 allowed_time_s: int=None, points: int=None, hint:List[str]=None,
                 ci: float=None, ci_explanation: str=None,
                  qid=None):
        super().__init__(question_type="mcq", question_text=question_text, allowed_time_s=allowed_time_s,
                         points=points, hint=hint, qid=qid)
        self.options = options  # List of option dicts with 'text' and 'explanation for that option'
        self.correct_indices = correct_indices
        self.calc_ci_obj = calc_ci_obj
        if ci is not None and ci >= 0 and ci_explanation is not None and len(ci_explanation) > 0:
            self._ci = ci
            self._ci_explanation = ci_explanation
        else:
            self._ci = 0
            self._ci_explanation = ""
            self.get_ci()

    @property
    def ci(self):
        return self._ci

    @property
    def ci_explanation(self):
        return self._ci_explanation

    def get_ci(self):
        res = self.calc_ci_obj.calc_cerebro_index(self.to_dict())

        if not res:
            raise SystemError("res is empty.")
        else:
            res = res.get('result')
            self._ci = res.get('complexity_score')
            self._ci_explanation = res.get('explanation')

    def to_dict(self):
        return {
            "id": str(self.qid),
            "type": self.question_type,
            "question": self.question_text,
            "hint": self.hint,
            "allowed_time_s": self.allowed_time_s,
            "points": self.points,
            "ci": self._ci,
            "ci_explanation": self._ci_explanation,
            "options": self.options,
            "correct_indices": self.correct_indices,
        }

    @classmethod
    def from_dict(cls, data):
        return cls(
            qid=uuid.UUID(data['id']),
            question_text=data['question'],
            options=data['options'],
            correct_indices=data['correct_indices'],
            hint=data.get('hint', ""),
            allowed_time_s=data.get('allowed_time_s'),
            points=data.get('points'),
            ci=data.get('ci'),
            ci_explanation=data.get('ci_explanation'),
            calc_ci_obj=data.get('calc_ci_obj')
        )
