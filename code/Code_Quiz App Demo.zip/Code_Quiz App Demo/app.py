import ttkbootstrap as tb
from ttkbootstrap.constants import *
from utils.navigation import AppNavigator
from screens.login_screen import LoginScreen
from screens.dashboard_screen import DashboardScreen
from screens.question_screen import QuestionScreen
from screens.manual_question_screen import ManualQuestionScreen
from screens.quiz_screen import QuizScreen


def main():
    app = tb.Window(title="Quiz Maker Demo", themename="flatly")
    app.geometry("1600x800")  # original 1000x700

    navigator = AppNavigator(app)

    # Register screens
    navigator.register_screen("Login", LoginScreen)
    navigator.register_screen("Dashboard", DashboardScreen)
    navigator.register_screen("Question", QuestionScreen)
    navigator.register_screen("ManualQuestion", ManualQuestionScreen)
    navigator.register_screen("Quiz", QuizScreen)

    navigator.show_screen("Login")

    app.mainloop()


if __name__ == "__main__":
    main()


