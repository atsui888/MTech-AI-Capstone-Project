from typing import Tuple, Dict, Any

# Import provided functions/modules without modifying them
from system_utils import check_login_credentials as _check_login_credentials
import generate_question as _gen_question_mod
import generate_quiz as _gen_quiz_mod
from calc_cerebro_index import calculate_complexity_score as _calc_complexity


_login_ctx = {
    "uid": None,
    "upass": None,
    "calc_ci_url": None,
    "gen_question_url": None,
    "gen_quiz_url": None,
}


def set_login_context(uid: str, upass: str, calc_ci_url: str, gen_question_url: str, gen_quiz_url: str) -> None:
    _login_ctx.update(
        dict(
            uid=uid,
            upass=upass,
            calc_ci_url=calc_ci_url,
            gen_question_url=gen_question_url,
            gen_quiz_url=gen_quiz_url,
        )
    )
    # Set globals expected by provided modules (cannot modify their code)
    setattr(_gen_question_mod, "UID", uid)
    setattr(_gen_question_mod, "UPASS", upass)
    setattr(_gen_question_mod, "CALC_CI_URL", calc_ci_url)
    setattr(_gen_question_mod, "GEN_QUESTION_URL", gen_question_url)

    setattr(_gen_quiz_mod, "GEN_QUIZ_URL", gen_quiz_url)


def check_login_credentials(username: str, password: str) -> Tuple[str, str, str, str, str]:
    return _check_login_credentials(username, password)


def generate_question(domain: str, question_format: str, complexity_level: str, context: str = None, shareable_read_only: bool = False):
    if not all([_login_ctx["uid"], _login_ctx["upass"], _login_ctx["calc_ci_url"], _login_ctx["gen_question_url"]]):
        raise RuntimeError("Login context not set. Call set_login_context(...) after login.")
    return _gen_question_mod.generate_question(
        domain=domain,
        question_format=question_format,
        complexity_level=complexity_level,
        context=context,
        shareable_read_only=shareable_read_only,
    )


def generate_quiz(
    uid: str,
    upass: str,
    calc_ci_url: str,
    gen_quiz_url: str,
    quiz_title: str,
    quiz_desc: str,
    domain: str,
    number_of_questions: int,
    question_format_distri: Dict[str, float],
    avg_ci_score: float,
    make_quiz_shareable: bool = False,
    add_shareable_read_only: bool = True,
):
    # Provided module exposes create_quiz; we wrap it to match PRD name
    return _gen_quiz_mod.create_quiz(
        uid=uid,
        upass=upass,
        calc_ci_url=calc_ci_url,
        gen_quiz_url=gen_quiz_url,
        quiz_title=quiz_title,
        quiz_desc=quiz_desc,
        domain=domain,
        number_of_questions=number_of_questions,
        question_format_distri=question_format_distri,
        avg_ci_score=avg_ci_score,
        make_quiz_shareable=make_quiz_shareable,
        add_shareable_read_only=add_shareable_read_only,
    )


def calculate_complexity_score(uid: str, upass: str, url: str, quest_obj) -> Any:
    # quest_obj must be a subclass of Question from provided modules
    return _calc_complexity(uid=uid, upass=upass, url=url, quest=quest_obj)


def get_login_context() -> Dict[str, Any]:
    return dict(_login_ctx)


