import json
import requests
from quiz import Quiz
from calc_cerebro_index import CalcCerebroIndex
from qxdf_helper import generated_question_to_qxdf_object

class GenQuiz:
    def __init__(self, uid: str, upass: str, gen_quiz_url: str, ci_url: str, debug=False):
        self._uid = uid
        self._upass = upass
        self._gen_quiz_url = gen_quiz_url
        self._calc_ci = CalcCerebroIndex(self._uid, self._upass, ci_url, debug=debug)

    def gen_quiz(self, make_quiz_shareable_read_only: bool, quiz_title: str, quiz_description: str, num_questions:int,
                 quiz_complexity_score: float, question_format_distribution: dict,
                 domain: str, add_shareable_read_only: bool, timeout: int=120):
        """
        Send prompt to API to generate a quiz.

        :param quiz_description:
        :param quiz_title:
        :param make_quiz_shareable_read_only:
        :param timeout:
        :param add_shareable_read_only:
        :param domain:
        :param num_questions:
        :param quiz_complexity_score:
        :param question_format_distribution:
        :return:
        """

        headers = {'accept': 'application/json', 'Content-Type': 'application/json'}
        data = {
            'make_quiz_shareable_read_only': make_quiz_shareable_read_only,
            'quiz_title': quiz_title,
            'quiz_description': quiz_description,
            'num_questions': num_questions,
            'quiz_complexity_score': quiz_complexity_score,
            'question_format_distribution': question_format_distribution,
            'domain': domain,
            'add_shareable_read_only': add_shareable_read_only
        }

        try:
            quiz, insert_status, generation_error = None, None, None
            res = requests.post(
                self._gen_quiz_url,
                headers=headers,
                data=json.dumps(data),
                auth=(self._uid, self._upass),
                timeout=timeout
            )
            res.raise_for_status()  # Raise an exception for bad status codes

            if res:
                quiz = res.json().get('quiz')

                insert_status = res.json().get('insert_status')
                generation_error = res.json().get('generation_error')

                if generation_error:
                    if generation_error.get('status') == 'error':
                        return {'error': generation_error.get('message')}
                    else:
                        quiz = Quiz(
                            make_quiz_shareable_read_only=quiz.get('shareable_read_only'),
                            quiz_title=quiz.get('quiz_title'),
                            quiz_description=quiz.get('quiz_description'),
                            domain=quiz.get('domain'),
                            avg_quiz_complexity=quiz.get('avg_quiz_complexity'),
                            quiz_id=quiz.get('quiz_id'),
                            allowed_time_s=quiz.get('allowed_time_s'),
                            points=quiz.get('points'),
                            passing_score=quiz.get('passing_score')
                        )
                        generated_questions = res.json().get('quiz').get("questions")
                        for quest in generated_questions:
                            question = generated_question_to_qxdf_object(quest, self._calc_ci)
                            if question:
                                quiz.add_question(question)
            return quiz, insert_status, generation_error
        except requests.exceptions.RequestException as e:
            print(f"An error occurred: {e}")
            return None
        except json.JSONDecodeError:
            print("Could not decode the JSON response.")
            return None


