from gen_question import GenQuestion
from question import Question
from question_mcq import MCQQuestion
from question_shortanswer import ShortAnswerQuestion
from question_truefalse import TrueFalseQuestion
import random
import time
import matplotlib.pyplot as plt
from system_utils import check_login_credentials, load_markdown_file


def generate_question(domain: str, question_format: str, complexity_level: str, context: str=None, shareable_read_only: bool=False):
    ml_personas = ['AI Ethics Reviewer', 'AI Research Scientist', 'Algorithm Tester', 'Analytics Consultant',
                   'Applied Researcher', 'AutoML Framework Developer', 'Bootcamp Attendee', 'CEO', 'CTO',
                   'Computer Science Undergrad', 'Data Engineer', 'Junior Data Analyst', 'Kaggle Competitor',
                   'ML Architect', 'ML Book Editor', 'ML Course Instructor', 'ML Evaluator', 'ML Intern',
                   'ML Ops Engineer', 'ML Product Manager', 'ML Student', 'Machine Learning Engineer',
                   'Model Interpretability Specialist', 'Model Performance Auditor', 'New Data Scientist',
                   'Peer Reviewer in AI Journal', 'QA Tester', 'Software Engineer', 'Tech Support Rep',
                   'Technical Writer', 'Venture Capitalist Assessing ML Startups']

    communication_styles = [
            "who is factual and believes in no-nonsense communication",
            "who articulates ideas in great detail and explains concepts thoroughly",
            "who communicates with technical rigor and likes to emphasize exact specifications",
            "who speaks with energy and passion, and typically discusses ideas excitedly",
            "who communicates sparingly but meaningfully and speak only when necessary",
            "who tailors explanations to the listener and adjusts explanations for clarity",
            "who prioritizes clarity over politeness and states hard truths directly",
            "who implies feedback subtly and hints at improvements gently",
            "whose tone carries unspoken critiques and 'praises' with irony",
            "who organizes thoughts systematically and presents ideas step-by-step"]

    question_objectives = [
            'To assess if the respondent can list a set of facts, terms, or steps.',
            'To assess if the respondent can define a concept with a clear explanation or meaning.',
            'To assess if the respondent can recall previously learned information.',
            'To assess if the respondent can identify correct information or facts.',
            'To assess if the respondent can name items or concepts.',
            'To assess if the respondent can recognize previously learned content.',
            'To assess if the respondent can summarize the main ideas in a condensed version.',
            'To assess if the respondent can describe something with a detailed explanation or depiction.',
            'To assess if the respondent can interpret information by restating it in another form.',
            'To assess if the respondent can classify items by grouping them based on shared characteristics.',
            'To assess if the respondent can explain a clarification by showing relationships and reasoning.',
            'To assess if the respondent can paraphrase by rewriting text in their own words.',
            'To assess if the respondent can use knowledge by applying it correctly to a new situation.',
            'To assess if the respondent can implement a plan or procedure.',
            'To assess if the respondent can execute a process or method.',
            'To assess if the respondent can carry out a task by following instructions.',
            'To assess if the respondent can solve a problem or calculation.',
            'To assess if the respondent can demonstrate a practical or visual proof of understanding.',
            'To assess if the respondent can compare similarities and differences.',
            'To assess if the respondent can contrast with a detailed explanation of differences.',
            'To assess if the respondent can differentiate between similar concepts.',
            'To assess if the respondent can organize components into a structured arrangement.',
            'To assess if the respondent can deconstruct by breaking down parts and their relationships.',
            'To assess if the respondent can attribute by identifying a cause or category.',
            'To assess if the respondent can judge something based on defined criteria.',
            'To assess if the respondent can critique with a detailed analysis of strengths and weaknesses.',
            'To assess if the respondent can argue a position supported with reasoning.',
            'To assess if the respondent can defend a justification with evidence.',
            'To assess if the respondent can support an evidence-based reasoning or conclusion.',
            'To assess if the respondent can assess a measured judgment with criteria.',
            'To assess if the respondent can design a new plan, product, or solution.',
            'To assess if the respondent can construct an assembled or built artifact.',
            'To assess if the respondent can develop a newly formed idea, model, or framework.',
            'To assess if the respondent can formulate an original hypothesis, theory, or plan.',
            'To assess if the respondent can invent a novel idea, tool, or method.',
            'To assess if the respondent can generate an original work or outcome.']

    max_retries = 3
    retry_attempt = 0
    persona = f"a {random.choice(ml_personas)} {random.choice(communication_styles)}"
    qxdf_question = None
    
    while retry_attempt < max_retries:
        if GEN_QUESTION_URL:
            gen_question = GenQuestion(
                uid=UID,
                upass=UPASS,
                gen_quest_url=GEN_QUESTION_URL,
                ci_url=CALC_CI_URL,
                debug=True
            )
            response = gen_question.generate_question(
                question_format=question_format,
                complexity_level=complexity_level,
                domain=domain,
                question_purpose=random.choice(question_objectives),
                shareable_read_only=shareable_read_only,
                user_provided_persona=persona + " and does NOT use the words 'according to the document' or similar words at the beginning or end of the question ",
                user_provided_question_content=context,
                timeout=60
            )
        
            if response is None or (isinstance(response, dict) and response.get('error') is not None):
                if response.get('error') is None:
                    print(f"Error: response from API Server is either None or invalid. "
                          f"\nWill retry until max limit of {max_retries}.")
                else:
                    print(f"Error: '{response.get('error')}'. Will retry until max limit of {max_retries}.")
                retry_attempt += 1
                if retry_attempt > max_retries:
                    raise SystemError("Error: Max Retry Threshold breach!")
                print(f"\nError: ******** Response from Server is None. Retry Attempt: {retry_attempt}. *******\n")
            else:
                qxdf_question, insert_status = response
                if not qxdf_question:
                    raise SystemError("None is received from API.")
                retry_attempt = max_retries + 1
        else:
            raise SystemError('GEN_QUESTION_URL is None or not found.')
        time.sleep(10)

    return qxdf_question


def display_question_in_terminal(quest: Question):
    print(f"Question ID: {quest.qid}")
    print(f"Question Format: {quest.question_type}")
    print(f"Question: {quest.question_text}")
    print(f"Hint: {quest.hint}")
    print(f"Allowed Time (s): {quest.allowed_time_s}")
    print(f"Points: {quest.points}\n")
    
    if isinstance(quest, MCQQuestion):
        print("Options:")
        for idx, option in enumerate(quest.options):
            correct = "✓" if idx in quest.correct_indices else "✗"
            print(f"  {correct} {option['text']}")
            print(f"     Explanation: {option['explanation']}")
    elif isinstance(quest, TrueFalseQuestion):
        print(f"Correct Answer: {quest.correct_value}")
        print(f"Correct Explanation: {quest.correct_ans_explanation}")
        print(f"Incorrect Explanation: {quest.incorrect_ans_explanation}")
    elif isinstance(quest, ShortAnswerQuestion):
        print(f"Expected Answer: {quest.expected_answer}")
        print(f"Explanation: {quest.expected_ans_explanation}")
    print('='*80)
    
    print(f"\nCerebro Index Score: {quest.ci:.2f}")
    explain = quest.ci_explanation
    print(f"\nCerebro Index Explanation: {explain.keys()}")
    print()
    component_to_name = {'bltx': "bloom's taxonomy", 'amb': "ambiguity", 
                          'infd': "information density", 'stc': "syntactic complexity", 
                          'cic': "conceptual interconnectedness", 'gs': "guessing susceptibility"}
    ci_components = ['bltx', 'amb', 'infd', 'stc', 'cic', 'gs']
    print(f"CI Component Scores: {explain.get('component_scores')}\n")
    for component in ci_components:
        print(f"{str(component_to_name.get(component)).capitalize()} --->")
        comp = explain.get(component)
        print(f"Overall Summary: {comp.get('overall_summary')}")
        print("\nCriteria Explanation:")
        if isinstance(comp.get('criteria_explanations'), dict):
            for k, v in comp.get('criteria_explanations').items():
                print(f"{k}: {v}")
        else:
            print(comp.get('criteria_explanations'))
        print("\nCriteria Scores:")
        if isinstance(comp.get('criteria_scores'), dict):
            for k, v in comp.get('criteria_scores').items():
                print(f"{k}: {v}")
        else:
            print(comp.get('criteria_scores'))
        print('='*80)


def create_ci_contribution_chart(quest: Question):
    """
    Creates a bar chart to show the breakdown of a score calculation
    from a single sample of data.
    """
    data = quest.to_dict().get('ci_explanation').get('component_scores')
    
    # Calculate the components of the formula
    term1_contribution = (4/3) * data['bltx']
    term2_contribution = (1/8) * (data['amb'] * data['cic'] * data['infd'] * data['stc'])

    # Calculate the final score
    ci_score = (term1_contribution + term2_contribution) * data['gs']

    # Final contributions after multiplying by F
    final_term1_contribution = term1_contribution * data['gs']
    final_term2_contribution = term2_contribution * data['gs']

    # Prepare data for the bar chart
    labels = ['Contribution from BLTX', 'Contribution from AMB, CIC, INFD, STC', 'CI Score']
    values = [final_term1_contribution, final_term2_contribution, ci_score]

    # Create the bar chart using Matplotlib
    fig, ax = plt.subplots(figsize=(10, 6))

    bars = ax.bar(labels, values, color=['#1E90FF', '#FF8C00', '#32CD32']) # Dodger Blue, Dark Orange, Lime Green

    # Add text labels on top of the bars
    for bar in bars:
        height = bar.get_height()
        ax.annotate(f'{height:.2f}',
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 3),  # 3 points vertical offset
                    textcoords="offset points",
                    ha='center', va='bottom',
                    fontsize=12)

    # Add title and labels
    ax.set_title('Score Breakdown: Contributions to Final Score', fontsize=16, fontweight='bold')
    ax.set_xlabel('Components', fontsize=12)
    ax.set_ylabel('Value', fontsize=12)
    ax.set_ylim(0, max(values) * 1.2) # Set y-axis limit for better spacing

    # Remove top and right spines
    ax.spines['right'].set_visible(False)
    ax.spines['top'].set_visible(False)

    plt.tight_layout()
    plt.savefig('score_breakdown_bar_chart.png')

    return fig, round(ci_score, 2), data


if __name__ == "__main__":
    UID, UPASS, CALC_CI_URL, GEN_QUESTION_URL, GEN_QUIZ_URL = check_login_credentials('demo_niu', 'demo_bi')

    markdown_file_path = "Course_Supervised_Machine_Learning.md"
    CONTEXT = load_markdown_file(markdown_file_path)
    
    DOMAIN = 'supervised machine learning'
    # question_formats = ["mcq", "short_answer", "true_false"]
    QUESTION_FORMAT = "mcq"
    # complexity_levels = ["very easy", "easy", "moderate", "challenging", "very challenging"]
    COMPLEXITY_LEVEL = "very easy"
    QUESTION = generate_question(domain=DOMAIN, question_format=QUESTION_FORMAT, complexity_level=COMPLEXITY_LEVEL,
                                 context=CONTEXT, shareable_read_only=True)
    display_question_in_terminal(QUESTION)
    FIG, FINAL_SCORE, COMPONENT_SCORES =create_ci_contribution_chart(QUESTION)
    plt.show()
    print(f"Final Score: {FINAL_SCORE}")
    print(f"Component Scores: {COMPONENT_SCORES}")


