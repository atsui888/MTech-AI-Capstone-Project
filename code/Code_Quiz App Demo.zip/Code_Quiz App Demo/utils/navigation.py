import ttkbootstrap as tb


class AppState:
    def __init__(self):
        self.uid = None
        self.upass = None
        self.calc_ci_url = None
        self.gen_question_url = None
        self.gen_quiz_url = None


class AppNavigator:
    def __init__(self, root: tb.Window):
        self.root = root
        self.frames = {}
        self.state = AppState()

    def register_screen(self, name: str, frame_cls):
        frame = frame_cls(self.root, self)
        self.frames[name] = frame

    def show_screen(self, name: str):
        frame = self.frames.get(name)
        if frame is None:
            return
        for f in self.frames.values():
            f.pack_forget()
        frame.pack(fill="both", expand=True)


