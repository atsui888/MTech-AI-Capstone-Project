from typing import Union
from question_truefalse import TrueFalseQuestion
from question_mcq import MCQQuestion
from question_shortanswer import ShortAnswerQuestion

def generated_question_to_qxdf_object(quest: dict, calc_ci_obj) ->(
        Union)[TrueFalseQuestion, MCQQuestion, ShortAnswerQuestion, None]:
    q_type = quest.get('type')
    match q_type:
        case 'true_false':
            return TrueFalseQuestion(
                question_text=quest.get('question'),
                correct_value=quest.get("correct_value"),
                correct_ans_explanation=quest.get("correct_ans_explanation"),
                incorrect_ans_explanation=quest.get("incorrect_ans_explanation"),
                allowed_time_s=quest.get("allowed_time_s"),
                points=quest.get("points"),
                hint=quest.get("hint"),
                ci=quest.get("ci"),
                ci_explanation=quest.get("ci_explanation"),
                calc_ci_obj=calc_ci_obj,
                qid=quest.get("qid"))
        case 'mcq':
            return MCQQuestion(
                question_text=quest.get('question'),
                options=quest.get("options"),
                correct_indices=quest.get("correct_indices"),
                allowed_time_s=quest.get("allowed_time_s"),
                points=quest.get("points"),
                hint=quest.get('hint'),
                ci=quest.get('ci'),
                ci_explanation=quest.get('ci_explanation'),
                calc_ci_obj=calc_ci_obj,
                qid=quest.get('qid')
            )
        case "short_answer":
            return ShortAnswerQuestion(
                question_text=quest.get("question"),
                expected_answer=quest.get("expected_answer"),
                expected_ans_explanation=quest.get("expected_ans_explanation"),
                allowed_time_s=quest.get("allowed_time_s"),
                points=quest.get("points"),
                hint=quest.get("hint"),
                ci=quest.get("ci"),
                ci_explanation=quest.get("ci_explanation"),
                calc_ci_obj=calc_ci_obj,
                qid=quest.get("qid")
            )
        case '_':
            raise SystemError("Unknown Question Type")
    return None