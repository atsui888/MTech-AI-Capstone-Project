
from pathlib import Path

def load_markdown_file(path_file: Path, debug: bool=False) -> str:
    if debug:
        print(path_file )

    try:
        with open(path_file , "r", encoding="utf-8") as md_file:
            return md_file.read()
    except FileNotFoundError:
        print(f"Error: The file '{path_file}' was not found.")
    except Exception as e:
        print(f"An error occurred: {e}")


if __name__ == "__main__":
    cwd = Path.cwd()
    file_name = "Singapore Skills Framework for Training and Adult Education.md"
    PATH_FILE = cwd / file_name

    MARKDOWN_CONTENTS = load_markdown_file(PATH_FILE, debug=True)
    print(f"\nMarkdown Contents:\n{MARKDOWN_CONTENTS}")
