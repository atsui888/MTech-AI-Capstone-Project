import uuid
from abc import ABC, abstractmethod
from typing import List

class Question(ABC):
    def __init__(self, question_type: str, question_text: str, allowed_time_s: int=0, points: int=0,
                 hint:List[str]=None, qid=None):
        """
        This class represents the core attributes of a Question. It focuses only on properties essential to the
        question itself, such as its type, text, time limit, points, hint, and identifier.

        Metadata like creator or creation time, while important, are considered
        outside the direct scope of a question and should be managed separately.

        :param question_type: The category or format of the question (e.g., multiple choice, true/false).
        :param question_text: The text or content of the question.
        :param allowed_time_s: The maximum time allowed to answer, in seconds.
        :param points: The score value assigned to the question.
        :param hint: An optional clue or aid for answering the question.
        :param qid: A unique identifier for the question.
        """
        self.qid = qid if qid else uuid.uuid4()
        self.question_type = question_type
        self.question_text = question_text
        self.allowed_time_s = allowed_time_s
        self.points = points
        self.hint = hint

    @property
    @abstractmethod
    def ci(self):
        pass

    @property
    @abstractmethod
    def ci_explanation(self):
        pass

    @abstractmethod
    def get_ci(self):
        # get_ci() will return ci and ci_explanation
        pass

    @abstractmethod
    def to_dict(self):
        pass

    @classmethod
    @abstractmethod
    def from_dict(cls, data):
        pass






