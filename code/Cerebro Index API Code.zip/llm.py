# llm.py

"""
Pricing
=======

OpenAI:
. Models: https://platform.openai.com/docs/models
. Pricing: https://platform.openai.com/docs/pricing
    gpt-4.1:        Input USD 2 per mil, Output USD 8 per mil (gpt-4.1-2025-04-14)
    gpt-4.1-mini:   Input USD 0.4 per mil, Output USD 1.60 per mil (gpt-4.1-mini-2025-04-14)
    gpt-4.1-nano:   Input USD 0.10 per mil, Output USD 0.40 per mil (gpt-4.1-nano-2025-04-14)

Google Gemini Developer API
Pricing: https://ai.google.dev/gemini-api/docs/pricing
    Gemini 2.5 Pro Preview: Input USD 1.25 to 2.5 per mil, Output: Think-> USD 10 to 15 per mil
    Gemini 2.5 Flash Preview: Input USD 0.15 per mil, Output: Think-> USD 3.5 per mil, Non-Think-> USD 0.6 per mil
    Gemini 2.0 Flash-Lite: Input USD 0.075 per mil, Output: USD 0.3 per mil
    RC: take note: Gemini Pro is expensive!!

DeepSeek:
. https://platform.deepseek.com/usage
. Models and Price: https://api-docs.deepseek.com/quick_start/pricing/
    deepseek-chat: Input USD 0.27 per mil, Output: USD 1.1 per mil
    deepseek-reasoner: Input USD 0.55 per mil, Output: USD 2.19 per mil


Alibaba Qwen:
. Models and Prices: https://www.alibabacloud.com/help/en/model-studio/models
    Qwen-Max: Input: USD 1.6 per million, Output: USD6.4 per million
    Qwen-Plus: Input: USD 0.4 per million, Output: USD 1.2 per million
    Qwen-Turbo: Input: USD USD0.05 per million, Output: Think-> USD 1 per mil, Non-Think-> USD 0.2 per mil

. Currently, enabled models for "Cerebro Index" workspace:
    Turbo: "qwen-turbo", "qwen-turbo-2025-04-28", "qwen-turbo-latest"
        - "qwen-turbo-2025-04-28" # 1 million free tokens for 180 days
    Plus: 'qwen-plus-2025-04-28'  # 1 million free tokens for 180 days
    Max: 'qwen-max-2025-01-25'  # 1 million free tokens for 180 days, als for qwen-max-latest (not enabled yet)

    for now, I should try to stick to "qwen-turbo-2025-04-28" and use 'qwen-plus-2025-04-28' if turbo isn't enough


"""

"""
Structured Mode
===============
Alibaba Qwen
Structured Mode (json)
https://www.alibabacloud.com/help/en/model-studio/json-mode?spm=a2c63.p38356.help-menu-2400256.d_0_1_5.2cae3fd9B0nXVa
Supported models:
    The structured output feature supports the following models:
        Qwen-Max series
            qwen-max, qwen-max-latest, qwen-max-0125
        Qwen-Plus series (non-thinking mode)
            qwen-plus-2025-01-25 and later        
        Qwen-Turbo series (non-thinking mode)
            qwen-turbo-2024-11-01 and later
        Open source Qwen
            qwen3 (non-thinking), qwen2.5

"""


# import uuid
from abc import ABC, abstractmethod
from typing import Union, Dict
# from openai import OpenAI  # DeepSeek also uses the openai package
from openai import AsyncOpenAI  # DeepSeek also uses the openai package
import dashscope
from dashscope.aigc.generation import AioGeneration  # for dashscope Async
from google import genai
from google.genai import types
# import json
# from google.genai.types import GenerateContentConfig, HttpOptions

# from pydantic import BaseModel
# import asyncio

class LLM(ABC):
    @property
    @abstractmethod
    def model_name(self):
        pass

    @abstractmethod
    def ask_llm(self, **kwargs):
        pass

    @abstractmethod
    def _model_args(self):
        # temperature, top_p, top_k, truncation etc
        pass

    @abstractmethod
    def _tokens_used(self):
        pass


class OpenAILLM(LLM):
    # https://github.com/openai/openai-python
    # https://milvus.io/ai-quick-reference/how-do-i-call-openais-api-asynchronously-in-python
    def __init__(self, api_key: str, model: str):
        # self._client = OpenAI(api_key=api_key)
        self._client = AsyncOpenAI(api_key=api_key)
        self._model_name = model
        self._response = None
        self._response_dict = None

    @property
    def model_name(self):
        return self._model_name

    def _model_args(self):
        if self._response_dict:
            return {
                'model': self._response_dict.get('model'),
                'max_output_tokens': self._response_dict.get('max_output_tokens'),
                'truncation': self._response_dict.get('truncation'),
                'instructions': self._response_dict.get('instructions'),
                'temperature': self._response_dict.get('temperature'),
                'top_p': self._response_dict.get('top_p'),
                'tools': self._response_dict.get('tools'),
                'tool_choice': self._response_dict.get('tool_choice')
            }
        return None

    async def ask_llm(self, messages: list, temperature=0.0, response_format=None, stream=False) \
            -> Union[None, Dict, Exception]:
        if response_format is None:
            response_format = dict(type='json_object')

        try:
            self._response = await self._client.chat.completions.create(
                model=self._model_name,
                messages=messages,
                temperature=temperature,
                stream=stream,
                response_format=response_format
            )
            if self._response:
                self._response_dict = self._response.to_dict()
                if self._response_dict.get('choices')[0].get('finish_reason').lower() == 'length':
                    return {'error': "output truncated as it exceeds 'max_tokens' or 'max context' length."}
                else:
                    return {
                        'completion': self._response_dict.get('choices')[0].get('message').get('content'),
                        'model_args': self._model_args(),
                        'usage': self._tokens_used()
                    }
        except Exception as e:
            return e
        return None

    def _tokens_used(self):
        if self._response_dict:
            return {
                'total_tokens': self._response_dict.get("usage").get('total_tokens'),
                'input_tokens': self._response_dict.get("usage").get("prompt_tokens"),
                'cached_tokens': self._response_dict.get("usage").get('prompt_tokens_details').get('cached_tokens'),
                'prompt_cache_hit_tokens': self._response_dict.get("usage").get('prompt_tokens_details').get(
                    'prompt_cache_hit_tokens'),
                'prompt_cache_miss_tokens': self._response_dict.get("usage").get('prompt_tokens_details').get(
                    'prompt_cache_miss_tokens'),
                'output_tokens': self._response_dict.get("usage").get("completion_tokens"),
            }
        return None


class DeepSeekLLM(LLM):
    # https://api-docs.deepseek.com/
    # https://api-docs.deepseek.com/guides/json_mode
    def __init__(self, api_key: str, model: str, base_url: str=r"https://api.deepseek.com"):
        # self._client = OpenAI(api_key=api_key, base_url=base_url)
        self._client = AsyncOpenAI(api_key=api_key, base_url=base_url)
        self._model_name = model
        self._response = None
        self._response_dict = None

    @property
    def model_name(self):
        return self._model_name

    def list_models(self):
        return self._client.models.list()

    def _model_args(self):
        if self._response_dict:
            return {
                'model': self._response_dict.get('model'),
                # 'max_output_tokens': self._response_dict('max_output_tokens'),
                # 'truncation': self._response_dict('truncation'),
                # 'instructions': self._response_dict('instructions'),
                # 'temperature': self._response_dict('temperature'),
                # 'top_p': self._response_dict('top_p'),
                # 'tools': self._response_dict('tools'),
                # 'tool_choice': self._response_dict('tool_choice')
            }
        return None

    async def ask_llm(self, messages: list, temperature: float=0.0, response_format=None, stream=False) \
            -> Union[None, Dict, Exception]:
        if response_format is None:
            response_format = dict(type='json_object')

        try:
            self._response = await self._client.chat.completions.create(
                model=self._model_name,
                messages=messages,
                temperature=temperature,
                stream=stream,
                response_format=response_format
            )
            if self._response:
                self._response_dict = self._response.to_dict()
                if self._response_dict.get('choices')[0].get('finish_reason').lower() == 'length':
                    return {'error': "output truncated as it exceeds 'max_tokens' or 'max context' length."}
                else:
                    return {
                        'completion': self._response_dict.get('choices')[0].get('message').get('content'),
                        'model_args': self._model_args(),
                        'usage': self._tokens_used()
                    }
        except Exception as e:
            return e
        return None

    def _tokens_used(self):
        if self._response_dict:
            return {
                'total_tokens': self._response_dict.get("usage").get('total_tokens'),
                'input_tokens': self._response_dict.get("usage").get("prompt_tokens"),
                'cached_tokens': self._response_dict.get("usage").get('prompt_tokens_details').get('cached_tokens'),
                'prompt_cache_hit_tokens': self._response_dict.get("usage").get('prompt_tokens_details').get(
                    'prompt_cache_hit_tokens'),
                'prompt_cache_miss_tokens': self._response_dict.get("usage").get('prompt_tokens_details').get(
                    'prompt_cache_miss_tokens'),
                'output_tokens': self._response_dict.get("usage").get("completion_tokens"),
            }
        return None


# todo: This version is being deprecated, use or migrate to llm_alibaba_qwen_async.py instead
class AlibabaModelStudioLLM(LLM):
    # https://www.alibabacloud.com/help/en/model-studio/what-is-model-studio
    # https://www.alibabacloud.com/help/en/model-studio/text-generation  #  Async Invocation
    def __init__(self, api_key: str, model: str='qwen-turbo',
                 base_url: str=r'https://dashscope-intl.aliyuncs.com/api/v1'):

        # using DashScope API and not OpenAI Compatible API
        dashscope.base_http_api_url = base_url

        self._api_key = api_key
        self._model_name = model
        self._response = None
        # self._response_dict = None

    @property
    def model_name(self):
        return self._model_name

    def _model_args(self):
        # this method may not be useful... remove from base class?
        return {
            'model': self._model_name,
            # 'max_output_tokens': self._response_dict('max_output_tokens'),
            # 'truncation': self._response_dict('truncation'),
            # 'instructions': self._response_dict('instructions'),
            # 'temperature': self._response_dict('temperature'),
            # 'top_p': self._response_dict('top_p'),
            # 'tools': self._response_dict('tools'),
            # 'tool_choice': self._response_dict('tool_choice')
        }


    async def ask_llm(self, messages: list, temperature: float=0.0, response_format=None,
                stream=False) -> Union[None, Dict, Exception]:
        if response_format is None:
            response_format = dict(type='json_object')

        try:
            # self._response = dashscope.Generation.call(  # non-async version
            self._response = await AioGeneration.call(
                api_key=self._api_key,
                model=self._model_name,
                messages=messages,
                result_format='message',
                response_format=response_format,
                temperature=temperature,
                stream=stream
            )

            # todo: debug code
            print('\n\n', '=' * 100)
            # print(type(result))
            print(self._response)
            print("Is error msg saying something about a get??")
            print('\n\n', '=' * 100)

            if self._response:  # todo: should the retry up to 3 times be here?
                if self._response.get('output').get('choices')[0].get('finish_reason') == 'length':
                    return {'error': "output truncated as it exceeds 'max_tokens' or 'max context' length."}
                else:
                    return {
                        'completion': self._response.get('output').get('choices')[0].get('message').get('content'),
                        'model_args': self._model_args(),
                        'usage': self._tokens_used()
                    }
        except Exception as e:
            return e
        return None

    def _tokens_used(self):
        if self._response:
            return {
                'total_tokens': self._response.get('usage').get('total_tokens'),
                'input_tokens': self._response.get('usage').get('input_tokens'),
                'cached_tokens': 'unknown',
                'prompt_cache_hit_tokens': 'unknown',
                'prompt_cache_miss_tokens': 'unknown',
                'output_tokens': self._response.get('usage').get('output_tokens'),
            }
        return None


class GoogleGeminiLLM(LLM):
    # https://ai.google.dev/gemini-api/docs/structured-output
    # https://ai.google.dev/gemini-api/docs/pricing
    # https://ai.google.dev/gemini-api/docs/text-generation
    # https://chatgpt.com/c/684392bf-1534-800e-865c-94345e82ef97 (maybe works for Async ??)
    def __init__(self, api_key: str, model: str):
        # self._client = genai.Client(api_key=api_key)  # non-async version
        self._client = genai.Client(api_key=api_key, http_options=types.HttpOptions(api_version="v1"))  # async
        self._model_name = model
        self._response = None
        # self._response_dict = None

    @property
    def model_name(self):
        return self._model_name

    def _model_args(self):
        if self._response:
            return {
                'model': self._response.model_version,
                'max_output_tokens': 'unknown',
                'truncation': 'unknown',
                'instructions': 'unknown',
                'temperature': 'unknown',
                'top_p': 'unknown',
                'tools': 'unknown',
                'tool_choice': 'unknown'
            }
        return None

    async def ask_llm(self, messages: list) \
            -> Union[None, Dict, Exception]:
        try:
            # self._response = await self._client.models.generate_content(  # non-async
            self._response = await self._client.aio.models.generate_content(  # async
                model=self._model_name,
                contents=messages
                # config=types.GenerateContentConfig(
                #     response_mime_type= response_format,
                #     response_schema=response_schema)
            )
            if self._response:
                if self._response.candidates[0].finish_reason != 'STOP':
                    return {'error': "output is probably truncated as it exceeds 'max_tokens' or 'max context' length."}
                else:
                    return {
                        'completion': self._response.text.removeprefix("```json\n").removesuffix("```"),
                        'model_args': self._model_args(),
                        'usage': self._tokens_used()
                    }
        except Exception as e:
            return e
        return None

    def _tokens_used(self):
        if self._response:
            return {
                'total_tokens': self._response.usage_metadata.total_token_count,
                'input_tokens': self._response.usage_metadata.prompt_token_count,
                'cached_tokens': 'unknown',
                'prompt_cache_hit_tokens': 'unknown',
                'prompt_cache_miss_tokens': 'unknown',
                'output_tokens': self._response.usage_metadata.candidates_token_count
            }
        return None


