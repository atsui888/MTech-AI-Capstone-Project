from pydantic import BaseModel  #, ConfigDict
from question_truefalse import TrueFalseQuestion
from question_mcq import MCQQuestion
from question_shortanswer import ShortAnswerQuestion
from serverside_calc_cerebro_index import CalcCerebroIndex
import time
import random
from api_helper import get_uniqueness_token, safe_json_loads
from typing import Union
from gen_quest_prompt load_prompt


class QuestionPromptInput(BaseModel):
    question_format: str
    complexity_level: str
    domain: str
    question_purpose: str
    shareable_read_only: bool
    user_provided_persona: None | str = None
    user_provided_question_content: None | str = None


class QuestionPromptResponse(BaseModel):
    # has to be dict and not a pydantic class coz I need the flexibility in returns
    # coz the fields for T/F, MCQ and SA are different. Unless I can think of a more elegant solution.
    generated_question: Union[None, dict]
    insert_status: Union[None, dict]
    generation_error: Union[None, dict]

async def generate_question_from_prompt(input_args: QuestionPromptInput, llm_model, response_format='json',
                                        reprompt=True, display_status=True, debug=False) -> dict:
    """

    :param display_status:
    :param reprompt: if reprompt, error msg is appended in new prompt
    :param response_format:
    :param llm_model:
    :param input_args:
    :param debug:
    :return:
    """


    if display_status:
        print("START ------> Generating 1 Question ******************")

    
    # thresholds, limits, constraints
    calc_ci = CalcCerebroIndex(llm=llm_model, response_format=response_format, debug=False)
    try_num = 1
    max_tries = 5

    gen_q_from_llm = {}

    request_delay_seconds = 0.5
    generated_question = None
    question_valid = None

    gen_input_tokens = 0
    gen_output_tokens = 0
    gen_total_tokens = 0

    # mcq
    min_mcq_question_len = 10
    min_mcq_hint_len = 10
    min_mcq_number_of_options = 2
    min_mcq_number_of_correct_indices = 1

    # true/false
    min_tf_question_len = 10
    min_tf_hint_len = 10
    min_correct_ans_explanation_len = 10
    min_incorrect_ans_explanation_len = 10

    # short answer
    min_short_answer_question_len = 10
    min_short_answer_hint_len = 10
    min_short_answer_expected_answer_len = 1
    min_short_answer_expected_ans_explanation_len = 10

    llm_error = None

    msgs = [{"role": "user", "content": load_prompt()}]
    count_chars = lambda x: sum([len(ele) for ele in x])
    while try_num < max_tries:
        question_valid = True
        completion_errors = ""

        if display_status:
            print(f"\nGenerate 1 Question --> Try Number: {try_num}\n***********************")

        result = await llm_model.ask_llm(messages=msgs, response_format=response_format, temperature=0.2)

        # todo: remove next line after testing
        # print('='*100)
        # print()
        # print(type(result))
        # print(result)
        # print()
        # print(f"Checking the usage: {result.get('usage').get('total_tokens')}")
        # print(result.get('usage').get('input_tokens'), result.get('usage').get('output_tokens'))
        # print('=' * 100)

        # I think no need for "if result:" test, coz valid_question: bool will handle it.

        token_usage = result.get('usage')  # this is not a json string
        if token_usage:
            gen_input_tokens += token_usage.get('input_tokens')
            gen_output_tokens += token_usage.get('output_tokens')
            gen_total_tokens += token_usage.get('total_tokens')
            if debug:
                print(f"\ngen_quest_input_tokens: {gen_input_tokens}")
                print(f"gen_quest_output_tokens: {gen_output_tokens}")
                print(f"gen_quest_total_tokens: {gen_total_tokens}\n")

        # result.get('completion') is a json string
        completion = safe_json_loads(result.get('completion')) if result else None
        if completion:
            llm_error = result.get('error')
            if completion.get('type'):
                gen_q_from_llm['type'] = completion.get('type')
            if completion.get('question'):
                gen_q_from_llm['question'] = completion.get('question')
            if completion.get('hint'):
                gen_q_from_llm['hint'] = completion.get('hint')
            if completion.get('options'):
                gen_q_from_llm['options'] = completion.get('options')
            if completion.get('correct_indices'):
                gen_q_from_llm['correct_indices'] = completion.get('correct_indices')
            if completion.get('correct_answer'):
                tmp = completion.get('correct_answer')
                if isinstance(tmp, bool):
                    gen_q_from_llm['correct_value'] = tmp
                elif isinstance(tmp, str):
                    gen_q_from_llm['correct_value'] = True if tmp.lower().strip() in ["true", "yes"] else False
                elif isinstance(tmp, (int, float)):
                    gen_q_from_llm['correct_value'] = True if tmp > 0 else False
                else:
                    gen_q_from_llm['correct_value'] = None
            if completion.get('correct_answer_explanation'):
                gen_q_from_llm['correct_ans_explanation'] = completion.get('correct_answer_explanation')
            if completion.get('incorrect_answer_explanation'):
                gen_q_from_llm['incorrect_ans_explanation'] = completion.get('incorrect_answer_explanation')
            if completion.get('expected_answer'):
                gen_q_from_llm['expected_answer'] = completion.get('expected_answer')
            if completion.get('expected_ans_explanation'):
                gen_q_from_llm['expected_ans_explanation'] = completion.get('expected_ans_explanation')

            if debug:
                print(f"DEBUG\ntype(gen_q_from_llm): {type(gen_q_from_llm)}\ngen_q_from_llm: {gen_q_from_llm}\n")

            # ************************ 2. Create the Question Object ************************
            # Common for all question formats
            if gen_q_from_llm.get('type') not in supported_question_formats:
                completion_errors += (f"Error: Only the following question formats are supported: [{supported_question_formats}]. "
                                      f"Please only generate these types of questions. ")
                question_valid = False

            if gen_q_from_llm.get('question') is None:
                completion_errors += "Error: You did not generate any question at all. "
                question_valid = False
            if gen_q_from_llm.get('hint') is None:
                completion_errors += "Error: You did not provide any hint for the question. "
                question_valid = False

            # Specific to Question Format
            if gen_q_from_llm.get('type') == "mcq":
                if len(gen_q_from_llm.get('question')) < min_mcq_question_len:
                    completion_errors += (f"Error: A MCQ question needs to have a minimum length "
                                          f"of {min_mcq_question_len} characters. ")
                    question_valid = False
                if gen_q_from_llm.get('hint') is None or count_chars(gen_q_from_llm.get('hint')) < min_mcq_hint_len:
                    completion_errors += (f"Error: A hint for a MCQ question needs to have a minimum length "
                                          f"of {min_mcq_hint_len} characters. ")
                    question_valid = False
                if (gen_q_from_llm.get('options') is None or
                        not isinstance(gen_q_from_llm.get('options'), list) or
                                       len(gen_q_from_llm.get('options')) < min_mcq_number_of_options):
                    completion_errors += (f"Error: A MCQ question needs to provide at "
                                          f"least {min_mcq_number_of_options} options. ")
                    question_valid = False
                if (gen_q_from_llm.get('correct_indices') is None or
                        not isinstance(gen_q_from_llm.get('correct_indices'), list) or
                        len(completion.get('correct_indices')) < min_mcq_number_of_correct_indices):
                    completion_errors += (f"Error: A MCQ question needs to have at "
                                          f"least {min_mcq_number_of_correct_indices} correct answer. ")
                    question_valid = False

            elif gen_q_from_llm.get('type') == "true_false":
                if len(gen_q_from_llm.get('question')) < min_tf_question_len:
                    completion_errors += (f"Error: A True or False Question needs to have a minimum length "
                                          f"of {min_tf_question_len} characters. ")
                    question_valid = False
                if gen_q_from_llm.get('hint') is None or count_chars(gen_q_from_llm.get('hint')) < min_tf_hint_len:
                    completion_errors += (f"Error: A hint for a True or False Question needs to have a minimum length "
                                          f"of {min_tf_hint_len} characters. ")
                    question_valid = False

                if (gen_q_from_llm.get('correct_value') is None or
                        not isinstance(gen_q_from_llm.get('correct_value'), bool)):
                    completion_errors += f'Error: The field "correct_answer" must contain a boolean value, either true or false. '
                    question_valid = False
                if (gen_q_from_llm.get('correct_ans_explanation') is None or
                        len(gen_q_from_llm.get('correct_ans_explanation')) < min_correct_ans_explanation_len):
                    completion_errors += (f'Error: "correct_answer_explanation" must have at least '
                                          f'{min_correct_ans_explanation_len} characters.')
                    question_valid = False
                if (gen_q_from_llm.get('incorrect_ans_explanation') is None or
                        len(gen_q_from_llm.get('incorrect_ans_explanation')) < min_incorrect_ans_explanation_len):
                    completion_errors += (f'Error: "incorrect_answer_explanation" must have at least '
                                          f'{min_incorrect_ans_explanation_len} characters.')
                    question_valid = False

            elif gen_q_from_llm.get('type') == "short_answer":
                if len(gen_q_from_llm.get('question')) < min_short_answer_question_len:
                    completion_errors += (f"Error: A Short Answer Question needs to have at least "
                                          f"of {min_short_answer_question_len} characters. ")
                    question_valid = False
                if gen_q_from_llm.get('hint') is None or count_chars(gen_q_from_llm.get('hint')) < min_short_answer_hint_len:
                    completion_errors += (f"Error: A hint for a Short Answer Question needs to have a minimum length "
                                          f"of {min_short_answer_hint_len} characters. ")
                    question_valid = False
                if (gen_q_from_llm.get('expected_answer') is None or
                        len(gen_q_from_llm.get('expected_answer')) < min_short_answer_expected_answer_len):
                    completion_errors += (f"Error: The answer to the question must have at least "
                                          f"{min_short_answer_expected_answer_len} characters. ")
                    question_valid = False
                if (gen_q_from_llm.get('expected_ans_explanation') is None or
                        len(gen_q_from_llm.get('expected_ans_explanation')) < min_short_answer_expected_ans_explanation_len):
                    completion_errors += (f"Error: The explanation for the expected answer must have at least "
                                          f"{min_short_answer_expected_ans_explanation_len} characters. ")
                    question_valid = False
            else:
                completion_errors += "Error: Please check your answer again. "
                question_valid = False

        if question_valid:
            try_num = max_tries
        else:
            if reprompt:
                msgs.append({"role": "assistant", "content": gen_q_from_llm})
                msgs.append({"role": "user", "content": completion_errors + " Please correct for these errors and "
                                                                            "regenerate the question."})

            if debug:
                print("\nMessages:")
                for msg in msgs:
                    print(f"{msg.get('role')}:")
                    print(f"{msg.get('content')}\n")
                print()
            time.sleep(request_delay_seconds)
            try_num += 1
        if display_status:
            print(f"\nGenerate 1 Question --> End Try Number ***********************\n")

    if question_valid:
        if gen_q_from_llm.get('type') == "mcq":
            generated_question = MCQQuestion(
                question_text=gen_q_from_llm.get('question'),
                options=gen_q_from_llm.get('options'),
                correct_indices=gen_q_from_llm.get('correct_indices'),
                allowed_time_s=-888,
                points=-888,
                hint=gen_q_from_llm.get('hint'),
                ci=None,
                ci_explanation=None,
                calc_ci_obj=calc_ci,
                qid=None)
            await generated_question.initialize_ci()
        elif gen_q_from_llm.get('type') == "true_false":
            generated_question = TrueFalseQuestion(
                    question_text=gen_q_from_llm.get('question'),
                    correct_value=gen_q_from_llm.get('correct_value'),
                    correct_ans_explanation=gen_q_from_llm.get('correct_ans_explanation'),
                    incorrect_ans_explanation=gen_q_from_llm.get('incorrect_ans_explanation'),
                    allowed_time_s=-888,
                    points=-888,
                    hint=gen_q_from_llm.get('hint'),
                    ci=None,
                    ci_explanation=None,
                    calc_ci_obj=calc_ci,
                    qid=None)
            await generated_question.initialize_ci()
        elif gen_q_from_llm.get('type') == "short_answer":
            generated_question = ShortAnswerQuestion(
                question_text=gen_q_from_llm.get('question'),
                expected_answer=gen_q_from_llm.get('expected_answer'),
                expected_ans_explanation=gen_q_from_llm.get('expected_ans_explanation'),
                allowed_time_s=-888,
                points=-888,
                hint=gen_q_from_llm.get('hint'),
                ci=None,
                ci_explanation=None,
                calc_ci_obj=calc_ci,
                qid=None)
            await generated_question.initialize_ci()
        else:
            return {"error": "Unsupported Question Format."}

    if debug:
        print(f"\nSending this Generated Question back to main.py:\n{generated_question.to_dict()}\n")

    if display_status:
        print("END ------> Generating 1 Question ******************\n")

    question_dict = generated_question.to_dict()

    # add tokens used for "generate question ONLY". NB: CI Components have their own token usage.
    if debug:
        print(f"\ngen_quest_input_tokens: {gen_input_tokens}")
        print(f"gen_quest_output_tokens: {gen_output_tokens}")
        print(f"gen_quest_total_tokens: {gen_total_tokens}\n")

    question_dict["prompt_persona"] = persona

    question_dict["gen_quest_token_usage"] = {
        "gen_quest_input_tokens": gen_input_tokens,
        "gen_quest_output_tokens": gen_output_tokens,
        "gen_quest_total_tokens": gen_total_tokens
    }

    question_dict["generation_error"] = llm_error

    question_dict["prompt_used"] = prompt
    return question_dict


