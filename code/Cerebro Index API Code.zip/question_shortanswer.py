import uuid
from typing import List
from question import Question


class ShortAnswerQuestion(Question):
    def __init__(self, question_text:str, expected_answer: str, expected_ans_explanation: str, calc_ci_obj,
                 allowed_time_s: int=None, points: int=None, hint:List[str]=None,
                 ci: float=None, ci_explanation: str=None,
                  qid=None):
        super().__init__(question_type="short_answer", question_text=question_text,
                         allowed_time_s=allowed_time_s, points=points, hint=hint, qid=qid)
        self.expected_answer = expected_answer
        self.expected_ans_explanation = expected_ans_explanation

        self.calc_ci_obj = calc_ci_obj
        self._ci = ci
        self._ci_explanation = ci_explanation

    async def initialize_ci(self):
        if (self._ci is None or self._ci < 0 or
                self._ci_explanation is None or len(self._ci_explanation) < 5):
            await self.get_ci()  # Call the async method to get CI

    @property
    def ci(self):
        return self._ci

    @property
    def ci_explanation(self):
        return self._ci_explanation

    async def get_ci(self):
        res = await self.calc_ci_obj.calc_cerebro_index(question=self.to_dict())

        if not res:
            raise SystemError("res is empty.")
        elif not isinstance(res, dict):
            # todo: find out why sometimes a <class 'AttributeError'> is received here, instead of a dict
            raise SystemError(f"res should be a dict, instead it is a {type(res)}")
        else:
            res = res.get('result')
            self._ci = res.get('complexity_score')

            rationale = {
                'component_scores': res.get('component_scores'),
                'bltx': res.get('bltx'),
                'amb': res.get('amb'),
                'infd': res.get('infd'),
                'stc': res.get('stc'),
                'cic': res.get('cic'),
                'gs': res.get('gs'),
                'total_tokens': res.get('total_tokens'),
                'input_tokens': res.get('input_tokens'),
                'output_tokens': res.get('output_tokens')
            }
            self._ci_explanation = rationale

    def to_dict(self):
        return {
            "id": str(self.qid),
            "type": self.question_type,
            "question": self.question_text,
            "hint": self.hint,
            "allowed_time_s": self.allowed_time_s,
            "points": self.points,
            "ci": self._ci,
            "ci_explanation": self._ci_explanation,
            "expected_answer": self.expected_answer,
            "expected_ans_explanation": self.expected_ans_explanation
        }

    @classmethod
    def from_dict(cls, data):
        return cls(
            qid=uuid.UUID(data['id']),
            question_text=data['question'],
            hint=data.get('hint', ""),
            allowed_time_s=data.get('allowed_time_s'),
            points=data.get('points'),
            ci=data.get('ci'),
            ci_explanation=data.get('ci_explanation'),
            calc_ci_obj=data.get('calc_ci_obj'),
            expected_answer=data.get('expected_answer'),
            expected_ans_explanation=data.get('expected_ans_explanation')
        )
