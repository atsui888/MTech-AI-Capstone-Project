from pydantic import BaseModel

from input_models import QuestionInput
from output_models import EvaluationOutput
import asyncio
import math
from typing import List, Union
import time
from api_helper import safe_json_loads
from gs_prompt import load_distract_prompt, load_duplicate_prompt, load_ans_leak_prompt

# This route classifies the Guessing Susceptibility (GS) of a given question.
class GSResponse(BaseModel):
    result: EvaluationOutput


async def check_question_format(question: QuestionInput, display_status=True) -> EvaluationOutput:
    """
    # Step 1 - Question Format
    Because Respondent can only choose answer ONCE, then response options like "all of the above", "none of the above",
    "_ and _ are correct" or other variants can be treated as just like any other unique option.
    The effect on probability of guessing the correct answer is impacted only if the respondent is allowed to make a
    second attempt at choosing the correct answer. We assume that like most if not all assessment, the respondent
    can answer a question once only.

    This function determines what are the number of options and the number of correct options a question has.
    It does not determine if they are good options or not, nor weather to decrement them.

    :param display_status:
    :param question: the question
    :return:
    """
    if display_status:
        print("START ------> GS: check_question_format ******************")

    set_gs_to_zero = False
    num_options = 0
    num_correct_options = 0
    explanation = ''

    if question.question_type == 'mcq':
        if question.options is not None and isinstance(question.options, list):
            num_options = len(question.options)
            explanation += f'GS-Question Format: {num_options} Options detected. '
            if num_options <= 1:
                explanation += "MCQ question cannot have less than 2 options for respondent to select. "
                set_gs_to_zero = True
        else:
            num_options = None  # flag that something is wrong
            explanation += 'GS-Question Format Error: Unable to detect the Number of Question Options. '
            set_gs_to_zero = True

        if question.correct_indices is not None and isinstance(question.correct_indices, list):
            num_correct_options = len(question.correct_indices)
            explanation += f'GS-Question Format: {num_correct_options} Correct Options detected. '
            if num_correct_options < 1:
                explanation += "MCQ Question must at least have 1 correct option. "
                set_gs_to_zero = True
        else:
            num_correct_options = None  # flag that something is wrong
            explanation += 'Error: Unable to detect the Number of Correct Options. '
            set_gs_to_zero = True

        if num_options <= num_correct_options:
            explanation += ("GS-Question Format Error: 'Number of Options' cannot be less than or equal "
                            "to the 'Number of Correct Answers'. ")
            set_gs_to_zero = True

    if display_status:
        print("END ------> GS: check_question_format ******************\n")

    return EvaluationOutput(
        question=question.model_dump(),
        eval_type="GS_Question_Format",
        score=None,
        explanation="<Check Question Format> to determine 'number of options' and 'number of correct options'.",
        details={
            'num_options': num_options, # None means something is wrong with the question.
            'num_correct_options': num_correct_options,  # None means something is wrong with the question.
            'explanation': explanation,
            'set_gs_to_zero': set_gs_to_zero
        }
    )



def check_distractor_len(distractor: str, correct_answers: Union[str, List[str]], threshold: float=0.4) -> dict:
    # 5: at least shorter by threshold pct, 0: within bounds, 5: at least longer by threshold pct
    distractor_len = len(distractor)
    if isinstance(correct_answers, list):
        tmp = 0
        for item in correct_answers:
            tmp += len(item)
        correct_answers_avg_len = tmp / len(correct_answers)
    else:
        correct_answers_avg_len = len(correct_answers)

    threshold_range = threshold * correct_answers_avg_len
    upper_bound = correct_answers_avg_len + threshold_range
    lower_bound = correct_answers_avg_len - threshold_range
    if distractor_len > upper_bound:
        return {"length": f"The distractor is at least {threshold * 100}% longer than the correct answer.",
                "score": 5}

    elif distractor_len < lower_bound:
        return {"length": f"The distractor is at least {threshold * 100}% shorter than the correct answer.",
                "score": 5}
    else:
        return {"length": f"Length of the distractor is within (+-){threshold * 100}% of correct answer.",
                "score": 0}


async def check_distractor_quality(question: QuestionInput, llm_model, response_format,
                                   display_status=True, debug=False) -> Union[EvaluationOutput, dict]:
    """

    This function determines whether to increase, decrease or do nothing to 'num_options' and 'num_correct_options'
    The actual inc/dec is not done here.

    A distractor is weak (not plausible) if it meets one or more of the following conditions:
    a. Does not have strong semantic relationship to the domain the question stem is about OR
    b. Does not have grammatical consistency when combined with the stem OR
    c. The word count of the distractor is 40% more than the correct answer's word count OR
    d. The word count of the distractor is 40% less than the correct answer's word count OR

    If it is a weak distractor, reduce number of options by 1
    nb: This Step focuses on the distractors and not the correct answer i.e.
        - the items in question.options that is not the correct option

    :param display_status:
    :param question:
    :param llm_model:
    :param response_format:
    :param debug:
    :return:
    """

    if display_status:
        print("START ------> GS: check_distractor_quality ******************")

    if question.options is None:
        return EvaluationOutput(
            question=question.model_dump(),
            eval_type="ci_gs_check_distractor_quality",
            score=0.0,
            explanation="Checks each distractor to determine if they are good or poor.",
            details={
                'explanation': "GS->Check Distractor Quality Error: There must be at least 1 Question Option.",
                'num_options_inc_dec': None,
                'num_correct_options_inc_dec': None
            }
        )

    if question.correct_indices is None:
        return EvaluationOutput(
            question=question.model_dump(),
            eval_type="ci_gs_check_distractor_quality",
            score=0.0,
            explanation="Checks each distractor to determine if they are good or poor.",
            details={
                'explanation': "GS->Check Distractor Quality Error: There must be at least 1 correct answer.",
                'num_options_inc_dec': None,
                'num_correct_options_inc_dec': None
            }
        )

    correct_answers_lst = []
    for i in question.correct_indices:
        correct_answers_lst.append(question.options[i]['text'])
    # correct_answers_txt = ', '.join(correct_answers_lst)

    question_options = []
    for opt in question.options:
        opt_text = opt['text']
        if opt_text not in correct_answers_lst:
            question_options.append(opt_text)
    question_options_txt = ', '.join(question_options)

    explanation = ''
    llm_error = 'None'
   
    try_num = 1
    max_tries = 5  # 4
    num_options_inc_dec = 0
    input_tokens = 0
    total_tokens = 0
    output_tokens = 0

    if debug:
        print(f"\nBefore Check Distractor Quality, num_options_inc_dec is: {num_options_inc_dec}")

    while try_num < max_tries:
        if display_status:
            print(f"\nCheck Distractor Quality --> Try Number: {try_num}\n************************")

        msgs = [{"role": "user", "content": load_distract_prompt()}]
        result = await llm_model.ask_llm(messages=msgs, response_format=response_format)

        # todo: debug code
        # print('\n\n', '='*100)
        # # print(type(result))
        # print(result)
        # print('\n\n', '=' * 100)

        completion = safe_json_loads(result.get('completion')) if result else None
        if completion:
            llm_error = result.get('error')
            # completion = json.loads(result.get('completion'))
            if debug:
                print(f"\ndebug\n{type(completion)}\n{completion}\n\n")
                print(f"completion.get(question_options[0]): {completion.get(question_options[0])}")
                print(completion.get(question_options[0]).get('semantic_irrelevance'), '\n\n')

            try:
                if completion.get(question_options[0]).get('semantic_irrelevance') is not None:
                    # Calculate and add in the Length Criteria (length of distractor vs Correct Answer: too long or short)
                    for k in [k for k in completion.keys()]:
                        breach = check_distractor_len(k, correct_answers_lst, 0.4)
                        # print(breach)
                        completion[k]['length'] = breach.get('length')
                        completion[k]['length_score'] = breach.get('score')
                    # if debug:
                    #     print(f"\ndebug\n{type(completion)}\n{completion}\n\n\n")

                    # now we calc num_options_inc_dec and num_correct_options_inc_dec
                    for k, v in completion.items():
                        semantic_irrelevance_score = v.get('semantic_irrelevance_score')
                        grammatical_inconsistency_score = v.get('grammatical_inconsistency_score')
                        length_score = v.get('length_score')
                        # if debug:
                        #     print(f"{k} -->")
                        #     print(f"Semantic Irrelevance: {v.get('criteria').get('semantic_irrelevance')}")
                        #     print(f"Score: {semantic_irrelevance_score}")
                        #     print(f"Grammatical Inconsistency: {v.get('criteria').get('grammatical_inconsistency')}")
                        #     print(f"Score: {grammatical_inconsistency_score}")
                        #     print(f"Length: {v.get('criteria').get('length')}")
                        #     print(f"Score: {length_score}")
                        #     print(f"{semantic_irrelevance_score} -- {grammatical_inconsistency_score} -- {length_score}")

                        total_score = semantic_irrelevance_score + grammatical_inconsistency_score + length_score
                        # if semantic_irrelevance_score == 5 or grammatical_inconsistency_score == 5 or length_score == 5:
                        if total_score > 10:  # 5 + 5 + 1 = 11
                            num_options_inc_dec -= 1
                            explanation += (f"For the option '{k}', as at least two of the three criteria is scored '5', "
                                         f"num_options_inc_dec -= 1 because {v}| ")
                            if debug:
                                print(explanation.removesuffix('| '), '\n')

                    usage = result.get('usage')
                    input_tokens += usage.get('input_tokens')
                    output_tokens += usage.get('output_tokens')
                    total_tokens += usage.get('total_tokens')
                    if debug:
                        print(f"\ninput_tokens: {input_tokens}")
                        print(f"output_tokens: {output_tokens}")
                        print(f"total_tokens: {total_tokens}")

                    try_num = max_tries
            except Exception as e:
                print(e)
                print(f"Error Occurred, Retrying again.")
        time.sleep(1)
        try_num += 1
        if display_status:
            print(f"\nCheck Distractor Quality --> End Try ************************\n")

    if debug:
        print(f"\nAfter Checking Distractor Quality, the Final num_options_inc_dec is: {num_options_inc_dec}")

    if display_status:
        print("END ------> GS: check_distractor_quality ******************\n")

    return EvaluationOutput(
            question=question.model_dump(),
            eval_type="gs_check_distractor_quality",
            score=None,
            explanation="Checks each option (that is not the correct answer) to determine if it is a "
                        "strong or weak distractor.",
            details={
                'num_options_inc_dec': num_options_inc_dec,
                'num_correct_options_inc_dec': None,  # the focus is on distractors, not correct answers
                'explanation': explanation.removesuffix('| ').strip(),
                'token_usage': {
                    'total_tokens': total_tokens,
                    'input_tokens': input_tokens,
                    'output_tokens': output_tokens
                },
                'llm_error': llm_error,
            }
        )


async def check_duplicate_options(question: QuestionInput, llm_model, response_format,
                                  display_status=True, debug=False) -> Union[EvaluationOutput, dict]:
    """
    Regardless of whether correct answer or distractor, all of them should not be either word-for-word duplicates
    nor semantically duplicates of each other. Hence, we check all options.

    This function determines whether to increase, decrease or do nothing to 'num_options' and 'num_correct_options'
    The actual inc/dec is not done here.

    :param display_status:
    :param question:
    :param llm_model:
    :param response_format:
    :param debug:
    :return:
    """

    if display_status:
        print("START ------> GS: check_duplicate_options ******************")

    explanation = ''

    # A. Check for Exact Duplicates
    options_to_check = list(set([opt['text'].lower() for opt in question.options]))
    exact_duplicates = {}

    for item in options_to_check:
        exact_duplicates[item] = exact_duplicates.get(item, -1) + 1

    num_options_inc_dec = 0
    if debug:
        print(f"\nBefore checking for 'exact duplicates', num_options_inc_dec: {num_options_inc_dec}.")
    for v in exact_duplicates.values():
        if v > 0:
            num_options_inc_dec -= v

    if num_options_inc_dec != 0:
        explanation += f"Exact Duplicates in the options were detected, num_options_inc_dec is {num_options_inc_dec} | "

    if debug:
        print(f"After checking for 'exact duplicates', num_options_inc_dec: {num_options_inc_dec}.")

    # B. Check for Semantic Duplicates
    if debug:
        print(f"\nBefore checking for 'Semantic Duplicates', num_options_inc_dec: {num_options_inc_dec}.")

    llm_error = 'None'
    try_num = 1
    max_tries = 5
    input_tokens = 0
    total_tokens = 0
    output_tokens = 0
    while try_num < max_tries:
        if display_status:
            print(f"\nCheck Duplicate Options --> Try Number: {try_num}\n************************")

        msgs = [{"role": "user", "content": load_duplicate_prompt()}]
        result = await llm_model.ask_llm(messages=msgs, response_format=response_format)

        completion = safe_json_loads(result.get('completion')) if result else None
        if completion:
            llm_error = result.get('error')
            # completion = json.loads(result.get('completion'))
            # if debug:
            #     print(f"\ndebug\n{type(completion)}\n{completion}\n")

            # next line checks if the LLM returned an empty json
            if completion.get(options_to_check[0]).get('explanation') is not None:

                # if debug:
                #     print(f"Currently, num_options_inc_dec is: {num_options_inc_dec}.\n")
                #     print(f"\nAI Model Completion:\n{type(completion)}\n{completion}\n\n\n")

                semantic_dups = {}
                for k, v in completion.items():
                    semantic_dups[k] = v.get('semantic_duplicates', [])

                if debug:
                    for k, v in semantic_dups.items():
                        print(f"'{k}': semantic duplicates detected -->\n\t{v}")

                count_of_semantic_dups = []
                # algorithm to avoid double-counting
                for k, v in semantic_dups.items():
                    if len(v) > 0 and v[0].lower() != 'none':
                        count_of_semantic_dups.append(len(v))
                        explanation += f"Semantic Duplicates '{k}': {v} | "
                if len(count_of_semantic_dups) > 0:
                    opt_adjust = int(round(-1 * (sum(count_of_semantic_dups) / len(count_of_semantic_dups)), 0))
                else:
                    opt_adjust = 0

                # if debug:
                #     print(f"\nAfter checking for Semantic Duplicates, amount to adjust "
                #           f"num_options_inc_dec: {opt_adjust}")

                num_options_inc_dec += opt_adjust

                if debug:
                    print(f"\nAfter checking for Semantic Duplicates, num_options_inc_dec is: {num_options_inc_dec}\n")

                usage = result.get('usage')
                input_tokens += usage.get('input_tokens')
                output_tokens += usage.get('output_tokens')
                total_tokens += usage.get('total_tokens')
                if debug:
                    print(f"input_tokens: {input_tokens}")
                    print(f"output_tokens: {output_tokens}")
                    print(f"total_tokens: {total_tokens}")
                try_num = max_tries
        time.sleep(1)
        try_num += 1
        if display_status:
            print(f"\nCheck Duplicate Options --> End Try ************************\n")

    if debug:
        print("END GS--> Check Duplicate Options.")

    explanation.removeprefix('| ').strip()

    if display_status:
        print("END ------> GS: check_duplicate_options ******************\n")

    return EvaluationOutput(
        question=question.model_dump(),
        eval_type="gs_check_duplicate_options",
        score=None,
        explanation="Check the options for Exact or Semantic Similarity. Options should ideally not be similar to each other.",
        details={
            'num_options_inc_dec': num_options_inc_dec,
            'num_correct_options_inc_dec': None,
            'token_usage': {
                'total_tokens': total_tokens,
                'input_tokens': input_tokens,
                'output_tokens': output_tokens
            },
            'llm_error': llm_error,
            'explanation': explanation.removesuffix('| ').strip()
        }
    )


async def check_answer_leakage_unified(question: QuestionInput, llm_model, response_format, persona=None,
                                   display_status:bool =True, strict_detection:bool =False,
                                       debug:bool =False) -> Union[EvaluationOutput, dict]:
    """
    This function if answer leakage exists. If it does, set_gs_to_zero = True.

    :param strict_detection: If False, even subtle answer leakage will be flagged and GS set to 0.
                            So be sure that you really want to be this strict.
    :param display_status:
    :param persona:
    :param question:
    :param llm_model:
    :param response_format:
    :param debug:
    :return:
    """

    if strict_detection:
        answer_leakage_threshold = 3
    else:
        answer_leakage_threshold = 5


    if display_status:
        print("START ------> GS: check_answer_leakage_UNIFIED ******************")

    if debug:
        print(f"strict_detection: {strict_detection} | answer_leakage_threshold --> {answer_leakage_threshold}")

    set_gs_to_zero = False
    explanation = ''

    question_text = question.question_text
    question_format = question.question_type
    if question_format == "mcq":
        question_options = [i['text'] for i in question.options]
        correct_answers = [question.options[i]['text'] for i in question.correct_indices]
        question_to_analyse = (f"The MCQ question is: {question_text}. The options that the "
                               f"respondent can choose from are {question_options}. "
                               f"The correct answer/s is {correct_answers}.")
    elif question_format == "short_answer":
        question_to_analyse = f"The short answer question is: {question_text}."
    elif question_format=="true_false":
        # correct_value = question.correct_value
        question_to_analyse = f"The true or false question is: {question_text}."
    else:
        error = "GS-> Check Answer Leakage: Unknown Question Format."
        print(error)
        return EvaluationOutput(
            question=question.model_dump(),
            eval_type="gs_check_answer_leakage_unified",
            score=None,
            explanation="Answer Leakage Detection: Answer leakage occurs when by looking at the question stem it is "
                        "extremely obvious to guess the correct answer(s) without actually knowing the subject matter.",
            details={
                'num_options_inc_dec': None,  # Not relevant for this fn, which checks correct options only.
                'num_correct_options_inc_dec': None,  # Not used, coz if answer leak detected, GS is 100%.
                'token_usage': {
                    'total_tokens': 0,
                    'input_tokens': 0,
                    'output_tokens': 0
                },
                'llm_error': error,
                'explanation': error,
                'set_gs_to_zero': True
            }
        )

    llm_error = 'None'
    try_num = 1
    max_tries = 5
    # num_correct_options_inc_dec = 0
    input_tokens = 0
    total_tokens = 0
    output_tokens = 0
    while try_num < max_tries:
        if display_status:
            print(f"\nCheck Answer Leakage UNIFIED --> Try Number: {try_num}\n***********************")

        msgs = [{"role": "user", "content": load_ans_leak_prompt()}]
        result = await llm_model.ask_llm(messages=msgs, response_format=response_format)

        if debug:
            print('\n', '*' * 100)
            print(f"Answer Leakage Result:\n{result}")
            print('*' * 100, '\n')

        completion = safe_json_loads(result.get('completion')) if result else None
        if completion:
            llm_error = result.get('error')
            if debug:
                print(f"\nBefore checking 'Answer Leakage', "
                      f"set_gs_to_zero = {set_gs_to_zero}.")

            # Objective: Was answer leakage detected? Explanation?
            answer_leakage_score = completion.get('answer_leakage', 0)
            if answer_leakage_score >= answer_leakage_threshold:
                set_gs_to_zero = True
                explanation += f"'Answer Leakage' detected, hence set_gs_to_zero is True. "
                explanation += f"Reason: {completion.get('explanation')} | "
            elif answer_leakage_score == 0:
                set_gs_to_zero = True
                err_msg = "Error in Answer Leakage Detection Component. | "
                explanation += err_msg
                llm_error += err_msg
            else:
                explanation += "No Answer Leakage detected. "
                explanation += f"Reason: {completion.get('explanation')} | "

                if debug:
                    print(f"After checking 'Answer Leakage', "
                          f"set_gs_to_zero = {set_gs_to_zero}.\n")

            usage = result.get('usage')
            input_tokens += usage.get('input_tokens')
            output_tokens += usage.get('output_tokens')
            total_tokens += usage.get('total_tokens')
            if debug:
                print(f"input_tokens: {input_tokens}")
                print(f"output_tokens: {output_tokens}")
                print(f"total_tokens: {total_tokens}")

            try_num = max_tries
        time.sleep(1)
        try_num += 1
        if display_status:
            print(f"\nCheck Answer Leakage UNIFIED --> End Try ***********************\n")

    if display_status:
        print("END ------> GS: check_answer_leakage_UNIFIED ******************")

    if debug:
        print()
        print('*'*100)
        print(f"\nExplanation: {explanation.removesuffix('| ').strip()}\n")
        print('*' * 100)

    if llm_error and isinstance(llm_error, str):
        llm_error.removesuffix('| ').strip()

    return EvaluationOutput(
        question=question.model_dump(),
        eval_type="gs_check_answer_leakage_unified",
        score=None,
        explanation="Answer Leakage Detection: Answer leakage occurs when by looking at the question stem it is "
                    "extremely obvious to guess the correct answer(s) without actually knowing the subject matter.",
        details={
            'num_options_inc_dec': None,  # Not relevant for this fn, which checks correct options only.
            'num_correct_options_inc_dec': None,  # Not used, coz if answer leak detected, GS is 100%.
            'token_usage': {
                'total_tokens': total_tokens,
                'input_tokens': input_tokens,
                'output_tokens': output_tokens
            },
            'llm_error': llm_error,
            'explanation': explanation.removesuffix('| ').strip(),
            'set_gs_to_zero': set_gs_to_zero
        }
    )


async def analyse_guessing_susceptibility(question: QuestionInput, llm_model, response_format='json',
                                          answer_leakage_strict_detection: bool=False,
                                          display_status=True, debug=False) -> Union[EvaluationOutput, dict]:
    """

    :param answer_leakage_strict_detection:
    :param question:
    :param llm_model:
    :param response_format:
    :param display_status:
    :param debug:
    :return:
    """

    if display_status:
        print("START ------> Guessing Susceptibility (GS) ******************")

    num_options = 0
    num_correct_options = 0
    gs = None
    input_tokens = 0
    output_tokens = 0
    total_tokens = 0
    gs_llm_error = ''
    overall_summary = ''
    criteria_explanations = {}
    criteria_scores = {}

    if question.question_type == 'short_answer':
        gs = 1.0
        overall_summary = 'Short Answer Questions do not provide options, hence by default Guessing Susceptibility '
        overall_summary += "Factor (GS) is 1.0. But if Answer Leakage is detected, GS will be set to 0.0."

        res = await check_answer_leakage_unified(question, llm_model=llm_model, response_format=response_format,
                                     strict_detection= answer_leakage_strict_detection, debug=False)
        #todo: remove debug line
        # print("\n\n", "*"*100)
        # print(type(res))
        # print(res)
        # print("*" * 100, "\n\n")

        if res:
            set_gs_to_zero = res.details.get('set_gs_to_zero', False)
            if set_gs_to_zero:
                gs = 0.0

            criteria_explanations = res.details.get('explanation')
            criteria_scores = None  # this line is needed coz criteria_scores was inited as {}, now we want it as None.

            token_usage = res.details.get('token_usage')
            if token_usage:
                input_tokens += token_usage.get('input_tokens')
                output_tokens += token_usage.get('output_tokens')
                total_tokens += token_usage.get('total_tokens')

    elif question.question_type == 'true_false':
        # num_options = 2, um_correct_options = 1
        gs = 0.5  # 1 = (1/2) = 0.5
        overall_summary = ("True/False questions essentially have two options, one of which is correct. Hence, "
                       "by default, Guessing Susceptibility Factor (GS) is 0.5. ")

        res = await check_answer_leakage_unified(question, llm_model=llm_model, response_format=response_format,
                                                 strict_detection= answer_leakage_strict_detection,
                                                 debug=False)

        # todo: remove debug line
        # print("\n\n", "*"*100)
        # print(type(res))
        # print(res)
        # print("*" * 100, "\n\n")

        if res:
            set_gs_to_zero = res.details.get('set_gs_to_zero', False)
            if set_gs_to_zero:
                gs = 0.0

            criteria_explanations = res.details.get('explanation')
            criteria_scores = None  # this line is needed coz criteria_scores was inited as {}, now we want it as None.

            token_usage = res.details.get('token_usage')
            if token_usage:
                input_tokens += token_usage.get('input_tokens')
                output_tokens += token_usage.get('output_tokens')
                total_tokens += token_usage.get('total_tokens')

    elif question.question_type == 'mcq':
        """
        . check_question_format(question) -> detects the number of options, and correct options
        . check_distractor_quality(), check_duplicate_options(), check_answer_leakage() increment/decrement
        num_options and num_correct_options. (mostly decrement)
        
        Example for a standard 4 option MCQ Question:
        a. check_question_format() -> num_options = 4, num_correct_options = 1
        b. after running the 3 other checking functions, assuming we get the following results:
            num_options_inc_dec = -2
            num_correct_options_inc_dec = 0
        c. Then
            num_options = 4 -1 = 3
            num_correct_options = 1 - 0 = 1
            GS (guessing susceptibility) = 1 - (num_correct_options / num_options)
                                         = 1 - (1/3)
                                         = 1 - 0.3333
                                         = 0.67 nb (standard 4 option valid mcq has a GS of 0.75)
        d. Assuming CI is scored as 8, then revised CI is:
            8 * GS = 8 * 0.67 = 5.36
            interpretation:
            A MCQ question with a CI of 8 is actually a 5.35 because there were issues with the question
            that made it easy for the respondent to guess the answer.  
            The 'ideal' GS is 1.0, so that CI * GS = CI * 1 = CI.
            i.e. it is not easy for the respondent to simply randomly guess the correct answer.
        """

        # only check_question_format() shd set the initial num_options and num_correct_options
        cqf_result = await check_question_format(question)
        if cqf_result.details.get('num_options') is not None:
            num_options = cqf_result.details.get('num_options')
        if cqf_result.details.get('num_correct_options') is not None:
            num_correct_options = cqf_result.details.get('num_correct_options')
        if debug:
            print()
            print('='*80)
            print("Check Question Format")
            print(f"num options: {num_options} | num correct options: {num_correct_options}")

        criteria_explanations['question_format'] = cqf_result.details.get('explanation')

        criteria_scores['question_format'] = {
            'num_options': num_options,
            'num_correct_options': num_correct_options,
            'set_gs_to_zero': cqf_result.details.get('set_gs_to_zero')
        }
        overall_summary += (f"After checking Question Format, num options: {num_options} and num correct "
                        f"options: {num_correct_options}. | ")

        tasks = [
            check_distractor_quality(question, llm_model=llm_model, response_format=response_format, debug=False),
            check_duplicate_options(question, llm_model=llm_model, response_format=response_format, debug=False),
            check_answer_leakage_unified(question, llm_model=llm_model, response_format=response_format,
                                         strict_detection= answer_leakage_strict_detection, debug=False)
        ]
        results = await asyncio.gather(*tasks)
        set_gs_to_zero = False
        if results:
            if debug:
                print('\n\n', '='*50, ' Going through Results ', '='*25)
            for r in results:  # add tokens used by each of the checking process
                temp_criteria_explanations = {}
                temp_criteria_scores = {}
                if debug:
                    print('*'*30, f" {r.eval_type} ",'*'*30)
                    print(f"explanation: {r.explanation}")
                    print(f"score: {r.score}")
                    for k, v in r.details.items():
                        print(f"{k}\t-> {v}")
                    print()

                overall_summary += f"Eval Type: {r.eval_type}-> "

                if r.details.get('error'):
                    print('*' * 50, r.get('error'), '*' * 50)
                    gs_llm_error += r.get('error')
                    # raise SystemError(f"Error getting Completions from AI Model:\n{r.get('error')}")

                if r.details.get('token_usage').get('input_tokens') is not None:
                    input_tokens += r.details.get('token_usage').get('input_tokens')

                if r.details.get('token_usage').get('output_tokens') is not None:
                    output_tokens += r.details.get('token_usage').get('output_tokens')
                if r.details.get('token_usage').get('total_tokens') is not None:
                    total_tokens += r.details.get('token_usage').get('total_tokens')

                if r.details.get('explanation') is not None:
                    temp_criteria_explanations = r.details.get('explanation')

                # next two are modifiers of 'num_options' and 'num_correct_options'
                if r.details.get('num_options_inc_dec') is not None:
                    num_options_inc_dec = r.details.get('num_options_inc_dec')
                    num_options += num_options_inc_dec
                    temp_criteria_scores['num_options_inc_dec'] = num_options_inc_dec
                    overall_summary += f"num_options_inc_dec = {r.details.get('num_options_inc_dec')}, "
                if r.details.get('num_correct_options_inc_dec') is not None:
                    num_correct_options_inc_dec = r.details.get('num_correct_options_inc_dec')
                    num_correct_options += num_correct_options_inc_dec
                    temp_criteria_scores['num_correct_options_inc_dec'] = num_correct_options_inc_dec
                    overall_summary += f"num_correct_options_inc_dec = {num_correct_options_inc_dec}, "

                if r.details.get('llm_error') is not None:
                    gs_llm_error += r.details.get('llm_error') + '| '

                set_gs_to_zero = r.details.get('set_gs_to_zero')
                temp_criteria_scores['set_gs_to_zero'] = set_gs_to_zero
                overall_summary += f"set_gs_to_zero: {set_gs_to_zero} | "

                criteria_explanations[r.eval_type] = temp_criteria_explanations
                criteria_scores[r.eval_type] = temp_criteria_scores

            if debug:
                print("Final Guessing Susceptibility Calculation:")
            if set_gs_to_zero:
                if debug:
                    print("set_gs_to_zero flag is True, hence, gs = 0.0.")
                gs = 0.0
            else:
                if num_correct_options > 1:
                    # there are more than 1 correct answer, and they must be simultaneously selected in a single attempt
                    # Calculate total possible pairs (combinations of 2 out of 4)
                    if num_options > 0:
                        total_combinations = math.comb(num_options, num_correct_options)
                        # Only 1 combination is correct
                        num_of_correct_combinations = 1
                        # Probability = favorable outcomes / total outcomes
                        probability = 1.0 - (num_of_correct_combinations / total_combinations)
                        gs = probability if probability > 0.0 else 0.0
                        if debug:
                            print(f"After checks are completed, num options: {num_options}, "
                                  f"correct options: {num_correct_options}")
                            print(f"Total possible pairs: {total_combinations}")
                            print(f"Probability of guessing the correct pair: {probability:.4f} ({probability * 100:.2f}%)")
                    else:
                        gs = 0.0
                elif num_correct_options == 1:
                    if debug:
                        print(f"After checks are completed, num options: {num_options}, "
                              f"correct options: {num_correct_options}")
                    if num_options > 0:
                        gs = 1.0 - (num_correct_options / num_options)
                    else:
                        gs = 0.0
                    if debug:
                        print("GS = 1.0 - (num_correct_options / num_options)")
                        print(f"GS = {round(gs, 2)}")
                else:
                    gs = 0.0
                    overall_summary += "Error in MCQ: There must be at least 1 valid correct option." + '| '
                    if debug:
                        print("GS is set to 0.0 because There must be at least 1 valid correct option in an MCQ.")

    if debug:
        print(f"\nInput Tokens: {input_tokens} + Output Tokens: {output_tokens}")
        print(f"Total Tokens: {input_tokens + output_tokens} == {total_tokens}")

    overall_summary.removeprefix("| ").strip()

    if display_status:
        print("END ------> Guessing Susceptibility (GS) ******************\n")

    return EvaluationOutput(
        question=question.model_dump(),
        eval_type="gs",
        score=round(gs,2),
        explanation="Guessing Susceptibility (GS) checks for Question Format Issues, Distractor Quality, Duplicate "
                    "Distractors and Answer Leakage, where relevant.",
        details = {
            'overall_summary': overall_summary,
            'criteria_explanations': criteria_explanations,
            'criteria_scores': criteria_scores,
            'llm_error': gs_llm_error.removesuffix("| ").strip(),
            "comments": '',
            "token_usage": {
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "total_tokens": total_tokens
            }
        }
    )



