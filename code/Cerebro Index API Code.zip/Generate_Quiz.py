from dataclasses import dataclass
from input_models import QuestionFormat # ci_score_2_ci_category, qf_str_to_question_format
from pydantic import BaseModel
from typing import List, Union
import math
import numpy as np
import random

class QuizPromptInput(BaseModel):
    # What the client user needs to tell the Server in order to generate the Quiz and save it
    make_quiz_shareable_read_only: bool  # if True, set this Quiz to allow others to use (Read Only)
    quiz_title: str
    quiz_description: str
    num_questions: int
    quiz_complexity_score: float
    question_format_distribution: dict
    domain: str
    add_shareable_read_only: bool  # If True, Add Shareable Read Only Questions from other users

class QuizPromptResponse(BaseModel):
    quiz: Union[None, dict]
    insert_status: Union[None, dict]
    generation_error: Union[None, dict]

@dataclass
class GAQuestion:
    question_id: str
    question_format: QuestionFormat
    ci_score: float
    ci_complexity_category: str
    llm_complexity_category: str

@dataclass
class GAQuiz:
    quiz_questions: List[GAQuestion]
    fitness: float = None

    def total_quiz_questions(self):
        return len(self.quiz_questions)

    def __lt__(self, other):
        return self.fitness < other.fitness

    def __gt__(self, other):
        return self.fitness > other.fitness


class GenQuizGA:
    def __init__(self, avail_quests: List[GAQuestion], constraints: dict, ga_params: Union[None, dict]=None,
                 debug: bool=False):
        """

        :param avail_quests:
        :param constraints:
        :param ga_params:
        :param debug:
        """
        # rchai init
        # 1.1 Load GA Params
        self._population_size = ga_params.get('population_size') if ga_params.get('population_size') else 50
        self._generations = ga_params.get('generations') if ga_params.get('generations') else 100
        self._crossover_rate = ga_params.get('crossover_rate') if ga_params.get('crossover_rate') else 0.8
        self._mutation_rate = ga_params.get('mutation_rate') if ga_params.get('mutation_rate') else 0.1
        self._elitism = ga_params.get('elitism') if ga_params.get('elitism') else 2

        # 1.2 Check GA Params for errors
        self._population_size_error = None
        if self._population_size < self._elitism:
            self._population_size_error = {
                'status': 'error',
                'message': 'Population Size must be larger than number of elites.'
            }

        if debug:
            print(self.show_ga_params(), '\n')
            print(self.show_constraints(), '\n')

        # 2.1 LOAD User Data (questions user has previously generated or taken from publicly shareable)
        self._available_quests = avail_quests

        # 2.2 CHECK the Loaded User Data
        self._available_quests_error = None
        if (self._available_quests is None or not isinstance(self._available_quests, list) or
                len(self._available_quests) < 1):
            self._available_quests_error = {
                "status": "error",
                "message": "No questions or no valid questions were detected in the data received."
            }

        # 3.1 LOAD User Requirements (Constraints)
        self._required_num_questions = constraints.get('num_questions') if constraints.get('num_questions') else 5
        self._target_avg_quiz_complexity = constraints.get('avg_quiz_complexity') \
            if constraints.get('avg_quiz_complexity') is not None else 5.0
        self._quiz_distribution = constraints.get('quiz_distribution') if constraints.get('quiz_distribution') \
            else {QuestionFormat(0): 1.0, QuestionFormat(1): 0.0, QuestionFormat(2): 0.0}

        # 3.2 CHECK the User Requirements (Constraints)
        # 3.2.1 Check if num of questions desired by user is valid
        num_activated_proper_qf = sum([1 for question_format in QuestionFormat.proper_member_names() if
                                       constraints.get('quiz_distribution').get(question_format) is not None and
                                       constraints.get('quiz_distribution').get(question_format) > 0])
        self._required_num_questions_error = None

        if self._required_num_questions < 2 or (self._required_num_questions < num_activated_proper_qf):
            self._required_num_questions_error = {
                'status': 'error',
                'message': "Quizzes must have at least 2 questions. If you need 1 question, use the 'generate question' "
                           "end point instead. Also, your desired number of quiz questions must be at least equal to "
                           "the number of question formats you want. Example, if you wish your quiz to have 3 types "
                           "of question formats, then you should set the number of quiz questions to 3 or more."
            }
        if num_activated_proper_qf <= 0:
            self._required_num_questions_error = {
                'status': 'error',
                'message': "Sum of Quiz Format Distribution <=0. It must be between 0 and 1 (inclusive)."
            }

        # 3.2.2 Check if requested number of questions for quiz is too large
        self._required_num_questions_excessive_error_1 = None
        max_question_limit = 30  # currently, this limit is hard-coded
        if self._required_num_questions > max_question_limit:
            self._required_num_questions_excessive_error_1 = {
                'status': 'error',
                'message': f"You have asked for {self._required_num_questions} in your quiz which exceed the limit "
                           f"of {max_question_limit}."

            }

        self._required_num_questions_excessive_error_2 = None
        if self._required_num_questions > len(avail_quests):
            self._required_num_questions_excessive_error_2 = {
                'status': 'error',
                'message': f"You have asked for {self._required_num_questions} in your quiz which exceeds the number "
                           f"of questions you have generated previously (and perhaps even with the addition of "
                           f"shareable questions by other users). Either lower the number of questions for the quiz "
                           f"or generate more questions."

            }

        # 3.2.3 Check if avg quiz complexity is valid (>=0 and <=10)
        self._target_avg_quiz_complexity_error = None
        if 0 > self._target_avg_quiz_complexity > 10:
            self._target_avg_quiz_complexity_error = {
                'status': 'error',
                'message': 'The Target Average Quiz Complexity must be between 0 and 10 (inclusive).'
            }

        # 3.2.4 Check if Question Formats are Valid
        self._question_format_error = None
        for key in self._quiz_distribution.keys():
            try:
                QuestionFormat(key)
            except ValueError:
                self._question_format_error = {
                    'status': 'error',
                    'message': f"{key} is not a valid Question Format."
                }

        # 3.2.5 Check if sum of distribution is 1 or close to 1
        self._distribution_error = None
        quiz_distribution_sum = sum(self._quiz_distribution.values())
        if not math.isclose(quiz_distribution_sum, 1.0, abs_tol=0.0101) :  # abs_tol
            self._distribution_error = {
                "status": "error",
                "message": f"Invalid quiz distribution sum: {quiz_distribution_sum}. Must sum up to 1.0 or very close to it."
            }
        if quiz_distribution_sum <= 0:
            self._distribution_error = {
                'status': 'error',
                'message': "Sum of Quiz Distribution cannot be zero or negative. It must be between 0 and 1 (inclusive)."
            }

        # 4.0 Calculate "global" variables | rchai globals
        # 4.1 Calc the concrete num of questions per question format that we need to deliver to user
        self._quiz_distribution_num_error = None
        if 0 < quiz_distribution_sum <= 1:
            qf_subset = [qf for qf, p_value in self._quiz_distribution.items() if p_value > 0]
            quiz_distribution_num = {k: int(v * self._required_num_questions) for k, v in self._quiz_distribution.items()}
            curr_num_questions = sum(quiz_distribution_num.values())
            if debug:
                print(f"\nREQUIRED num questions: {self._required_num_questions}, CURR num questions: {curr_num_questions}.")

            if curr_num_questions < self._required_num_questions:
                num_to_add = self._required_num_questions - curr_num_questions
                if debug:
                    print(f"num to add: {num_to_add}")
                while num_to_add > 0:
                    quiz_distribution_num[random.choice(qf_subset)] += 1
                    num_to_add -= 1
            elif self._required_num_questions < curr_num_questions:
                num_to_remove = curr_num_questions - self._required_num_questions
                if debug:
                    print(f"num_to_remove: {num_to_remove}")
                raise SystemError("GenQuizGA.init needs to remove questions from quiz_distribution_num")
            else:
                if debug:
                    print("All good, no need to adjust the quiz distribution numbers.")

            self._quiz_distribution_num = quiz_distribution_num.copy()
            if debug:
                print(f"Final Quiz Distribution Numbers:\n{self._quiz_distribution_num} --> "
                      f"\nTotal Questions: {sum(self._quiz_distribution_num.values())}")
        else:
            self._quiz_distribution_num = None
            self._quiz_distribution_num_error = {
                'status': 'error',
                'message': 'Unable to calculate quiz distribution sum. Check that the sum of your quiz distribution '
                           'is between 0.0 and 1.0 (inclusive).'
            }

    def show_ga_params(self):
        return (f"Population Size: {self._population_size} \nNum of Generations: {self._generations}, \nCrossover Rate: "
                f"{self._crossover_rate}\nMutation Rate: {self._mutation_rate}\nElitism: {self._elitism}")

    def show_constraints(self):
        return (f"Num Questions: {self._required_num_questions} \nAvg Quiz Complexity: {self._target_avg_quiz_complexity}, "
                f"\nDistribution: {self._quiz_distribution}")

    def _gen_question(self, question_format: Union[None, QuestionFormat]=None) -> Union[dict, GAQuestion]:
        """
        if question_format is not specified, randomly select a question.
        :param question_format:
        :return:
        """
        if question_format:
            subset = [quest for quest in self._available_quests if quest.question_format == question_format]
            return random.choice(subset) if subset else random.choice(self._available_quests)
        else:
            return random.choice(self._available_quests)

    def _gen_quiz(self) -> Union[dict, GAQuiz]:
        return GAQuiz(quiz_questions=[self._gen_question() for _ in range(self._required_num_questions)])

    def _evaluate_fitness(self, quiz: GAQuiz) -> float:
        """
        Compute the fitness of a quiz.
        Higher fitness = better match to constraints. Fitness==0 is best.
        :return:
        """
        fitness = 0.0
        total_complexity_score = sum(q.ci_score for q in quiz.quiz_questions)
        ave_quiz_complexity = total_complexity_score / len(quiz.quiz_questions)

        # 1. Penalize deviation from target complexity
        fitness -= abs(ave_quiz_complexity - self._target_avg_quiz_complexity)

        # 2. Penalize deviation from target question type distribution
        type_counts = {qf: 0 for qf in QuestionFormat.proper_member_names()}

        for q in quiz.quiz_questions:
            type_counts[q.question_format] += 1

        total_quiz_questions = quiz.total_quiz_questions()
        for t, target_pct in self._quiz_distribution.items():
            quiz_pct = type_counts[t] / total_quiz_questions
            # fitness -= abs(quiz_pct - target_pct)  # original
            fitness -= 3 * abs(quiz_pct - target_pct)

        quiz.fitness = fitness
        return fitness

    # --- Genetic Operators ---
    @staticmethod
    def _tournament_selection(population, num_samples: Union[None, int]=None, debug=False) -> GAQuiz:
        """
        Tournament selection selects a chromosome (also referred to as an individual) from a population,
        not individual genes.

        Tournament selection works by randomly selecting a small subset of chromosomes from the population, and
        then choosing the one with the best fitness within that subset to be a parent for the next generation.

        :param population:
        :param num_samples:
        :return:
        """
        num_samples = int(len(population)/2) if num_samples is None else num_samples
        selected_subset = random.sample(population, num_samples)
        if debug:
            print('\n', '~'*100)
            # print("population")
            # for p in population:
            #     print(p.fitness)

            print("Tournament Selection Subset")
            for quiz in selected_subset:
                print(quiz.fitness)

        selected_subset_sorted = sorted(selected_subset)
        if debug:
            print("Tournament Selection Subset - Sorted")
            for quiz in selected_subset_sorted:
                print(quiz.fitness)

        return selected_subset_sorted[-1]

    def _crossover(self, parent1: GAQuiz, parent2: GAQuiz) -> GAQuiz:
        """

        :param parent1:
        :param parent2:
        :return:
        """

        # Single-point crossover between two parents.
        if random.random() > self._crossover_rate:
            return random.choice([parent1, parent2])

        crossover_point = random.randint(1, len(parent1.quiz_questions) - 1)

        child_questions = parent1.quiz_questions[:crossover_point] + parent2.quiz_questions[crossover_point:]
        return GAQuiz(quiz_questions=child_questions)

    def _mutate(self, quiz: GAQuiz) -> GAQuiz:
        """
        NB: Mutation of gene (question) does not take QuestionFormat constraint into consideration.
        :param quiz:
        :return:
        """
        mutated_quiz_questions = quiz.quiz_questions.copy()
        for idx in range(len(mutated_quiz_questions)):
            if random.random() < self._mutation_rate:
                mutated_quiz_questions[idx] = self._gen_question()  # question_format arg is not set
        quiz.quiz_questions = mutated_quiz_questions
        return quiz

    @staticmethod
    def _remove_duplicates_keep_first_question(lst: List[GAQuestion]) -> list[GAQuestion]:
        """
        Removes duplicate IDs from a list, keeping only the first occurrence of each ID.

        :param lst:
        :return:
        A new list with duplicate removed, preserving the order of first occurrences.
        """
        seen_quest_ids = set()
        unique_questions = []
        for quest in lst:
            if quest.question_id not in seen_quest_ids:
                unique_questions.append(quest)
                seen_quest_ids.add(quest.question_id)
        return unique_questions


    def _repair(self, quiz: GAQuiz, enable_ci_0: bool=False, debug:bool = False) -> GAQuiz:
        """
        1. Fix ci_scores out of bounds

        2. Fix ci_score == 0 (if not enabled)
        . Check if allow_ci_0 is enabled, otherwise remove all questions with ci_score == 0.

        3 Check for duplicates
        … if found, remove all but keep first.

        4. Check if QF distribution is met
        … if too many in a qf, remove it
        … if too few in a qf, add it
        … when adding, check for duplicates before adding it.
        … set a max try so it doesn't become an infinite loop. coz it is possible that there isn't enough questions of
        a specific format in the database.

        5. Check if total questions required for quiz is exceeded, if yes, delete them.

        :param quiz:
        :param debug:
        :return:
        """
        if debug:
            print(f"\n\n************************ GenQuizGA.repair() Start ************************")
            print(f"Before Repair actions start: No of questions in quiz --> {len(quiz.quiz_questions)}")
            print("Subsequently, questions with CI Score of 0 and duplicate questions will be removed if found.")

        modified_quiz_questions = quiz.quiz_questions.copy()

        # 1. Fix complexity bounds  # todo: this part is relevant only after I add in the later features.
        # for q_type, complexity in quiz:
        #     bounds = QUESTION_TYPE_BOUNDS[q_type]
        #     clamped_complexity = np.clip(complexity, bounds["min"], bounds["max"])
        #     repaired_quiz.append((q_type, clamped_complexity))

        # 2. Remove ci_score==0 unless enabled
        if not enable_ci_0:
            modified_quiz_questions = [quest for quest in modified_quiz_questions if quest.ci_score != 0]

        # 3. Remove duplicate questions
        modified_quiz_questions = self._remove_duplicates_keep_first_question(modified_quiz_questions)

        # NOTES *******************************************************
        #  Code in 4.0 works, but I've commented it out coz the GA performance ended up being worse.
        # NOTES *******************************************************
        # 4. Adjust question type distribution (if needed)
        # 4.1 get the current type counts in the quiz
        # type_counts = {qf: 0 for qf in QuestionFormat.proper_member_names()}
        # for quest in modified_quiz_questions:
        #     type_counts[quest.question_format] += 1
        # if debug:
        #     print("\nAfter CI_0 and Dedup actions, Modified Quiz Questions -> Distribution:")
        #     for question_format, qty in type_counts.items():
        #         print(f"\t{question_format}: {qty}")
        #     print(f"Total num: {sum([value for value in type_counts.values()])}\n")

        # 4.2 compare with the type distribution constraint and add or remove questions as needed
        # for question_format, qty in self._quiz_distribution_num.items():  # rchai
        #     if debug:
        #         print(f"Requirement --> {question_format}: {qty}")
        #         print(f"In Quiz     --> {type_counts[question_format]}")
        #     if qty > type_counts[question_format]:  # Need N more questions of this qf
        #         num_to_add = qty - type_counts[question_format]
        #         if debug:
        #             print(f"---> Number of Questions of '{question_format}' to add: {num_to_add}.")
        #         max_tries = 3  # break, in case impossible to fulfill e.g. User didn't provide enough in question dataset.
        #         current_try = 0
        #         while num_to_add > 0:
        #             current_try += 1
        #             question = self._gen_question(question_format=question_format)
        #             if question.question_id not in [quest.question_id for quest in modified_quiz_questions]:  # no dup
        #                 modified_quiz_questions.append(question)
        #                 num_to_add -= 1
        #                 current_try = 0
        #                 if debug:
        #                     print(f"\t...1 question added.")
        #             if current_try > max_tries:
        #                 if debug:
        #                     print(f"\t...Unable to add 1 or more questions. Breaking.")
        #                 break
        #     elif qty < type_counts[question_format]:  # remove N questions of this qf
        #         num_to_remove = type_counts[question_format] - qty
        #         if debug:
        #             print(f"---> Number of Questions of '{question_format}' to remove: {num_to_remove}.")
        #             print(f"type(question_format): {type(question_format)}")
        #             # for quest in modified_quiz_questions:
        #             #     print(f"quest.question_format: {quest.question_format} | {type(quest.question_format)}")
        #             #     if quest.question_format == question_format:
        #             #         print(f"Found one! question_id: {quest.question_id}\n")
        #
        #         qf_quest_ids = [quest.question_id for quest in modified_quiz_questions
        #                         if quest.question_format==question_format]
        #         qf_quest_ids_to_del = [qf_quest_ids[idx] for idx in range(num_to_remove)]
        #         modified_quiz_questions = [quest for quest in modified_quiz_questions
        #                                    if quest.question_id not in qf_quest_ids_to_del]
        #
        # if debug:
        #     type_counts = {qf: 0 for qf in QuestionFormat.proper_member_names()}
        #     for quest in modified_quiz_questions:
        #         type_counts[quest.question_format] += 1
        #     print("\n~~~~~~ After Adjusting Quiz Distribution ~~~~~~~~")
        #     for qf, qty in type_counts.items():
        #         print(f"\t{qf}: {qty}")

        # 5. Check if total questions required for quiz is exceeded, if yes, delete them.
        excess_questions = len(modified_quiz_questions) - self._required_num_questions
        if debug:
            print(f"\nRequired number of questions: {self._required_num_questions}. Number of questions in "
                  f"quiz: {len(modified_quiz_questions)}")
            print(f"Excess Questions in Quiz: '{excess_questions}'. -ve: Need to add questions. +ve: Need to remove questions.")
        if excess_questions > 0:
            while excess_questions > 0:
                random_element = random.choice(modified_quiz_questions)
                modified_quiz_questions.remove(random_element)
                if debug:
                    print("\t1 question has been removed.")
                excess_questions -= 1
        else:
            while excess_questions < 0:  # NB: the addition of question does NOT consider Distribution Constraint
                quest = self._gen_question()
                modified_quiz_questions.append(quest)
                excess_questions += 1

        # FINAL: Return the Repaired Quiz to caller.
        quiz.quiz_questions = modified_quiz_questions
        if debug:
            print("\n Repair Completed, repaired quiz -->")
            type_counts = {qf: 0 for qf in QuestionFormat.proper_member_names()}
            for quest in quiz.quiz_questions:
                type_counts[quest.question_format] += 1
            for qf, qty in type_counts.items():
                print(f"\t{qf}: {qty}")
            print(f"Total Questions: {len(quiz.quiz_questions)}")
            print(f"************************ GenQuizGA.repair() End ************************")
        return quiz

    # rchai: prev fn definition, if not useful delete it
    # async def generate_quiz_from_user_specs(input_args: QuizPromptInput, llm_model, response_format='json',
    #                                         display_status: bool=True, debug:bool=False) -> dict:

    async def generate_the_quiz(self, early_stopping: bool=True, display: bool=True, debug: bool=False):
        """
        In a genetic algorithm, chromosomes represent potential solutions to a problem. They are typically encoded as
        strings of genes. In my use_case, a quiz is a chromosome and each question in a quiz is a gene.

        This GA loop will find the best chromosome.

        :param early_stopping: If True, "generations" will stop if best_quiz's fitness is the same for 10 turns.
        :param display:
        :param debug:
        :return:
        """

        if display:
            print('\n', '+'*80, 'GA Loop - START')

        # rchai return errors
        if self._available_quests_error:
            return self._available_quests_error

        if self._question_format_error:
            return self._question_format_error

        if self._distribution_error:
            return self._distribution_error

        if self._population_size_error:
            return self._population_size_error

        if self._target_avg_quiz_complexity_error:
            return self._target_avg_quiz_complexity_error

        if self._required_num_questions_error:
            return self._required_num_questions_error

        if self._required_num_questions_excessive_error_1:
            return self._required_num_questions_excessive_error_1

        if self._required_num_questions_excessive_error_2:
            return self._required_num_questions_excessive_error_2

        if self._quiz_distribution_num_error:
            return self._quiz_distribution_num_error



        # ============================================================================
        population = [self._gen_quiz() for _ in range(self._population_size)]

        if display:
            print("--------------------------------------------> Creating a NEW generation - START")
        early_stopping_data = {
            'best_quiz_fitness': -9999.9,
            'num_of_turns': 0
        }
        for gen in range(self._generations):
            if display:
                print(f"\n============================== Generation {gen} START ==============================")

            # 1. get fitness of each quiz (chromosome) in the population
            fitness = [self._evaluate_fitness(quiz) for quiz in population]

            # 2. Select elites (top individuals to carry over) i.e. Top N Chromosome i.e. Top N Quiz
            elites_indices = np.argsort(fitness)[-self._elitism:]  # each elite is a quiz
            elites = [population[idx] for idx in elites_indices]

            # Create the next generation - starting with the newly transplanted Elites
            new_population = elites.copy()  # new population starts with N chromosomes (i.e. the N Elite Quizzes)
            if debug:
                print("Elites selected and transferred to New Population.")
                print(f"No of Quizzes in new population: '{len(new_population)}'")

            # Fill out the new population with new chromosomes
            while len(new_population) < self._population_size:
                # Selection of 2 parents (NOT from new_population)
                parent1 = self._tournament_selection(population, debug=debug)  # parents are quizzes (chromosomes)
                parent2 = self._tournament_selection(population, debug=debug)
                if debug:
                    print("2 Parents selected by tournament selection.")
                # at this point, the new_population has N Elites i.e. 2 Quizzes, parent 1 & 2 not added to
                # new_population yet. After GA Operators are executed, only 1 quiz is left (child)
                # Hence, this loop adds 1 chromosome at a time.

                # Crossover
                child = self._crossover(parent1, parent2)

                # Mutation
                child = self._mutate(child)

                # Repair the Mutated child if required
                enable_ci_0 = True if self._target_avg_quiz_complexity == 0 else False
                child = self._repair(quiz=child, enable_ci_0=enable_ci_0, debug=debug)

                # Evaluate the child
                self._evaluate_fitness(child)

                # One Chromosome (Quiz) added to the new population
                new_population.append(child)
                if debug:
                    print(f"\n~~~~~~~~~~~> No of Quizzes in new population: '{len(new_population)}'")

            if display:
                print(f"\n============================== Generation {gen} END ==============================")

            population = new_population
            quiz_fitness = [self._evaluate_fitness(quiz) for quiz in population]
            best_quiz_fitness = round(sorted(quiz_fitness)[-1], 3)
            avg_population_fitness = round(sum(quiz_fitness) / len(fitness), 3)
            quizzes_with_fitness_0 = [round(fitness, 5) for fitness in quiz_fitness if -0.045 < fitness < 0.45]

            if early_stopping:
                if best_quiz_fitness == early_stopping_data.get('best_quiz_fitness'):
                    early_stopping_data['num_of_turns'] += 1
                    if early_stopping_data['num_of_turns'] > 10:
                        break
                else:
                    early_stopping_data['best_quiz_fitness'] = best_quiz_fitness
                    early_stopping_data['num_of_turns'] = 0

            if display:
                print(f"\nGen {gen}: Average Population Fitness = {avg_population_fitness}")
                print(f"Best Quiz: {best_quiz_fitness}")
                print(f"Number of Quizzes with fitness 0 or near 0 is: {len(quizzes_with_fitness_0)} \n {quizzes_with_fitness_0}")
                print("--------------------------------------------> Creating a NEW generation - END")

        if display:
            print('\n', '+'*80, 'GA Loop - END')
        # Return the best quiz (chromosome) from the final population
        return sorted(population)[-1]  # the return is a GAQuiz

