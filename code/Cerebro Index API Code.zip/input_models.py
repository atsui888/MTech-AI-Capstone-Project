from pydantic import BaseModel
from typing import Dict, List, Union
from enum import Enum


class QuestionInput(BaseModel):
    question_id: Union[str, None]
    question_type: str
    question_text: str
    hint: Union[List[str], None]
    options: Union[List[Dict], None]
    correct_indices: Union[List[int], None]
    correct_value: Union[str, bool, None]
    correct_ans_explanation: Union[str, None]
    incorrect_ans_explanation: Union[str, None]
    expected_answer: Union[str, None]
    expected_ans_explanation: Union[str, None]


class QuestionFormat(Enum):
    MCQ = 1
    SHORT_ANSWER = 2
    TRUE_FALSE = 3

    @classmethod
    def proper_member_names(cls):
        return [member for member in cls]

    @classmethod
    def member_names(cls):
        return [member.name for member in cls]

    @classmethod
    def member_values_constants(cls):
        return [member.value for member in cls]

    @classmethod
    def member_names_value_constants(cls) -> list:
        return [(member.name, member.value) for member in cls]

    @classmethod
    def is_member(cls, proper_name: Enum) -> bool:
        return cls.__contains__(proper_name)

    @classmethod
    def qf_to_short_member_name(cls, qf: str) -> Enum:
        return cls.__members__[qf.upper()]

    @classmethod
    def proper_member_name_to_qf(cls, proper_name: Enum) -> Union[None, str]:
        for k, v in cls.__members__.items():
            if v == proper_name:
                return k.lower()
        return None

    def label(self):
        """
        For displaying a more informative 'label' to the caller
        :return:
        """
        labels = {
            QuestionFormat.MCQ: "The MCQ Question Format.",
            QuestionFormat.TRUE_FALSE: "The True/False Question Format.",
            QuestionFormat.SHORT_ANSWER: "The Short Answer Question Format."
        }
        return labels[self]


def qf_str_to_question_format(qf: str):
    """
    Converts qf str e.g. "mcq" to QuestionFormat.MCQ
    :param qf:
    :return:
    """

    if qf == "mcq":
        return QuestionFormat(1)
    elif qf == "short_answer":
        return QuestionFormat(2)
    elif qf == "true_false":
        return QuestionFormat(3)
    else:
        return None

def ci_score_2_ci_category(ci_score: float) -> str:
    if ci_score == 0:
        return "zero complexity"
    elif ci_score <= 2.0:
        return "minimal complexity"
    elif ci_score <= 4.0:
        return "low complexity"
    elif ci_score <= 6.0:
        return "moderate"
    elif ci_score <= 8.0:
        return "challenging"
    else:
        return "very challenging"