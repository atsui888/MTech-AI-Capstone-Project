# this file is used by Generate_Question.py and Generate_Quiz.py because they need to attach a
# calc_ci object to their class initiation.

from input_models import QuestionInput
from Cerebro_Index import analyse_complexity


class CalcCerebroIndex:
    def __init__(self, llm, response_format, debug=False):
        self._llm = llm
        self._response_format = response_format
        self._debug = debug

    # @staticmethod
    async def calc_cerebro_index(self, question: dict):

        """
        Call Cerebro Index API to calculate the CI for this question and store the return value into self.cerebro_index
        :return:
        """

        data =  QuestionInput(
            question_id=question.get('id'),
            question_type=question.get('type'),
            question_text=question.get('question'),
            hint=question.get('hint'),
            options=question.get('options'),
            correct_indices=question.get('correct_indices'),
            correct_value=question.get('correct_value'),
            correct_ans_explanation=question.get('correct_ans_explanation'),
            incorrect_ans_explanation=question.get('incorrect_ans_explanation'),
            expected_answer=question.get('expected_answer'),
            expected_ans_explanation=question.get('expected_ans_explanation'))

        if self._debug:
            print('\n********************* serverside_calc_cerebro_index.py --> calc_cerebro_index() is called!\n')

        res = await analyse_complexity(question=data, llm_model=self._llm, response_format=self._response_format,
                                       debug=self._debug)
        # print('*' * 80)
        # print(type(res))
        # print(res)
        # print('*' * 80)
        # zz = res.model_dump()
        # print(type(zz))
        # print(zz)
        # print('*' * 80)
        return {'result': res.model_dump()}


if __name__ == "__main__":
    pass
