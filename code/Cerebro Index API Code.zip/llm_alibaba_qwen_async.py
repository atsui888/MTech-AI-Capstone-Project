from abc import ABC, abstractmethod
from typing import Dict, Union
from llm import LLM

import asyncio
import platform
from dashscope.aigc.generation import AioGeneration
import dashscope
import os





class AlibabaModelStudioLLM(LLM):
    # https://www.alibabacloud.com/help/en/model-studio/what-is-model-studio
    # https://www.alibabacloud.com/help/en/model-studio/text-generation  #  Async Invocation
    def __init__(self, llm_model_name: str):
        self._model_name = llm_model_name
        self._response = None

    @property
    def model_name(self):
        return self._model_name

    def _model_args(self):
        # this method may not be useful... remove from base class?
        return {
            'model': self._model_name,
            # 'max_output_tokens': self._response_dict('max_output_tokens'),
            # 'truncation': self._response_dict('truncation'),
            # 'instructions': self._response_dict('instructions'),
            # 'temperature': self._response_dict('temperature'),
            # 'top_p': self._response_dict('top_p'),
            # 'tools': self._response_dict('tools'),
            # 'tool_choice': self._response_dict('tool_choice')
        }


    async def ask_llm(self, messages: list, temperature: float=0.1, response_format=None,
                stream=False, time_out: int=30, debug=False) -> Union[None, Dict, Exception]:
        """

        :param top_p:
        :param messages:
        :param temperature:
        :param response_format:
        :param stream:
        :param time_out: in Seconds
        :param debug:
        :return:
        """
        if response_format is None:
            response_format = dict(type='text')
        elif response_format == 'json':
            response_format = dict(type='json_object')

        # https://www.alibabacloud.com/help/en/model-studio/use-qwen-by-calling-api#69cac67a477k2
        # Original Code without checking for time-out. RC: 2025-08-05_1739
        # self._response = await AioGeneration.call(
        #     # self._response = dashscope.Generation.call(  # non-async version
        #     # api_key=self._api_key,  # api key is already set in global var "dashscope.api_key"
        #     model=self._model_name,
        #     messages=messages,
        #     result_format='message',
        #     response_format=response_format,
        #     temperature=temperature,
        #     stream=stream  # be careful of setting to True, coz this method is being awaited.
        # )

        # New Code, RC: 2025-08-05_1741
        try:
            self._response = await asyncio.wait_for(AioGeneration.call(
                # self._response = dashscope.Generation.call(  # non-async version
                # api_key=self._api_key,  # api key is already set in global var "dashscope.api_key"
                model=self._model_name,
                messages=messages,
                result_format='message',
                response_format=response_format,
                temperature=temperature,
                stream=stream  # be careful of setting to True, coz this method is being awaited.
            ), timeout=time_out)

            error_reason = ''

            if debug:
                print('\n\n', '=' * 100)
                # "code": "Model.AccessDenied"
                print("response code is: ")
                print(self._response.get("code"))  # Model.AccessDenied
                print(type(self._response))
                print(self._response)
                print('\n\n', '=' * 100)

            if self._response:
                response_code = self._response.get("code")
                if self._response is not None:
                    if response_code == 'Model.AccessDenied':
                        error_reason += "You are not authorised to use this AI Model. | "
                    elif response_code == 'InvalidParameter':
                        error_reason += f"{self._response.get('message')}"
                else:
                    error_reason += "Error: Unable to get response code."

                response_output = self._response.get('output')
                if response_output is not None:
                    response_choices = response_output.get('choices')
                    if response_choices is not None and isinstance(response_choices, list) and len(
                            response_choices) > 0:
                        finish_reason = response_choices[0].get('finish_reason')
                        if finish_reason is not None and isinstance(finish_reason, str) and len(finish_reason) > 0:
                            if finish_reason == 'length':
                                error_reason += "Output truncated as it exceeds 'max_tokens' or 'max context' length. | "
                            elif finish_reason == 'stop':
                                completion_msg = response_choices[0].get('message')
                                if completion_msg is not None:
                                    completion_content = completion_msg.get('content')
                                    if completion_content is not None and len(completion_content) > 0:
                                        return {
                                            'error': None,
                                            'completion': completion_content,
                                            'model_args': self._model_args(),
                                            'usage': self._tokens_used()
                                        }
                                    else:
                                        error_reason += "Error: Unable to get Completion Content!"
                                else:
                                    error_reason += "Error: Unable to get completion message."
                        else:
                            error_reason += "Error: Unable to get response->output->choices[0]->finish_reason."
                    else:
                        error_reason += "Error: Unable to get response->output->choices."
                else:
                    error_reason += "Error: Unable to get response output."
            else:
                error_reason += f"Unknown Error. Debug the Response --->  {self._response}"
            return {
                'error': error_reason.removesuffix('| ').strip(),
                'completion': None,
                'model_args': None,
                'usage': None
            }
        except asyncio.TimeoutError:
            err_msg = "Error: Coroutine 'ask_llm' timed out!"
            print(err_msg)
            return {
                'error': err_msg,
                'completion': None,
                'model_args': None,
                'usage': None
            }



    def _tokens_used(self):
        if self._response:
            return {
                'total_tokens': self._response.get('usage').get('total_tokens'),
                'input_tokens': self._response.get('usage').get('input_tokens'),
                'cached_tokens': 'unknown',
                'prompt_cache_hit_tokens': 'unknown',
                'prompt_cache_miss_tokens': 'unknown',
                'output_tokens': self._response.get('usage').get('output_tokens'),
            }
        return None




# for local testing
async def test_guessing_susceptibility_text():
    qwen = AlibabaModelStudioLLM(llm_model_name='qwen-turbo')  # 'qwen-turbo', 'qwen-plus'

    tasks = []
    questions = ["Who are you?", "What can you do?", "How's the weather?", "what 2+2?"]
    for q in questions:
        msg_format = [
            {"role": "assistant", 'content': 'you are a helpful assistant'},
            {"role": "user", "content": q}]

        tasks.append(qwen.ask_llm(msg_format))  # All Tasks are using the same qwen object's .ask_llm()

    results = await asyncio.gather(*tasks)
    for r in results:
        if r.get('error'):
            print( '*'*50, r.get('error'), '*'*50)
        else:
            print('*' * 50)
            print(r.get('completion', 'unknown'))
            print(r.get('model_args', 'unknown'))
            print(r.get('usage', 'unknown'))
            print('*'*50)

# for local testing
async def test_guessing_susceptibility_json():
    qwen = AlibabaModelStudioLLM(llm_model_name='qwen-turbo')  # 'qwen-turbo', 'qwen-plus'

    tasks = []
    questions = ["Who are you?", "What can you do?", "How's the weather?", "what 2+2?"]
    for q in questions:
        prompt = f""" 
            You are a comedian, answer the following question in a funny way.
    
            **Question:**
            {q}
        
            **Output Format:**
            Your response MUST be in JSON format. STRICTLY adhere to the following JSON structure, ensuring ALL fields 
            and nested objects are present for each evaluated option. Return your response in JSon as follows: 
            ```json
            "question": {{<the question>}},
            "answer": {{<your answer>}},
            "question_difficulty": {{<was the question difficult? 1 to 5 integer (easy to very hard)}}
            ```
        """
        msg_format = [{"role": "user", "content": prompt}]

        tasks.append(qwen.ask_llm(msg_format, response_format='json'))

    results = await asyncio.gather(*tasks)
    for r in results:
        if r.get('error'):
            print( '*'*50, r.get('error'), '*'*50)
        else:
            print('*' * 50)
            print(r.get('completion', 'unknown'))
            print(r.get('model_args', 'unknown'))
            print(r.get('usage', 'unknown'))
            print('*'*50)




# **************************** Local Env (START) **********************************************************
if __name__ == "__main__":
    LOCAL_API = True  # set to False if using on render.com
    if LOCAL_API:
        from dotenv import load_dotenv
        load_dotenv()
        LLM_API_KEYS = {
            'alibaba_qwen': os.getenv('CI_ALIBABA_QWEN_KEY'),
            'deepseek': os.getenv('CI_DEEPSEEK_KEY'),
            'google_gemini': os.getenv('CI_GOOGLE_GEMINI_KEY'),
            'openai': os.getenv('CI_OPENAI_SVC_KEY')
        }


        # the next line works whether in local env or render.com
        QWEN_KEY = os.getenv('CI_ALIBABA_QWEN_KEY')

        if QWEN_KEY is None:
            raise SystemError("Alibaba Key cannot be None.")

        # using DashScope API and not OpenAI Compatible API
        # The following two lines are critical.
        dashscope.base_http_api_url = 'https://dashscope-intl.aliyuncs.com/api/v1'
        dashscope.api_key = QWEN_KEY

        # Set event loop policy
        if platform.system() == 'Windows':
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

        # Testing
        asyncio.run(test_guessing_susceptibility_text(), debug=True)
        # asyncio.run(test_guessing_susceptibility_json(), debug=True)
# **************************** Local Env (END) **********************************************************


