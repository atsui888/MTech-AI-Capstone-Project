from pydantic import BaseModel
from input_models import QuestionInput
from output_models import EvaluationOutput
import time
from api_helper import safe_json_loads
from cic_prompt import load_prompt

# This route classifies the Conceptual Interconnectedness (CIC) of a given question,

class CICResponse(BaseModel):
    result: EvaluationOutput

async def analyse_conceptual_interconnectedness(question: QuestionInput, llm_model, response_format='json',
                                                display_status=True, debug=False) -> EvaluationOutput:
    """

    :param question:
    :param llm_model:
    :param response_format:
    :param display_status:
    :param debug:
    :return:
    """
    if display_status:
        print("START ------> Calculating Conceptual Interconnectedness ******************")

    comments = ''
    llm_error = 'None'
    try_num = 1
    max_tries = 5
    avg_score = None
    overall_summary = None
    criteria_explanations = None
    criteria_scores = None
    input_tokens = 0
    total_tokens = 0
    output_tokens = 0
    # cic_complexity_score = None

    while try_num < max_tries:
        if display_status:
            print(f"\nCheck Conceptual Interconnectedness --> Try Number: {try_num}\n***********************")

        msgs = [{"role": "user", "content": load_prompt()}]
        result = await llm_model.ask_llm(messages=msgs, response_format=response_format)

        completion = safe_json_loads(result.get('completion')) if result else None
        if completion:
            llm_error = result.get('error')
            # completion = json.loads(result.get('completion'))
            # if debug:
            #     print(f"\nDEBUG\n{type(completion)}\n{completion}\n")

            # next line checks if the LLM returned an empty json
            if completion.get('overall_summary') is not None and len(completion.get('overall_summary')) > 0:
                overall_summary = completion.get('overall_summary')
                criteria_explanations = completion.get('criteria_explanations')
                criteria_scores = completion.get('criteria_scores')
                total_score = 0.0
                for score in criteria_scores.values():
                    total_score += score
                avg_score = round(total_score / len(criteria_scores), 3)

                if debug:
                    print('\n', 'DEBUG *********************************')
                    print(f"Overall Summary --->\n{overall_summary}\n")
                    for k, v in criteria_explanations.items():
                        print(f"{k}:\n{v}")
                    print()
                    for k, v in criteria_scores.items():
                        print(f"{k}: {v}")
                    print(f"Average Score:\n{avg_score}")

                usage = result.get('usage')
                input_tokens += usage.get('input_tokens')
                output_tokens += usage.get('output_tokens')
                total_tokens += usage.get('total_tokens')
                if debug:
                    print(f"input_tokens: {input_tokens}")
                    print(f"output_tokens: {output_tokens}")
                    print(f"total_tokens: {total_tokens}")
                try_num = max_tries
        time.sleep(1)
        try_num += 1
        if display_status:
            print(f"\nCheck Conceptual Interconnectedness --> End Try ***********************\n")


    if avg_score is None:
        # we did not get a valid response from LLM
        cic_complexity_score = 1.0  # set at 1 as we have no idea what the amb should be
        llm_error += "No valid response from LLM, hence setting amb_complexity_score to 1.0. "
    elif avg_score > 0:
        # scale between 1.0 to 2.0 (inclusive)
        cic_complexity_score = (1.0 + (avg_score - 1) * (1.0 / 4))
    else:
        # 0.0 indicates critical error with the question that user needs to manage
        cic_complexity_score = 0.0

    if display_status:
        print("END ------> Calculating Conceptual Interconnectedness ******************\n")

    return EvaluationOutput(
        question=question.model_dump(),
        eval_type='cic',
        score=cic_complexity_score,
        explanation="Conceptual Interconnectedness measures how strongly ideas are linked and indicates question "
                    "complexity based on the need to integrate multiple concepts.",
        details={
            'overall_summary': overall_summary,
            'criteria_explanations': criteria_explanations,
            'criteria_scores': criteria_scores,
            'token_usage': {
                'total_tokens': total_tokens,
                'input_tokens': input_tokens,
                'output_tokens': output_tokens
            },
            'llm_error': llm_error,
            'comments': comments.removesuffix('| ').strip()
        }
    )
