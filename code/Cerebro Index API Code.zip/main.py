from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials

# fastapi dev main.py

from input_models import QuestionInput

from Cerebro_Index import analyse_complexity, ComplexityResponse
from CI_Bloom_Taxonomy import analyse_bloom_taxonomy, BLTXResponse
from CI_Ambiguity import analyse_ambiguity, AMBResponse
from CI_Information_Density import analyse_information_density, INFDResponse
from CI_Syntactic_Complexity import analyse_syntactic_complexity, STCResponse
from CI_Conceptual_Interconnectedness import analyse_conceptual_interconnectedness, CICResponse
from CI_Guessing_Susceptibility import analyse_guessing_susceptibility, GSResponse

from Generate_Question import QuestionPromptInput, generate_question_from_prompt, QuestionPromptResponse
from api_helper import get_question_hash_token

from Generate_Quiz import QuizPromptInput, QuizPromptResponse, GenQuizGA, GAQuiz, GAQuestion
# from create_quiz_ga import GAQuestion, GAQuiz
from quiz import Quiz

from question_truefalse import TrueFalseQuestion
from question_mcq import MCQQuestion
from question_shortanswer import ShortAnswerQuestion
from input_models import ci_score_2_ci_category, qf_str_to_question_format

from serverside_calc_cerebro_index import CalcCerebroIndex


PRG_ENV = 'local'
# PRG_ENV = 'render.com'

if PRG_ENV == 'local':
    from dotenv import load_dotenv
    load_dotenv()
else:
    print('running on render.com')

import os
import anvil.server

CI_WEBAPP_CLIENT_UPLINK = os.getenv('CI_WEBAPP_CLIENT_UPLINK')
# print(f"web client uplink is: {CI_WEBAPP_CLIENT_UPLINK}", flush=True)
LLM_API_KEYS = {
    'alibaba_qwen': os.getenv('CI_ALIBABA_QWEN_KEY'),
    'deepseek': os.getenv('CI_DEEPSEEK_KEY'),
    'google_gemini': os.getenv('CI_GOOGLE_GEMINI_KEY'),
    'openai': os.getenv('CI_OPENAI_SVC_KEY')
}

# ************************* Alibaba QWEN - START ********************************************
import dashscope
dashscope.base_http_api_url = 'https://dashscope-intl.aliyuncs.com/api/v1'
QWEN_KEY = LLM_API_KEYS.get('alibaba_qwen')
# print('\n\n\n')
# print(f"LLM Key: {QWEN_KEY}")
# print('\n\n\n')
dashscope.api_key = QWEN_KEY
from llm_alibaba_qwen_async import AlibabaModelStudioLLM
LLM_MODEL_NAME = 'qwen-plus'
QWEN_MODEL = AlibabaModelStudioLLM(llm_model_name=LLM_MODEL_NAME)  # 'qwen-turbo', 'qwen-plus'
# ************************* Alibaba QWEN - END ********************************************

from pydantic import BaseModel
from typing import Union

class AuthenticatedUser(BaseModel):
    username: str
    enabled: Union[bool, None]
    admin: Union[bool, None]
    ci_api: Union[bool, None]
    ci_web_app: Union[bool, None]
    ci_quest: Union[bool, None]


app = FastAPI(title="Cerebro Index API", version="1.0")
security = HTTPBasic()

# In-memory user store (username: password)
# USERS: Dict[str, str] = {
#     "user1": "secret",
#     "alice": "wonderland",
#     "bob": "builder"
# }


def authenticate(credentials: HTTPBasicCredentials = Depends(security)):
    # # 1a) In-memory
    # stored_password = USERS.get(credentials.username)
    # if not stored_password or not secrets.compare_digest(credentials.password, stored_password):
    #     raise HTTPException(
    #         status_code=status.HTTP_401_UNAUTHORIZED,
    #         detail="Invalid credentials",
    #         headers={"WWW-Authenticate": "Basic"},
    #     )
    # return credentials.username

    user_email = credentials.username
    user_pass = credentials.password

    # print('*'*30)
    # print(CI_WEBAPP_CLIENT_UPLINK)
    # print('*' * 30)
    anvil.server.connect(CI_WEBAPP_CLIENT_UPLINK)
    res = anvil.server.call('validate_user', user_email, user_pass)

    # debug code
    # print(f"\nResponse from Anvil User Authentication: {type(res)}\n{res}\n")

    if not res:
        # Anvil returned None, it means that User Account was not authenticated.
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
            headers={"WWW-Authenticate": "Basic"},
        )
    else:
        if res.get('enabled'):
            return AuthenticatedUser(
                username=user_email,
                enabled=res.get('enabled'),
                admin=res.get('admin'),
                ci_api=res.get('CI_API'),
                ci_web_app=res.get('CI_WEB_APP'),
                ci_quest=res.get('CI_QUEST'),
            )

    return None


@app.get("/")
async def root():
    # return {"message": f"Uplink is: {CI_WEBAPP_CLIENT_UPLINK}"}
    return {"message": "Hello World from CI API"}

# 'question' is the resource, 'cerebro-index' is the action being taken.
@app.post("/v1/question/cerebro-index", response_model=ComplexityResponse)
async def evaluate_complexity(data: QuestionInput, user: AuthenticatedUser = Depends(authenticate)):
    if not user.ci_api:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
            headers={"WWW-Authenticate": "Basic"},
        )

    # i.e. get the Cerebro Index of the question
    question = data.question_text
    if not question:
        raise HTTPException(status_code=400, detail="Questions need to be provided to API.")

    result = await analyse_complexity(question=data, llm_model=QWEN_MODEL, response_format='json', debug=False)

    # print()
    # print(type(result))
    # print(result)
    # print(result.question.get("question_id"))
    # print()
    # response[0].get('result')
    #
    anvil.server.connect(CI_WEBAPP_CLIENT_UPLINK)
    _ = anvil.server.call('update_token_usage',
                          user.username,
                          "cerebro_index",
                          LLM_MODEL_NAME,
                          None,  # quiz_id is not applicable
                          result.question.get("question_id"),
                          result.total_tokens,
                          result.input_tokens,
                          result.output_tokens)

    return {"result": result}

@app.post("/v1/question/bloom-taxonomy", response_model=BLTXResponse)
# async def evaluate_bltx(data: BLTXQuestionInput, user: AuthenticatedUser = Depends(authenticate)):
async def evaluate_bltx(data: QuestionInput, user: AuthenticatedUser = Depends(authenticate)):
    if not user.ci_api:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
            headers={"WWW-Authenticate": "Basic"},
        )

    question = data.question_text
    if not question:
        raise HTTPException(status_code=400, detail="Questions need to be provided to API.")
    result = await analyse_bloom_taxonomy(question=data, llm_model=QWEN_MODEL, response_format='json', debug=False)
    anvil.server.connect(CI_WEBAPP_CLIENT_UPLINK)
    _ = anvil.server.call('update_token_usage',
                          user.username,
                          "bltx",
                          LLM_MODEL_NAME,
                          None,  # quiz_id is not applicable
                          result.question.get("question_id"),
                          result.details.get('token_usage').get('total_tokens'),
                          result.details.get('token_usage').get('input_tokens'),
                          result.details.get('token_usage').get('output_tokens'))
    return {"result": result}

@app.post("/v1/question/ambiguity", response_model=AMBResponse)
async def evaluate_amb(data: QuestionInput, user: AuthenticatedUser = Depends(authenticate)):
    if not user.ci_api:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
            headers={"WWW-Authenticate": "Basic"},
        )

    question = data.question_text
    if not question:
        raise HTTPException(status_code=400, detail="Questions need to be provided to API.")
    result = await analyse_ambiguity(question=data, llm_model=QWEN_MODEL, response_format='json', debug=False)
    anvil.server.connect(CI_WEBAPP_CLIENT_UPLINK)
    _ = anvil.server.call('update_token_usage',
                          user.username,
                          "amb",
                          LLM_MODEL_NAME,
                          None,  # quiz_id is not applicable
                          result.question.get("question_id"),
                          result.details.get('token_usage').get('total_tokens'),
                          result.details.get('token_usage').get('input_tokens'),
                          result.details.get('token_usage').get('output_tokens'))
    return {"result": result}

@app.post("/v1/question/information-density", response_model=INFDResponse)
async def evaluate_infd(data: QuestionInput, user: AuthenticatedUser = Depends(authenticate)):
    if not user.ci_api:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
            headers={"WWW-Authenticate": "Basic"},
        )

    question = data.question_text
    if not question:
        raise HTTPException(status_code=400, detail="Questions need to be provided to API.")
    result = await analyse_information_density(question=data, llm_model=QWEN_MODEL, response_format='json', debug=False)
    anvil.server.connect(CI_WEBAPP_CLIENT_UPLINK)
    _ = anvil.server.call('update_token_usage',
                          user.username,
                          "infd",
                          LLM_MODEL_NAME,
                          None,  # quiz_id is not applicable
                          result.question.get("question_id"),
                          result.details.get('token_usage').get('total_tokens'),
                          result.details.get('token_usage').get('input_tokens'),
                          result.details.get('token_usage').get('output_tokens'))
    return {"result": result}

@app.post("/v1/question/syntactic-complexity", response_model=STCResponse)
async def evaluate_stc(data: QuestionInput, user: AuthenticatedUser = Depends(authenticate)):
    if not user.ci_api:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
            headers={"WWW-Authenticate": "Basic"},
        )

    question = data.question_text
    if not question:
        raise HTTPException(status_code=400, detail="Questions need to be provided to API.")
    result = await analyse_syntactic_complexity(question=data, llm_model=QWEN_MODEL, response_format='json',
                                                debug=False)
    anvil.server.connect(CI_WEBAPP_CLIENT_UPLINK)
    _ = anvil.server.call('update_token_usage',
                          user.username,
                          "stc",
                          LLM_MODEL_NAME,
                          None,  # quiz_id is not applicable
                          result.question.get("question_id"),
                          result.details.get('token_usage').get('total_tokens'),
                          result.details.get('token_usage').get('input_tokens'),
                          result.details.get('token_usage').get('output_tokens'))
    return {"result": result}

@app.post("/v1/question/conceptual-interconnectedness", response_model=CICResponse)
async def evaluate_cic(data: QuestionInput, user: AuthenticatedUser = Depends(authenticate)):
    if not user.ci_api:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
            headers={"WWW-Authenticate": "Basic"},
        )

    question = data.question_text
    if not question:
        raise HTTPException(status_code=400, detail="Questions need to be provided to API.")
    result = await analyse_conceptual_interconnectedness(question=data, llm_model=QWEN_MODEL, response_format='json',
                                                         debug=False)
    anvil.server.connect(CI_WEBAPP_CLIENT_UPLINK)
    _ = anvil.server.call('update_token_usage',
                          user.username,
                          "cic",
                          LLM_MODEL_NAME,
                          None,  # quiz_id is not applicable
                          result.question.get("question_id"),
                          result.details.get('token_usage').get('total_tokens'),
                          result.details.get('token_usage').get('input_tokens'),
                          result.details.get('token_usage').get('output_tokens'))
    return {"result": result}

@app.post("/v1/question/guessing-susceptibility", response_model=GSResponse)
async def evaluate_gs(data: QuestionInput, user: AuthenticatedUser = Depends(authenticate)):
    if not user.ci_api:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
            headers={"WWW-Authenticate": "Basic"},
        )

    question = data.question_text
    if not question:
        raise HTTPException(status_code=400, detail="Questions need to be provided to API.")
    result = await analyse_guessing_susceptibility(data, llm_model=QWEN_MODEL, response_format='json',
                                                   answer_leakage_strict_detection=False,
                                                   display_status=True, debug=False)
    anvil.server.connect(CI_WEBAPP_CLIENT_UPLINK)
    _ = anvil.server.call('update_token_usage',
                          user.username,
                          "gs",
                          LLM_MODEL_NAME,
                          None,  # quiz_id is not applicable
                          result.question.get("question_id"),
                          result.details.get('token_usage').get('total_tokens'),
                          result.details.get('token_usage').get('input_tokens'),
                          result.details.get('token_usage').get('output_tokens'))
    return {"result": result}

@app.post("/v1/question/generate", response_model=QuestionPromptResponse)
async def generate_question(data: QuestionPromptInput, user: AuthenticatedUser = Depends(authenticate)):
    """

    :param data:
    :param user:
    :return:
    """
    if not user.ci_api:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
            headers={"WWW-Authenticate": "Basic"},
        )

    # todo: to think of other prompt engineering methods to reduce duplicate questions being generated.
    #  Preferably don't need to pull previous question from database and insert into prompt,
    #  because this is computationally very expensive and also all the additional tokens used could
    #  be financially expensive too. Maybe think of scenarios, perspectives, topic trees etc?

    # print(f"\n\ntype(data): {type(data)} -->\n{data}\n\n")
    # question_dict = {"temp": "commented out"}

    generation_error = None

    res = await generate_question_from_prompt(input_args=data, llm_model=QWEN_MODEL, response_format='json',
                                              reprompt=True, display_status=True, debug=False)

    if res is None:
        return {"error": "Error: Response from API Server is None. Unknown Error."}
    elif res.get("generation_error") is not None and len(res.get("generation_error")) > 0:
        return {"error": {res.get("generation_error")}}

    ci_explanation = res.get('ci_explanation')
    if ci_explanation:
        ci_total_tokens = ci_explanation.get('total_tokens', 0)
        ci_input_tokens = ci_explanation.get('input_tokens', 0)
        ci_output_tokens = ci_explanation.get('output_tokens', 0)
    else:
        ci_total_tokens = 0
        ci_input_tokens = 0
        ci_output_tokens = 0

    gen_quest_token_usage = res.get('gen_quest_token_usage')
    if gen_quest_token_usage:
        gen_quest_total_tokens = gen_quest_token_usage.get('gen_quest_total_tokens', 0)
        gen_quest_input_tokens = gen_quest_token_usage.get('gen_quest_input_tokens', 0)
        gen_quest_output_tokens = gen_quest_token_usage.get('gen_quest_output_tokens', 0)
    else:
        gen_quest_total_tokens = 0
        gen_quest_input_tokens = 0
        gen_quest_output_tokens = 0

    total_tokens = ci_total_tokens + gen_quest_total_tokens
    input_tokens = ci_input_tokens + gen_quest_input_tokens
    output_tokens = ci_output_tokens + gen_quest_output_tokens

    anvil.server.connect(CI_WEBAPP_CLIENT_UPLINK)
    _ = anvil.server.call('update_token_usage',
                          user.username,
                          "gen_quest",
                          LLM_MODEL_NAME,
                          None,  # quiz_id is not applicable
                          res.get("id"),
                          total_tokens,
                          input_tokens,
                          output_tokens
    )

    insert_status = None
    try:
        ci_summary = (res.get('ci_explanation').get('bltx').get('overall_summary') + " " +
                  res.get('ci_explanation').get('amb').get('overall_summary') +
                  res.get('ci_explanation').get('infd').get('overall_summary') +
                  res.get('ci_explanation').get('stc').get('overall_summary') +
                  res.get('ci_explanation').get('cic').get('overall_summary') +
                  res.get('ci_explanation').get('gs').get('overall_summary'))

        question_format = res.get('type')
        if question_format == "mcq":
            question_hash, user_question_hash = get_question_hash_token(user_email=user.username,
                                                                        question_format=question_format,
                                                                        question_text=res.get('question'),
                                                                        mcq_options=res.get('options'), debug=False)
        elif question_format == "true_false" or question_format == "short_answer":
            question_hash, user_question_hash = get_question_hash_token(user_email=user.username,
                                                                        question_format=question_format,
                                                                        question_text=res.get('question'),
                                                                        mcq_options=None,
                                                                        debug=False)
        else:
            return {'error': 'Error: Generate Question ---> Unknown Question Format.'}

        hint = ' '.join(res.get('hint', []))  # convert from list to a single string

        question_id = res.get('id')
        creator = user.username
        shareable_read_only = data.shareable_read_only
        llm_used = LLM_MODEL_NAME

        domain = data.domain
        question_text = res.get('question')
        question_format = question_format

        mcq_options = res.get('options')
        mcq_correct_indices = res.get('correct_indices')
        question_hash = question_hash
        user_question_hash = user_question_hash
        tf_correct_value = res.get('correct_value')
        tf_correct_ans_explanation = res.get('correct_ans_explanation')
        tf_incorrect_ans_explanation = res.get('incorrect_ans_explanation')
        sa_expected_answer = res.get('expected_answer')
        sa_expected_ans_explanation = res.get('expected_ans_explanation')

        hint = hint
        allowed_time_s = res.get('allowed_time_s')
        points = res.get('points')

        ci_score = res.get('ci')
        ci_summary = ci_summary
        ci_component_scores = res.get('ci_explanation').get('component_scores')

        bltx = res.get('ci_explanation').get('bltx')
        amb = res.get('ci_explanation').get('amb')
        cic = res.get('ci_explanation').get('cic')
        gs = res.get('ci_explanation').get('gs')
        infd = res.get('ci_explanation').get('infd')
        stc = res.get('ci_explanation').get('stc')

        creation_prompt = res.get('prompt_used')
        prompt_persona = res.get("prompt_persona")
        prompt_complexity_level = data.complexity_level
        gen_quest_input_tokens = res.get("gen_quest_token_usage").get("gen_quest_input_tokens")
        gen_quest_output_tokens = res.get("gen_quest_token_usage").get("gen_quest_output_tokens")
        gen_quest_total_tokens = res.get("gen_quest_token_usage").get("gen_quest_total_tokens")

        generation_error = res.get('generation_error')
        print(f"\ngeneration_error --> {generation_error}\n")
        if generation_error is not None:
            return {"generated_question": None, "insert_status": None,
                    "generation_error": generation_error}


        # rc: debug code - comment out after testing - don't delete, it takes AGES to key in
        # print("\n", "*"*120, "\n")
        # print(f"question_id: {question_id}")
        # print(f"creator: {creator}")
        # print(f"shareable_read_only: {shareable_read_only}, type: {type(shareable_read_only)}")
        #
        # print(f"domain: {domain}")
        # print(f"question_text: {question_text}")
        # print(f"question_format: {question_format}")
        #
        # print(f"mcq_options: {mcq_options}")
        # print(f"mcq_correct_indices: {mcq_correct_indices}")
        # print(f"question_hash: {question_hash}")
        # print(f"user_question_hash: {user_question_hash}")
        # print(f"tf_correct_value: {tf_correct_value}, type: {type(tf_correct_value)}")
        # print(f"tf_correct_ans_explanation: {tf_correct_ans_explanation}")
        # print(f"tf_incorrect_ans_explanation: {tf_incorrect_ans_explanation}")
        # print(f"sa_expected_answer: {sa_expected_answer}")
        # print(f"sa_expected_ans_explanation: {sa_expected_ans_explanation}")
        #
        # print(f"hint: {hint}")
        # print(f"allowed_time_s: {allowed_time_s}")
        # print(f"points: {points}")
        #
        # print(f"ci_score: {ci_score}")
        # print(f"ci_summary: {ci_summary}")
        # print(f"ci_component_scores: {ci_component_scores}")
        #
        # print('\n', '-' * 120)
        # print(f"bltx: {bltx}")
        # print(f"amb: {amb}\n")
        # print(f"cic: {cic}\n")
        # print(f"gs: {gs}\n")
        # print(f"infd: {infd}\n")
        # print(f"stc: {stc}\n")
        # print('-' * 120, '\n')
        #
        # print(f"\ncreation_prompt: {creation_prompt}")
        # print(f"prompt_persona: {prompt_persona}")
        # print(f"prompt_complexity_level: {prompt_complexity_level}")
        # print(f"gen_quest_input_tokens: {gen_quest_input_tokens}")
        # print(f"gen_quest_output_tokens: {gen_quest_output_tokens}")
        # print(f"gen_quest_total_tokens: {gen_quest_total_tokens}")
        # print("\n", "*" * 120, "\n")

        insert_status = anvil.server.call('add_question_to_table',
                                          question_id, creator, shareable_read_only, llm_used,
                                          domain, question_text, question_format,
                                          mcq_options, mcq_correct_indices, question_hash, user_question_hash,
                                          tf_correct_value, tf_correct_ans_explanation, tf_incorrect_ans_explanation,
                                          sa_expected_answer, sa_expected_ans_explanation,
                                          hint, allowed_time_s, points,
                                          ci_score, ci_summary, ci_component_scores,
                                          bltx, amb, cic, gs, infd, stc,
                                          creation_prompt, prompt_persona, prompt_complexity_level,
                                          gen_quest_input_tokens, gen_quest_output_tokens, gen_quest_total_tokens)

        print(f"\n\nInsert Status: {insert_status}")
        if insert_status is None:
            return {"generated_question": None, "insert_status": "Failed to save question to database.",
                    "generation_error": None}
    except Exception as e:
        print(f"\n\n{e}\n\n")
        return {"generated_question": res, "insert_status": insert_status, "generation_error": generation_error}

    # debug code
    # print('*' * 100)
    # print(f"\n\nres.keys() --> {res.keys()}\n\n")
    # print(f"\ntype(res): {type(res)}\n{res}\n\n")
    return {"generated_question": res, "insert_status": insert_status, "generation_error": generation_error}



@app.post("/v1/quiz/generate", response_model=QuizPromptResponse)
async def generate_quiz(data: QuizPromptInput, user: AuthenticatedUser = Depends(authenticate)):
    """
    This fn does the following:
    -   When given user specifications, it computes the number of questions, their question format and
        associated CI scores required to form a Quiz.
    -   To do this, a GA is used which draws on the questions previously generated by the user or other
        users who have flagged their questions as 'shareable_read_only' = True.
    -   If there are insufficient questions, the GA will provide the best possible quiz it can under the circumstances,
        and inform user to generate more questions.
    -   To avoid pulling duplicate questions in the quiz, the algorithm will first check if the question_hash exists
        before putting the new question in the population.

    :param data:
    :param user:
    :return:
    """
    if not user.ci_api:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
            headers={"WWW-Authenticate": "Basic"},
        )

    return_error = False
    return_error_msg = ''
    quiz_generation_error = False
    quiz_generation_error_msg = ''
    insert_quiz_error = False
    # insert_quiz_msg = ''

    # debug code
    # print(f"\n\nShow what user sent to API:\n{data}\n\n")

    # rchai quiz
    # 1.0 Get user's previously generated questions and perhaps those shared by other users
    anvil.server.connect(CI_WEBAPP_CLIENT_UPLINK)
    res = anvil.server.call('get_user_questions_for_quiz_ga', user.username, data.domain,
                            data.add_shareable_read_only)
    avail_quests = []
    if res:
        avail_quests = [GAQuestion(question_id=q[0],
                                   question_format=qf_str_to_question_format(q[1]),
                                   ci_score=q[2],
                                   ci_complexity_category=ci_score_2_ci_category(q[2]),
                                   llm_complexity_category=q[3]) for q in res]
    else:
        return_error_msg = "Error: 0 questions retrieved from questions table."
        data_to_return = {"quiz": None,
                          'insert_status': None,
                          'generation_error': {'status': 'error', 'message': return_error_msg}}
        return data_to_return

    # import pickle
    # file_name = 'user_question_data_FastAPI_main.pkl'
    # with open(file_name, 'wb') as f:
    #     pickle.dump(avail_quests, f)

    # with open(file_name, 'rb') as f:
    #     avail_quests = pickle.load(f)

    # debug line
    print(f'\nAvailable Quests --> len: {len(avail_quests)}')
    # for quest in avail_quests[:3]:
    #     print(quest)

    # 2.0 Send user specs to GA and get best quiz, which consists of List[GAQuestions} & metadata
    ga_params = {
        'population_size': 80,  # 50  # how many quiz (chromosomes) there are in a population.
        'generations': 120,  # 100  # how many generations i.e. loops for GA to operate on a population
        'crossover_rate': 0.8,
        'mutation_rate': 0.1,
        'elitism': 2
    }

    # rchai GA user params
    input_args = {
        "num_questions": data.num_questions,
        'avg_quiz_complexity': data.quiz_complexity_score,
        'quiz_distribution': {qf_str_to_question_format(qf): p_value for qf, p_value in
                              data.question_format_distribution.items()}
    }

    print("Initialising GA")
    quiz_ga = GenQuizGA(avail_quests=avail_quests, constraints=input_args, ga_params=ga_params, debug=False)
    print("Searching for Best Quiz.")
    final_result = await quiz_ga.generate_the_quiz(display=False, early_stopping=True, debug=False)

    final_result_error = False
    if isinstance(final_result, dict):
        if final_result.get('status').lower().strip() == 'error':
            final_result_error = True

    avg_quiz_complexity = -9999.99  # if caller see this, means that there is an error.
    if not final_result_error:
        question_format_counts = {}
        for quest in final_result.quiz_questions:
            if question_format_counts.get(quest.question_format) is None:
                question_format_counts[quest.question_format] = 1
            else:
                question_format_counts[quest.question_format] += 1

        # Get Quiz Average CI score
        quiz_complexities = sorted([quest.ci_score for quest in final_result.quiz_questions])
        total_quiz_complexity = sum(quiz_complexities)
        avg_quiz_complexity = total_quiz_complexity / len(final_result.quiz_questions)

        # debug code
        print(f"Complexity Scores - All Quizzes: {quiz_complexities}")
        print(f"Complexity Scores = Avg: {round(avg_quiz_complexity, 3)}")
        # print(f"Num of Quiz Questions: {len(final_result.quiz_questions)}")
        # for KEY, VALUE in question_format_counts.items():
        #     print(f"{KEY}: {VALUE}")
        # print(f"\nFrom Class itself:")
        # print(f"Fitness - Best: {round(final_result.fitness, 3)}")
        # print(f"Best Quiz:\n{final_result}")
    else:
        print(f"\nError: {final_result}")

    calc_ci = CalcCerebroIndex(llm=QWEN_MODEL, response_format='json', debug=False)
    quiz = Quiz(
        domain=data.domain,
        avg_quiz_complexity=round(avg_quiz_complexity, 2),
        make_quiz_shareable_read_only=data.make_quiz_shareable_read_only,
        quiz_title=data.quiz_title,
        quiz_description=data.quiz_description,
        allowed_time_s=None,
        points=None,
        passing_score=None,
        quiz_id=None  # Quiz Constructor will create it
    )

    # debug code
    # print('\n\n')
    print('*'*80)
    print(f"Best Quiz Fitness: {round(final_result.fitness, 3)}")

    # debug code
    # for quest in final_result.quiz_questions:
    #     # print(type(quest))
    #     print(quest.question_id)
    # print('*' * 80)
    # print('\n\n')

    # Get Question Data
    quest_ids = [quest.question_id for quest in final_result.quiz_questions]

    # debug code
    # print(f"quest_ids:\n{quest_ids}")

    anvil.server.connect(CI_WEBAPP_CLIENT_UPLINK)
    question_data = anvil.server.call('get_user_questions_by_qid', user.username, quest_ids, 30)

    questions_list = []
    if question_data:
        for quest in question_data:
            if quest.get("question_format") == 'mcq':
                mcq = MCQQuestion(
                    question_text=quest.get("question_text"),
                    options=quest.get("mcq_options"),
                    correct_indices=quest.get("mcq_correct_indices"),
                    allowed_time_s=quest.get("allowed_time_s"),
                    points=quest.get("points"),
                    hint=quest.get("hint"),
                    ci=quest.get("ci_score"),
                    ci_explanation=quest.get("ci_summary"),
                    calc_ci_obj=calc_ci,
                    qid=quest.get("question_id")
                )
                questions_list.append(mcq)
            elif quest.get("question_format") == 'short_answer':
                sa = ShortAnswerQuestion(
                    question_text=quest.get("question_text"),
                    expected_answer=quest.get("sa_expected_answer"),
                    expected_ans_explanation=quest.get("sa_expected_ans_explanation"),
                    allowed_time_s=quest.get("allowed_time_s"),
                    points=quest.get("points"),
                    hint=quest.get("hint"),
                    ci=quest.get("ci_score"),
                    ci_explanation=quest.get("ci_summary"),
                    calc_ci_obj=calc_ci,
                    qid=quest.get("question_id")
                )
                questions_list.append(sa)
            elif quest.get("question_format") == 'true_false':
                tf = TrueFalseQuestion(
                    question_text=quest.get("question_text"),
                    correct_value=quest.get("tf_correct_value"),
                    correct_ans_explanation=quest.get("tf_correct_ans_explanation"),
                    incorrect_ans_explanation=quest.get("tf_incorrect_ans_explanation"),
                    allowed_time_s=quest.get("allowed_time_s"),
                    points=quest.get("points"),
                    hint=quest.get("hint"),
                    ci=quest.get("ci_score"),
                    ci_explanation=quest.get("ci_summary"),
                    calc_ci_obj=calc_ci,
                    qid=quest.get("question_id")
                )
                questions_list.append(tf)
            else:
                print("Data from Question Table has Error in Question Format.")
                return_error = True

        questions_list = sorted(questions_list, key=lambda x: (x.question_type, x.ci))
        for quest in questions_list:
            quiz.add_question(quest)

        # Save Quiz to Anvil (for questions, just the q_id)
        anvil.server.connect(CI_WEBAPP_CLIENT_UPLINK)
        _ = anvil.server.call(
            'add_quiz_to_table',
            quiz_id=str(quiz.quiz_id),
            created_by=user.username,
            shareable_read_only=data.make_quiz_shareable_read_only,
            method_used='GA',
            quiz_title=data.quiz_title,
            quiz_description=data.quiz_description,
            domain=data.domain,
            domain_cluster_id=None,
            domain_clauster_name=None,
            avg_quiz_complexity=quiz.avg_quiz_complexity,
            allowed_time_s=None,
            passing_score=None,
            points=None,
            total_questions=quiz.total_questions,
            num_mcq_questions=quiz.num_mcq_questions,
            num_short_answer_questions=quiz.num_short_answer_questions,
            num_true_false_questions=quiz.num_true_false_questions,
            question_ids=quest_ids
        )
    else:
        print("Question Data NOT received.")

    # Save token usage to Anvil. In the future, find an appropriate mthd to calc token usage.
    anvil.server.connect(CI_WEBAPP_CLIENT_UPLINK)
    _ = anvil.server.call('update_token_usage',
                          user.username,
                          "gen_quiz",
                          LLM_MODEL_NAME,
                          str(quiz.quiz_id),
                          None,  # question_id is not applicable for recording in table: token_usage
                          20000, # total_tokens (currently an arbitrary number)
                          5000, # input_tokens (currently an arbitrary number)
                          15000  #  output_tokens (currently an arbitrary number)
                          )

    if not quiz_generation_error and not return_error and not insert_quiz_error:
        data_to_return = {"quiz": quiz.to_dict(),
                'insert_status': {'status': 'no error', 'message': 'quiz has been saved to database table.'},
                'generation_error': {'status': 'no error', 'message': 'quiz is successfully generated.'}}
    else:
        data_to_return =  {"quiz": quiz_generation_error_msg,
                'insert_status': {'status': 'error', 'message': insert_quiz_error},
                'generation_error': {'status': 'error', 'message': return_error_msg}}

    # debug line
    # print('debug --> This is what is sent back to the user.')
    # print(data_to_return)

    return data_to_return


@app.post("/v1/admin/only", response_model=dict)
def admin_only_endpoint(data: dict, user: AuthenticatedUser = Depends(authenticate)):
    if not user.admin:
        raise HTTPException(status_code=403, detail="Access forbidden: Admins only.")
    # Proceed with admin-specific logic
    return {"message": f"Welcome, admin -> {user.username}! You sent us this data:\n{data}"}



"""
https://fastapi.tiangolo.com/fastapi-cli/
to start fastapi server during dev:
$> fastapi dev main.py
For production you would use 'fastapi run' instead
Internally, FastAPI CLI uses Uvicorn, a high-performance, production-ready, ASGI server.

check the Prog_Env (at top of this file) is set correctly.
"""