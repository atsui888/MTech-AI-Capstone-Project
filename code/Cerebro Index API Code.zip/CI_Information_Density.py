from pydantic import BaseModel
from input_models import QuestionInput
from output_models import EvaluationOutput
import time
from api_helper import safe_json_loads
from infd_prompt import load_prompt

# This route classifies the Information Density (INFD) of a given question,

class INFDResponse(BaseModel):
    result: EvaluationOutput

async def analyse_information_density(question: QuestionInput, llm_model, response_format='json',
                                      display_status=True, debug=False) -> EvaluationOutput:
    """

    :param question:
    :param llm_model:
    :param response_format:
    :param display_status:
    :param debug:
    :return:
    """
    if display_status:
        print("START ------> Calculating Information Density Score ******************")

    comments = ''
    llm_error = 'None'
    try_num = 1
    max_tries = 5
    # avg_score = 0.4  # in case LLM gives error, 0.4 results in info density of 1.0 i.e. do no harm. CI * 1.0 = CI
    overall_summary = None
    criteria_explanations = None
    question_attributes = None
    criteria_scores = None
    input_tokens = 0
    total_tokens = 0
    output_tokens = 0
    lexical_density_pct = 0
    # lexical_density_score = 0

    while try_num < max_tries:
        if display_status:
            print(f"\nCheck Information Density --> Try Number: {try_num}\n***********************")

        msgs = [{"role": "user", "content": load_prompt()}]
        result = await llm_model.ask_llm(messages=msgs, response_format=response_format)
        completion = safe_json_loads(result.get('completion')) if result else None
        if completion:
            llm_error = result.get('error')
            # completion = json.loads(result.get('completion'))
            if debug:
                print(f"\nDEBUG\n{type(completion)}\n{completion}\n")

            # next line checks if the LLM returned an empty json
            if completion.get('overall_summary') is not None and len(completion.get('overall_summary')) > 0:
                overall_summary = completion.get('overall_summary')
                criteria_explanations = completion.get('criteria_explanations')

                # criteria_scores = completion.get('criteria_scores')
                # total_score = 0.0
                # for score in criteria_scores.values():
                #     total_score += score
                # avg_score = round(total_score / len(criteria_scores), 3)

                question_attributes = completion.get('question_attributes')
                num_lexical_words = len(set(question_attributes.get('lexical_words_found')))
                # print(f"num lexical words: {num_lexical_words}")

                total_words_in_q = len(question.question_text.split())
                # print(f"The question is: {question.question_text}")
                # print(f"type(question.question_text): {type(question.question_text)}")
                # print(f"total words: {total_words_in_q}")

                if total_words_in_q > 0:
                    lexical_density_pct = num_lexical_words / total_words_in_q
                else:
                    lexical_density_pct = 0.0
                criteria_scores = {'lexical_density_pct': round(lexical_density_pct, 2)}

                # replace with my calculated values coz LLM sometimes counts wrongly.
                question_attributes['num_lexical_words'] = num_lexical_words
                question_attributes['total_words'] = total_words_in_q

                if debug:
                    print('\n', 'DEBUG *********************************')
                    print(f"Overall Summary --->\n{overall_summary}\n")
                    for k, v in criteria_explanations.items():
                        print(f"{k}:\n{v}")
                    print()
                    # for k, v in criteria_scores.items():
                    #     print("Criteria Scores is not used as LLM does not consistently count the total number of "
                    #           "words in a question correctly. Hence, it is done outside the LLM call.")
                    #     print(f"{k}: {v}")
                    # print(f"Average Score:\n{avg_score}")

                usage = result.get('usage')
                input_tokens += usage.get('input_tokens')
                output_tokens += usage.get('output_tokens')
                total_tokens += usage.get('total_tokens')
                if debug:
                    print(f"input_tokens: {input_tokens}")
                    print(f"output_tokens: {output_tokens}")
                    print(f"total_tokens: {total_tokens}")

                question_attributes = completion.get('question_attributes')
                # if question_attributes is not None and isinstance(question_attributes, dict):
                #     for k, v in question_attributes.items():
                #         comments += f"'{k}': {v} | "
                if debug:
                    print(f"Question Attributes:\n{question_attributes}")

                try_num = max_tries
        time.sleep(1)
        try_num += 1
        if display_status:
            print(f"\nCheck Information Density --> End Try ***********************\n")

    if lexical_density_pct >= 0.92:
        lexical_density_score = 5
    elif lexical_density_pct >= 0.55:
        lexical_density_score = 4
    elif lexical_density_pct >= 0.4:
        lexical_density_score = 3
    elif lexical_density_pct >= 0.3:
        lexical_density_score = 2
    else:
        lexical_density_score = 1

    lexical_density_score_to_info_density_score = {
        1: 5,
        2: 3,
        3: 1,
        4: 1,
        5: 5
    }
    information_density_complexity_score = (
            1.0 + (lexical_density_score_to_info_density_score[lexical_density_score] - 1) * (1.0 / 4))

    if display_status:
        print("END ------> Calculating Information Density Score ******************\n")

    return EvaluationOutput(
        question=question.model_dump(),
        eval_type='infd',
        score=information_density_complexity_score,
        explanation="Information density refers to how much meaning is conveyed in a given unit of language. "
                    "Higher density means more meaning with fewer words. The amount of meaningful information in a "
                    "question influences its complexity.",
        details={
            'overall_summary': overall_summary,
            'criteria_explanations': criteria_explanations,
            'criteria_scores': criteria_scores,
            'token_usage': {
                'total_tokens': total_tokens,
                'input_tokens': input_tokens,
                'output_tokens': output_tokens
            },
            'question_attributes': question_attributes,
            'llm_error': llm_error,
            'comments': comments.removesuffix('| ').strip()
        }
    )
