# helper code when dealing with external APIs

import json
import hashlib
from datetime import datetime
from typing import List, Union


def safe_json_loads(data):
    # checks if data is valid json or not
    """
    # usage:
    completion = safe_json_loads(result.get('completion')) if result else None

    if completion:
        print("Valid JSON:", completion)
    else:
        print("No valid completion data")
    """

    if not data or not isinstance(data, str) or not data.strip():
        return None
    try:
        return json.loads(data)
    except json.JSONDecodeError:
        return None

def get_uniqueness_token():
    now = datetime.now().isoformat()
    return hashlib.sha256(now.encode()).hexdigest()

def remove_punctuation(s: str):
    return ''.join(c for c in s if c.isalnum() or c.isspace())

def get_question_hash_token(user_email: str, question_format: str, question_text: str, mcq_options: Union[None, List[dict]]=None,
                            debug=False):
    """
    question_hash consists of "question_format" + "question_text" + "additionals specific to question_format"
    note that punctuation is removed before hashing. lower case + strip is performed
    e.g.
        short_answer
        ------------
        hash("sa what colour is the sky")

        true_false
        ----------
        hash("sa The sky is blue, isn't it?")

        mcq
        ---
        hash("mcq what colour is the sky opt_1.text opt_2.text opt_N.text")

    :param user_email:
    :param question_format:
    :param question_text:
    :param mcq_options:
    :param debug:
    :return:
    """

    """
    Issue: Questions may be duplicates buy yet inaccessible to a specific user or not consistently accessible to a user
	because:
		- Shareable is set to False
		- Shareable status can be changed at will 
	Resolution:
		A question that is saved to the Questions Table has 2 hashes:
		- question_hash: this consists of either 
			a. (question_format + question_text) for true_false and short_answer questions or
			b. (question_format + question_text + mcq_options) for mcq questions
		- user_question_hash
			where user_email is prepended to either (a) or (b) before hashing
		When saving to the questions table:
			if user_question_hash exists, then the question already exists for that user
			else, save the question including the user_question_hash and the question_hash.
		When a user draws questions from the question table to create a quiz,
			this can consist of their own questions and shareable questions.
			- questions will first be drawn from their own questions.
			- if required, questions will also be drawn from the shareable questions,
				these will be checked using the question_hash. 
				if there are duplicates, that shareable question will not be added to the quiz
				because it already exists. (from the user's own questions)
    """



    tmp_str = question_text
    if question_format == 'mcq':
        for item in mcq_options:  # this code needs to deal with the 2 parts of options.
            tmp_str += " " + item.get('text', '')

    if debug:
        print(f"Before cleaning: {tmp_str}")
    tmp_str = remove_punctuation(tmp_str)
    tmp_str = tmp_str.lower().strip()

    tmp_str = question_format + " " + tmp_str
    if debug:
        print(f"Before hashing: \n{tmp_str}\n{(user_email + ' ' + tmp_str)}")

    question_hash = hashlib.sha256(tmp_str.encode()).hexdigest()
    user_question_hash = hashlib.sha256((user_email + " " + tmp_str).encode()).hexdigest()
    return question_hash, user_question_hash


if __name__ == "__main__":
    # unique_token = get_uniqueness_token()
    # print(unique_token)

    EMAIL = 'abc@zzz.com'
    QUESTION_FORMAT = "mcq"
    QUESTION_TEXT = "What is python ... in I.T.?"
    OPTIONS = [
        {"text": "Language", "explanation": "Python is a programming language"},
        {"text": "Snake", "explanation": "Python is a type of snake."},
        {"text": "Object Oriented", "explanation": "Everything in python is an object."}
    ]
    QUESTION_OPTIONS = [()]  # todo: note that options has 2 parts
    QUESTION_HASH, USER_QUESTION_HASH = get_question_hash_token(EMAIL, QUESTION_FORMAT, QUESTION_TEXT,
                                                                OPTIONS, debug=True)
    print(f"\nquestion hash --> {QUESTION_HASH}")
    print(f"\nuser question hash --> {USER_QUESTION_HASH}")