# Utilities for CI API

import re
import hashlib
from typing import Union

class EmailAddressHelper:
    # Supabase Postgres table name has a constraint of 63 characters.
    MAX_TABLENAME_LEN = 63
    def __init__(self):
        pass

    @staticmethod
    def email_to_table_name(rag_database: str, email_address: str) -> str:
        """
        Convert an email address to a valid, unique PostgreSQL table name.

        Steps:
        1. Lowercase the email.
        2. Replace all non-[a-z0-9_] characters with underscores.
        3. Prefix an underscore if the result starts with a digit.
        4. Truncate to fit an 8-character hash suffix within 63 characters.
        5. Prepend RAG Database Name and Append '_' + first 8 chars of MD5 hash of the original email.

        :param rag_database: Name of Rag Database that this user table will be crated in
        :param email_address: The user's registered email address.
        :return: the transformed table name: rag_database_email_address
        """
        normalized = email_address.lower() #1. Lowercase

        # 2. Replace invalid characters
        #    Allow only a–z, 0–9, and underscore; replace everything else with '_'
        cleaned = re.sub(r'[^a-z0-9_]', '_', normalized)

        # 3. if start with digit, add a prefix "u_"
        if cleaned and cleaned[0].isdigit():
            cleaned = 'u_' + cleaned

        # 4a Compute 32-bit hash suffix
        hash_suffix = hashlib.md5(email_address.encode()).hexdigest()[:8]

        # 4b. Truncate to accommodate "_" + hash_suffix
        max_name_length = EmailAddressHelper.MAX_TABLENAME_LEN - len(hash_suffix) - 1
        if len(cleaned) > max_name_length:
            cleaned = cleaned[:max_name_length]

        # 5. Append the hash suffix. note that adding rag_database may exceed the postgres table name max len
        table_name = f"{rag_database}___{cleaned}_{hash_suffix}"

        return table_name

    @staticmethod
    def extract_ragdb_tablename(user_table_name: str) -> (Union[None, str], Union[None, str],
                                                          Union[None, str], Union[None, str]):
        """
        Given a tablename created by method email_to_table_name(), extract the rag database name
        and the tablename.
        :param user_table_name:
        :return:
        """
        rag_database, table_name, email_id, suffix_id = None, None, None, None

        parts = user_table_name.split('___', 1)  # Split on the first occurrence of '___'
        if len(parts) == 2:
            rag_database = parts[0]
            table_name = parts[1]

            if table_name is None or len(table_name) < 1:
                email_id = None
                suffix_id = None
            else:
                parts_2 = table_name.rsplit('_', 1)  # Split from the right on the last underscore
                if len(parts_2) == 2:
                    email_id = parts_2[0]
                    # note: 'u_' only occurs if the first char of table name is a digit.
                    parts_3 = email_id.split('u_', 1)  # Split on the first occurrence of 'u_'
                    if len(parts_3) == 2:
                        email_id = parts_3[1]
                    suffix_id = parts_2[1]
                else:
                    SystemError("Error: extract_ragdb_tablename -> Invalid Format")
            return rag_database, table_name, email_id, suffix_id
        else:
            raise SystemError("Error: extract_ragdb_tablename -> Invalid Format")



if __name__ == "__main__":
    EMAIL_ADDRESSES = []

    email_helper = EmailAddressHelper()
    USER_TABLE_NAMES = []
    for email in EMAIL_ADDRESSES:
        USER_TABLE_NAMES.append(email_helper.email_to_table_name(rag_database="rag1", email_address=email))

    for utn in USER_TABLE_NAMES:
        print(utn)
    print()

    for utn in USER_TABLE_NAMES:
        rag_db, table_name, email_address, suffix_id = email_helper.extract_ragdb_tablename(utn)
        print(f"{rag_db} *** {table_name} *** {email_address} *** {suffix_id}")

    pass