from pydantic import BaseModel
from typing import Any, Union

class EvaluationOutput(BaseModel):
    question: dict
    eval_type: str
    score: Union[float, None]
    explanation: Union[str, None]
    details: Any


