from pydantic import BaseModel
from input_models import QuestionInput
from typing import Dict, Union
# import random
import asyncio
from CI_Bloom_Taxonomy import analyse_bloom_taxonomy
from CI_Ambiguity import analyse_ambiguity
from CI_Information_Density import analyse_information_density
from CI_Syntactic_Complexity import analyse_syntactic_complexity
from CI_Conceptual_Interconnectedness import analyse_conceptual_interconnectedness
from CI_Guessing_Susceptibility import analyse_guessing_susceptibility



# This route classifies the CI of a given question, hence there is a class QuestionComplexity
# to hold the complexity scoring result and the explanation for it.

class QuestionComplexity(BaseModel):
    question: dict
    complexity_score: float
    component_scores: dict
    explanation: str
    bltx: Union[None, Dict]
    amb: Union[None, Dict]
    infd: Union[None, Dict]
    stc: Union[None, Dict]
    cic: Union[None, Dict]
    gs: Union[None, Dict]
    total_tokens: int
    input_tokens: int
    output_tokens: int

class ComplexityResponse(BaseModel):
    result: QuestionComplexity

# rc was here
async def analyse_complexity(question: QuestionInput, llm_model, response_format='json', display_status=True,
                             debug=False) -> QuestionComplexity:
    """

    :param question:
    :param llm_model:
    :param response_format:
    :param display_status:
    :param debug:
    :return:
    """
    if display_status:
        print("START ------> Calculating Cerebro Index ******************")

    tasks = [
        analyse_bloom_taxonomy(question=question, llm_model=llm_model, response_format=response_format,
                               display_status=True, debug=False),
        analyse_ambiguity(question=question, llm_model=llm_model, response_format=response_format,
                          display_status=True, debug=False),
        analyse_information_density(question=question, llm_model=llm_model, response_format=response_format,
                                    display_status=True, debug=False),
        analyse_syntactic_complexity(question=question, llm_model=llm_model, response_format=response_format,
                                     display_status=True, debug=False),
        analyse_conceptual_interconnectedness(question=question, llm_model=llm_model, response_format=response_format,
                                              display_status=True, debug=False),
        analyse_guessing_susceptibility(question=question, llm_model=llm_model, response_format=response_format,
                                        answer_leakage_strict_detection=False, display_status=True, debug=False)
    ]

    results = await asyncio.gather(*tasks)

    ci_score = 0.0
    component_scores = {}
    component_details = {}

    total_tokens = 0
    input_tokens = 0
    output_tokens = 0

    if debug:
        print(f"Cerebro Index Score: {ci_score}\n")
    for r in results:
        if r and r.score is not None and r.score >= 0:
            if debug:
                print()
                print(r, '\n')

            component_scores[r.eval_type] = r.score
            component_details[r.eval_type] = r.details
            total_tokens += r.details.get('token_usage').get('total_tokens')
            input_tokens += r.details.get('token_usage').get('input_tokens')
            output_tokens += r.details.get('token_usage').get('output_tokens')
            if debug:
                print(f"eval_type: {r.eval_type} | score: {r.score}")
                print(f"summary: {r.details.get('overall_summary')}")
                # print(f"detail explanation: {r.details.get('criteria_explanations')}")
                # print(f"comments: {r.details.get('comments')}")
                print(f"llm error: {r.details.get('llm_error')}")
                print(f"token usage: {r.details.get('token_usage')}\n")

    """
            Calculate CI and return it rescaled to the interval [0, 10].

            Parameters
            ----------
            bltx : int     # 1–6     nb: this is different from the rest
            amb  : float   # 1.0–2.0
            infd : float   # 1.0–2.0
            stc  : float   # 1.0–2.0
            cic  : float   # 1.0–2.0
            gs   : float   # 0.0–1.0  nb: this is different from the rest

            Returns
            -------
            float
                CI mapped linearly onto [0, 10].
                
            notes: this formula can still change based on latest validation test results.
    """

    # **************** prev method ***********************
    # ci_score = (component_scores.get('bltx', 0) * component_scores.get('amb', 1.0) * component_scores.get('infd', 1.0)
    #             * component_scores.get('stc', 1.0) * component_scores.get('cic', 1.0) * component_scores.get('gs', 1.0))

    # CI_MIN, CI_MAX, DESIRED_MAX = 0.0, 96.0, 10.0
    # ci_mapped = (ci_score - CI_MIN) / (CI_MAX - CI_MIN) * DESIRED_MAX


    # ******************** new method ***************************
    bltx = component_scores.get('bltx', 0)
    bltx_max = 6
    bltx_desired_range_max = 8
    scaled_bltx = bltx / bltx_max * bltx_desired_range_max

    amb = component_scores.get('amb', 1.0)
    cic = component_scores.get('cic', 1.0)
    infd = component_scores.get('infd', 1.0)
    stc = component_scores.get('stc', 1.0)
    comp4_min = 1  # amb * cic * infd * stc = 1 * 1 * 1 *1 = 1
    comp4_max = 16  # amb * cic * infd * stc = 2 * 2 * 2 * 2 = 16
    comp4_desired_range_max = 2.0
    scaled_comp4 = ((amb * cic * infd * stc)-1) / (comp4_max-comp4_min) * comp4_desired_range_max

    gs = component_scores.get('gs', 1.0)

    """
        New Ci calculation
        bltx_desired_range_max = 8 + com4_desired_range_max = 2.0 = 10.0
        i.e.    80% of the question's complexity is due to cognitive ability requirements and the other 20% is due to 
                com4 (amb, cic, infd, stc)
                however, the way the question is presented i.e. question format and other factors that make the question
                easy to guess, affects the inherent complexity.

                hence (80% + 20%) * GS factor = CI Score
    """
    ci_score = (scaled_bltx + scaled_comp4) * gs


    if debug:
        print(f"\nComponent Scores: {component_scores}")
        print(f"CI = bltx({component_scores.get('bltx', 0)}) * amb({component_scores.get('amb', 1.0)}) * "
              f"infd({component_scores.get('infd', 1.0)}) * stc({component_scores.get('stc', 1.0)}) * "
              f"cic({component_scores.get('cic', 1.0)}) * gs({component_scores.get('gs', 1.0)})")
        print(f"\nFinal Score: {ci_score}")

    if display_status:
        print("END ------> Calculating Cerebro Index ******************\n")

    return QuestionComplexity(
        question=question.model_dump(),
        complexity_score=round(ci_score, 2),
        component_scores=component_scores,
        # explanation="The Cerebro Index (CI) Score combines cognitive, linguistic, and structural factors—such as "
        #             "Cognitive Process Levels, Ambiguity, Information Density, Syntactic Complexity, Conceptual "
        #             "Interconnectedness, and Question Format—into a normalized complexity metric. By isolating "
        #             "complexity from learner-specific traits (e.g., prior knowledge), the CI allows AI to create "
        #             "structurally consistent questions and helps educators tailor difficulty to individual learners.",
        explanation="The Cerebro Index (CI) Score quantifies question complexity by integrating cognitive, linguistic, "
                    "and structural factors, independent of learner-specific traits. This enables AI to generate "
                    "consistent rigorous questions and helps educators adjust difficulty to individual learners.",
        bltx=component_details.get('bltx'),
        amb=component_details.get('amb'),
        infd=component_details.get('infd'),
        stc=component_details.get('stc'),
        cic=component_details.get('cic'),
        gs=component_details.get('gs'),
        total_tokens=total_tokens,
        input_tokens=input_tokens,
        output_tokens=output_tokens
    )

